package main

import (
	"github.com/Sonos-Inc/pdsw-engx-devops-sk8s/cmd"
)

func main() {
	cmd.Execute()
}
