# Sk8s

Sk8s is a simple utility for Kubernetes (K8s) at Sonos.

## Features

Sk8s is an in-house utility for working with K8s at Sonos.

Currently the functionality Sk8s supports includes:

- Easy login using browser based Okta/OAuth login
- Easy token refresh every 4 hours.
- Update notifications when new versions of this project are published
- Configs saved locally
- Multi cluster support
- Artifactory helm repo login
- Debugging of applications running in k8s

## Install

Currently, releases are uploaded to s3 for most major platforms.

MacOS users can run the following when on VPN or the Sonos network:

```bash
brew install sonos-inc/pdsw-devops/sk8s
# Or to upgrade:
brew upgrade sonos-inc/pdsw-devops/sk8s
```

Find the specific version you would like [here](https://s3.amazonaws.com/093d2402-1813-11e9-b269-33c14c94eed6/manifest.yaml).

Then for a given version, find the build you need [here](https://s3.amazonaws.com/093d2402-1813-11e9-b269-33c14c94eed6/versions/v0.0.1/manifest.yaml).

Finally, download the desired artifact by replacing *manifest.yaml* with the version and file name. The files are named with the pattern `sk8s_<os>_<arch>.tar.gz`, so some commonly used ones are `sk8s_linux_amd64.tar.gz`, `sk8s_darwin_amd64.tar.gz`, and `sk8s_darwin_arm64.tar.gz`. The Windows binary also has .exe in the path making it `sk8s_windows_amd64.exe.tar.gz`

For example, for version `v1.12.2` and `sk8s_linux_amd64`:
```bash
curl --output sk8s_linux_amd64.tar.gz https://s3.amazonaws.com/093d2402-1813-11e9-b269-33c14c94eed6/versions/v1.12.2/sk8s_linux_amd64.tar.gz
```

## Usage

For detailed usage instructions, see the `--help` commandline argument.

Typical usage:

```bash
$ sk8s

Configuration has been written to /Users/kubernetes.user/.kube/config

Environment: dev
This token will last 4 hours.


Switch to a context with: kubectx
Then issue commands via: kubectl
```

## Commands

Below is a select list of commands that Sk8s provides:

### debug

Debug prints debug and k8s tools versions. This can be used to quicky diagnose potential version mismatches or issues with your local environment.

```bash
Usage:
  sk8s debug
```

Typical usage:

```bash
$ sk8s debug

Sk8s version: v1.12.0

kubectl version:
Client Version: version.Info{Major:"1", Minor:"19", GitVersion:"v1.19.4", GitCommit:"d360454c9bcd1634cf4cc52d1867af5491dc9c5f", GitTreeState:"clean", BuildDate:"2020-11-12T01:09:16Z", GoVersion:"go1.15.4", Compiler:"gc", Platform:"darwin/amd64"}
Server Version: version.Info{Major:"1", Minor:"18", GitVersion:"v1.18.10", GitCommit:"62876fc6d93e891aa7fbe19771e6a6c03773b0f7", GitTreeState:"clean", BuildDate:"2020-10-15T01:43:56Z", GoVersion:"go1.13.15", Compiler:"gc", Platform:"linux/amd64"}

...
```

### doctor (beta)

Diagnoses potential issues preventing a pod from running in k8s.

Note: This command is currently in beta. More features may be added to this tool and the current state of the command may not be representative of its final implementation.

```bash
Usage:
  sk8s doctor [name of pod] [flags]

Aliases:
  doctor, dr

Flags:
  -n, --namespace string   Namespace of Pod (default "default")
```

Typical usage:

```bash
$ sk8s doctor my-pod -n my-namespace

Pod: my-pod
Namespace: my-namespace

Arguments Verified. Found pod my-pod in namespace my-namespace

Running sk8s Doctor.


# Pod Tests

## Pod State
✓ - Pod has started
✓ - Pod Last State - Running
✓ - All containers are passing readiness probes
    Name: my-container
    Ready: true
    LastTerminationState: null
    Restart Count: 0

## Pod Resources
✓ - Pod resources defined

...
```

### find

Fuzzyfinder to switch kubectl context and Sk8s environment

This command will log in for you to the Sk8s environment corresponding to the context you switch to.

```bash
Usage:
  sk8s find

Aliases:
  find, f
```

Typical Usage:

```bash
$ sk8s find

  test.k.do.ws.sonos.com - dev
  build.k.do.ws.sonos.com - dev
> sandbox.k.do.ws.sonos.com - dev
  3/3
Select your environment to login:

# Select your environment. You can either enter the name of the environment, or use the arrow keys to select your environment.

Switching context to sandbox.k.do.ws.sonos.com - dev
I1201 11:29:00.583494   31372 nextEnvironment.go:13] Switching environment to: dev
Configuration has been written to /Users/kubernetes.user/.kube/config

Environment: dev
This token will last 4 hours.


Switch to a context with: kubectx
Then issue commands via: kubectl
```

### setup

Setup can help you set up your local environment. For now, the only command you can use is `artifactory`, which will set up your environment to be able to pull/push from/to artifactory.

```bash
Usage:
  sk8s setup [command]

Available Commands:
  artifactory sets up users artifactory config
```

## Developing

For information on developing Sk8s, see [this](./docs/developing.md) doc.

## Todo

Lots (see [Issues](https://github.com/Sonos-Inc/pdsw-engx-devops-sk8s/issues) as well.)
