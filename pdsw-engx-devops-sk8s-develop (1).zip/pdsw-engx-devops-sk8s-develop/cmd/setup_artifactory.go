package cmd

import (
	"bufio"
	"bytes"
	"context"
	"fmt"
	"os"
	"os/exec"
	"strings"
	"syscall"

	"github.com/docker/docker/client"
	"github.com/golang/glog"
	"github.com/hashicorp/go-version"
	"github.com/spf13/cobra"
	"golang.org/x/crypto/ssh/terminal"
)

type Registry struct {
	Name    string `json:"name"`
	URL     string `json:"url"`
	Default string `json:"default`
}

type HelmRepositories struct {
	Name string `json:"name"`
	URL  string `json:"url"`
}

func init() {
	setupCmd.AddCommand(setArtifactoryCmd)
}

var setArtifactoryCmd = &cobra.Command{
	Use:   "artifactory",
	Short: "sets up users artifactory config",
	Long:  "sets up users artifactory config",
	Run: func(cmd *cobra.Command, args []string) {
		cli, err := client.NewEnvClient()
		if err != nil {
			panic(err)
		}

		_, err = cli.Info(context.Background())
		if err != nil {
			glog.Infoln("Cannot communicate with docker, please ensure docker is installed and running locally")
			panic(err)
		}

		var registries []Registry
		var helmRepositories []HelmRepositories

		err = c.clusterConfig.UnmarshalKey("registries", &registries)

		if err != nil {
			glog.Errorf("Error unmarshalling registries, may need to run sk8s update")
			panic(err)
		}
		fmt.Println("")
		fmt.Println("For Sonos Artifactory, first click the artifcatory link in Okta to login,")
		fmt.Println("then use the username and API Key which are located at:\n")
		fmt.Println("  https://artifactory.sonos.com/ui/admin/artifactory/user_profile\n")
		fmt.Println("If you do not have an API Key, click the button to generate one.")
		fmt.Println("Please ensure both docker and helm are installed and running prior to executing this command.\n")
		username, password := credentials()

		for _, i := range registries {
			fmt.Printf("\nLogging into %s environment at %s\n\n", i.Name, i.URL)
			command := exec.Command("docker", "login", i.URL, "-u", username, "--password-stdin")
			command.Stdin = strings.NewReader(password)

			var out bytes.Buffer
			command.Stdout = &out
			err := command.Run()
			if err != nil {
				fmt.Println("\nLogin not successful, check your server address and credentials, and try again.")
				panic(err)
			}

			fmt.Println("\nLogin Successful.")

		}

		err = c.clusterConfig.UnmarshalKey("helmRepositories", &helmRepositories)
		if err != nil {
			glog.Errorf("Error unmarshalling helmRepositories, may need to run sk8s update")
			panic(err)
		}

		for _, i := range helmRepositories {
			helmLogin("helm", i.Name, i.URL, username, password)
		}
	},
}

func helmGetVersion(helmBinary string) (versionString string) {
	var cmd *exec.Cmd = exec.Command(helmBinary, "version", "--template={{.Version}}")
	var stderr bytes.Buffer
	cmd.Stderr = &stderr
	version, err := cmd.Output()

	if err != nil {
		fmt.Printf(stderr.String())
		fmt.Println(err)
		panic(err)
	}

	versionSplit := strings.SplitAfter(string(version), "v")
	versionString = string(versionSplit[1])
	return
}

func helmLogin(helmBinary string, name string, url string, username string, password string) {
	fmt.Printf("\nLogging into helm repository %s via %s\n", name, helmBinary)

	helmVersion := helmGetVersion(helmBinary)

	v1, err := version.NewVersion(helmVersion)
	if err != nil {
		fmt.Println(err)
		panic(err)
	}

	v2, err := version.NewVersion("3.8.1")
	if err != nil {
		fmt.Println(err)
		panic(err)
	}

	command := exec.Command(helmBinary, "repo", "add", name, url, "--force-update", "--username", username, "--password", password)

	if v1.GreaterThanOrEqual(v2) {
		command = exec.Command(helmBinary, "repo", "add", name, url, "--force-update", "--username", username, "--password", password, "--pass-credentials")
	}

	var out bytes.Buffer
	command.Stdout = &out
	err = command.Run()
	if err != nil {
		fmt.Printf("\nLogin to %s not successful, check your server address and credentials, and try again.\n", url)
		panic(err)
	}

	fmt.Println("\nLogin Successful.")
}

func credentials() (string, string) {
	reader := bufio.NewReader(os.Stdin)

	fmt.Print("Enter Username: ")
	username, _ := reader.ReadString('\n')

	fmt.Print("Enter Password: ")
	bytePassword, err := terminal.ReadPassword(int(syscall.Stdin))
	if err != nil {
		fmt.Printf("Error: %v\n", err)
	}
	password := string(bytePassword)

	return strings.TrimSpace(username), strings.TrimSpace(password)
}
