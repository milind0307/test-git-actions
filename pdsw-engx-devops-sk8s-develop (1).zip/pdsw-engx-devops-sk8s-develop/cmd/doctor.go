package cmd

import (
	"context"
	"fmt"
	"os"

	"github.com/Sonos-Inc/pdsw-engx-devops-sk8s/cmd/doctortests"
	"github.com/Sonos-Inc/pdsw-engx-devops-sk8s/cmd/helper"

	"github.com/spf13/cobra"

	"k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	// Necessary for k8s client
	_ "k8s.io/client-go/plugin/pkg/client/auth/oidc"
)

// Namespace is a flag
var Namespace string

func init() {
	rootCmd.AddCommand(doctorCmd)

	config, _ := helper.GetKubeConfig(c.kubeConfigPath)
	namespace := helper.GetNamespace(config)

	doctorCmd.Flags().StringVarP(&Namespace, "namespace", "n", namespace, "Namespace of Pod")
}

var doctorCmd = &cobra.Command{
	Use:     "doctor [name of pod]",
	Short:   "Diagnose a pod in k8s",
	Long:    "Diagnoses potential issues preventing a pod from running in k8s",
	Aliases: []string{"dr"},
	Args:    cobra.MinimumNArgs(0),
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Printf("~~~ Sk8s Doctor ~~~\n\n")

		namespace := Namespace
		fmt.Printf("Namespace: %s\n", namespace)

		// If we define a pod, only run on that pod, else run on all pods in a namespace (defaults to default)
		var pods []string
		if len(args) > 0 && args[0] != "" {
			pods = append(pods, args[0])
			fmt.Printf("Running sk8s Doctor on '%s' in the namespace '%s'.\n\n", pods[0], namespace)

		} else {
			clientset := helper.GetClientSet(c.kubeConfigPath)
			podsWithMetadata, _ := clientset.CoreV1().Pods(namespace).List(context.TODO(), metav1.ListOptions{})
			for _, podName := range podsWithMetadata.Items {
				pods = append(pods, podName.Name)
			}
			fmt.Printf("Running sk8s Doctor on all pods in the namespace '%s'.\n\n", namespace)
		}

		fmt.Printf("###############################\n")

		// Run doctor for every pod the user wants to doctor.
		for _, pod := range pods {
			fmt.Printf("Pod: %s\n", pod)

			verifyArgs(c.kubeConfigPath, namespace, pod)

			// Run Test Cases (located in doctortests/)
			doctortests.RunPodTests(c.kubeConfigPath, namespace, pod)
			doctortests.RunNamespaceTests(c.kubeConfigPath, namespace, pod)

			fmt.Printf("###############################\n")
		}

	},
}

// Used for verifying arguments and ensuring that the pod provided exists in the namespace provided.
func verifyArgs(kubeConfigPath string, namespace string, pod string) {
	clientset := helper.GetClientSet(kubeConfigPath)
	_, err := clientset.CoreV1().Pods(namespace).Get(context.TODO(), pod, metav1.GetOptions{})
	if errors.IsNotFound(err) {
		fmt.Printf("Pod %s in namespace %s not found\n", pod, namespace)
		fmt.Printf("Please ensure the pod %s is running in the namespace %s\n", pod, namespace)
		os.Exit(1)
	} else if statusError, isStatus := err.(*errors.StatusError); isStatus {
		fmt.Printf("Error getting pod %s in namespace %s: %v\n",
			pod, namespace, statusError.ErrStatus.Message)
		fmt.Println("Error getting pod, ensure you have access to a cluster")
		os.Exit(1)
	} else if err != nil {
		panic(err.Error())
	}
}
