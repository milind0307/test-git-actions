package cmd

import (
	"github.com/Sonos-Inc/pdsw-engx-devops-sk8s/cmd/helper"

	"github.com/spf13/cobra"
)

func init() {
	rootCmd.AddCommand(updateCmd)
}

var updateCmd = &cobra.Command{
	Use:   "update",
	Short: "Updates cluster configs",
	Long:  "Downloads latest cluster configs from s3",
	Run: func(cmd *cobra.Command, args []string) {
		helper.ClusterConfigUpdates(c.clusterConfig, c.sk8sConfig.GetString("sk8sBucket"))
	},
}
