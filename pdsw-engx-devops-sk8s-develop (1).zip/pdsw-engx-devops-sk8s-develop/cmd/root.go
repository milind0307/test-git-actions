package cmd

import (
	"fmt"
	"log"
	"net/http"
	"os"
	"os/user"
	"time"

	"github.com/Sonos-Inc/pdsw-engx-devops-sk8s/cmd/helper"

	stdFlag "flag"

	oidc "github.com/coreos/go-oidc"
	"github.com/golang/glog"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"
)

type Config struct {
	environment     string
	clientID        string
	clientSecret    string
	redirectURI     string
	kubeConfigPath  string
	issuerURL       string
	listen          string
	tlsCert         string
	tlsKey          string
	rootCAs         string
	debug           bool
	sk8sVersionURL  string
	skipUpdateCheck bool

	verifier *oidc.IDTokenVerifier
	provider *oidc.Provider

	client *http.Client
	// Does the provider use "offline_access" scope to request a refresh token
	// or does it use "access_type=offline" (e.g. Google)?
	offlineAsScope bool

	sk8sConfig    *viper.Viper
	clusterConfig *viper.Viper
}

const exampleAppState = "I wish to wash my irish wristwatch"

var c Config

func init() {
	defaults := map[string]string{
		"client-id":              "kubernetes",
		"client-secret-override": "",
		"redirect-uri":           "http://127.0.0.1:5555/callback",
		"sk8sBucket":             "https://s3.amazonaws.com/093d2402-1813-11e9-b269-33c14c94eed6",
		"sk8sVersionURL":         "https://s3.amazonaws.com/093d2402-1813-11e9-b269-33c14c94eed6/current",
		"listen":                 "http://127.0.0.1:5555",
		"debug":                  "false",
		"skip-update-check":      "false",
	}

	// bonus: log to stderr by default,
	// override with `--logtostderr=false`
	stdFlag.Set("logtostderr", "true")

	// make glog flags available in Cobra's CLI
	rootCmd.PersistentFlags().AddGoFlagSet(stdFlag.CommandLine)

	stdFlag.CommandLine.Parse([]string{})

	usr, err := user.Current()
	if err != nil {
		log.Fatal(err)
	}

	c.sk8sConfig = viper.New()
	c.clusterConfig = viper.New()

	configDir := fmt.Sprintf("%s/.sk8s", usr.HomeDir)
	configFullPath := fmt.Sprintf("%s/%s.%s", configDir, "config", "yaml")
	clusterconfigFullPath := fmt.Sprintf("%s/%s.%s", configDir, "clusters", "yaml")

	helper.SetupConfig(c.sk8sConfig, configDir, configFullPath, defaults)
	helper.SetupClusterConfig(c.clusterConfig, configDir, clusterconfigFullPath, c.sk8sConfig.GetString("sk8sBucket"))
	c.environment = c.sk8sConfig.GetString("environment")
	clientid, err := helper.GetClientID(c.clusterConfig, c.environment)
	if err != nil {
		// Client not found, setting to empty string
		clientid = ""
	}

	issuer, err := helper.GetIssuer(c.clusterConfig, c.environment)
	if err != nil {
		// Issuer not found, setting to empty string for now
		issuer = ""
	}
	rootCmd.PersistentFlags().StringVar(&c.clientID, "client-id", clientid, "OAuth2 client ID of this application.")
	rootCmd.PersistentFlags().StringVar(&c.clientSecret, "client-secret", "", "Override OAuth2 client secret of this application.")
	rootCmd.PersistentFlags().StringVar(&c.redirectURI, "redirect-uri", c.sk8sConfig.GetString("redirect-uri"), "Callback URL for OAuth2 responses.")
	rootCmd.PersistentFlags().StringVar(&c.kubeConfigPath, "kube-config-path", "", "Override kube config path")
	rootCmd.PersistentFlags().StringVar(&c.issuerURL, "issuer", issuer, "URL of the OpenID Connect issuer.")
	rootCmd.PersistentFlags().StringVar(&c.sk8sVersionURL, "sk8s-version-url", c.sk8sConfig.GetString("sk8sVersionURL"), "URL to check for curent version of sk8s")
	rootCmd.PersistentFlags().StringVar(&c.listen, "listen", c.sk8sConfig.GetString("listen"), "HTTP(S) address to listen at.")
	rootCmd.PersistentFlags().BoolVar(&c.debug, "debug", c.sk8sConfig.GetBool("debug"), "Print all request and responses from the OpenID Connect issuer.")
	rootCmd.PersistentFlags().BoolVar(&c.skipUpdateCheck, "skip-update-check", c.sk8sConfig.GetBool("skip-update-check"), "Skip update check.")

}

var rootCmd = &cobra.Command{
	Use:   "sk8s",
	Short: "Sk8s is Sonos' Kubernetes Authenticator",
	Long:  `Sk8s is Sonos' Kubernetes Authenticator for logging into Kubernetes via Dex/Okta`,
	PersistentPreRun: func(cmd *cobra.Command, args []string) {
		// to convince glog that we have called `flag.Parse()`,
		// without actually consuming CLI flags
		stdFlag.CommandLine.Parse([]string{})
		if !c.skipUpdateCheck {
			checkVersionComplete := make(chan bool)
			go helper.CheckVersion(c.sk8sVersionURL, VERSION, checkVersionComplete)

			select {
			case <-checkVersionComplete:
				return
			case <-time.After(2 * time.Second):
				glog.V(8).Infof("Update check timed out...\n")
				glog.V(8).Infof("Ensure you're either in a Sonos office or on Full Tunnel VPN.\n")
				glog.V(8).Infof("Attempting to continue on...\n")
			}
		}
	},
	Run: func(cmd *cobra.Command, args []string) {
		if len(args) == 0 {
			err := login(cmd, args)
			if err != nil {
				glog.Errorf("Error: %v", err)
				os.Exit(1)
			}
		}
	},
}

func Execute() {
	if err := rootCmd.Execute(); err != nil {
		stdFlag.CommandLine.Parse([]string{})
		glog.V(8).Infof("Error executing root command: %v", err)
	}
}
