package cmd

import (
	"os"

	"github.com/Sonos-Inc/pdsw-engx-devops-sk8s/cmd/helper"
	"github.com/golang/glog"
	"github.com/spf13/cobra"
)

func init() {
	rootCmd.AddCommand(switchCmd)
}

var switchCmd = &cobra.Command{
	Use:   "switch [optional environment]",
	Short: "Switches to the supplied environment or previous environment and logs in",
	Long:  "Switches to the supplied environment or previous environment and logs in",
	Args:  cobra.MaximumNArgs(1),
	Run: func(cmd *cobra.Command, args []string) {
		var err error
		currentEnvironment := c.sk8sConfig.Get("environment")

		nextEnvironment := helper.GetNextEnvironment(args, c.sk8sConfig.GetString("previousEnvironment"))

		c.environment = nextEnvironment
		c.clientID, err = helper.GetClientID(c.clusterConfig, c.environment)
		if err != nil {
			glog.Errorf("Error: %v\n", err)
			glog.Errorln("Please confirm you've selected a configured environment.")
			glog.Errorln("You can list environments by running: sk8s environments")
			os.Exit(1)
		}
		issuer, err := helper.GetIssuer(c.clusterConfig, c.environment)
		if err != nil {
			glog.Fatalf("Error: %v", err)
		}
		c.issuerURL = issuer

		// Write config after all other calls succeed
		c.sk8sConfig.Set("environment", nextEnvironment)
		c.sk8sConfig.Set("previousEnvironment", currentEnvironment)
		c.sk8sConfig.WriteConfig()

		err = login(cmd, nil)
		if err != nil {
			glog.Errorf("Error: %v", err)
			os.Exit(1)
		}
	},
}
