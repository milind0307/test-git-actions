package cmd

import (
	"bytes"
	"fmt"
	"io/ioutil"
	"net/http"
	"os/exec"

	"github.com/Sonos-Inc/pdsw-engx-devops-sk8s/cmd/helper"
	"github.com/golang/glog"
	"github.com/spf13/cobra"
)

func init() {
	rootCmd.AddCommand(debugCmd)
}

var debugCmd = &cobra.Command{
	Use:   "debug",
	Short: "Prints debug and K8s tools versions",
	Long:  "Prints debug and K8s tools versions",
	Run: func(cmd *cobra.Command, args []string) {
		config, _ := helper.GetKubeConfig(c.kubeConfigPath)
		fmt.Printf("Sk8s version: " + GetVersion() + "\n\n")
		printToolsVersions([]string{"kubectl", "helm", "helmfile"})
		fmt.Println("Current context: " + helper.GetContext(config))
		fmt.Println("Default namespace for current context: " + helper.GetNamespace(config))
		fmt.Println("Last Sk8s cluster configuration update: " + getLastUpdate())
		fmt.Printf(pingBucket())
	},
}


func getLastUpdate() string {
	lastUpdate := c.clusterConfig.GetString("last-update")
	if lastUpdate == "" {
		glog.Error("Cannot get last time Sk8s cluster config was updated, does the file exist?")
	}
	return lastUpdate
}

func printToolsVersions(tools []string) {
	for _, tool := range tools {
		var cmd *exec.Cmd
		if tool == "helmfile" {
			cmd = exec.Command(tool, "--version")
		} else {
			cmd = exec.Command(tool, "version")
		}
		var stderr bytes.Buffer
		cmd.Stderr = &stderr
		version, err := cmd.Output()
		fmt.Println(tool + " version:")
		fmt.Printf(string(version))
		if err != nil {
			fmt.Printf(stderr.String())
			fmt.Println(err)
			fmt.Printf("\n")
		} else {
			fmt.Printf("\n")
		}
	}
}

func pingBucket() string {
	var status string
	url := fmt.Sprintf("%s/status.txt", c.sk8sConfig.GetString("sk8sBucket"))
	resp, err := http.Get(url)
	if err != nil {
		glog.Errorf("Error getting bucket status: %s", err)
	}
	defer resp.Body.Close()
	if err != nil || resp.StatusCode != 200 {
		status = fmt.Sprintf("Cannot ping Sk8s S3 bucket, ensure you're either in a Sonos office or on Full Tunnel Corp VPN\n")
		return status
	}
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		glog.Errorf("Error reading status text: %v", err)
	}
	status = string(body)
	return status
}
