package cmd

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"log"
	"os/user"
	"path/filepath"

	"github.com/Sonos-Inc/pdsw-engx-devops-sk8s/cmd/helper"
	"golang.org/x/oauth2"

	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"time"

	oidc "github.com/coreos/go-oidc"
	"github.com/golang/glog"
	"github.com/spf13/cobra"
	"k8s.io/client-go/tools/clientcmd"
	clientcmdapi "k8s.io/client-go/tools/clientcmd/api"
)

const clientSecret = "cjJmdTl3Z3I5MHVwaGl3NDl1Z3Nkam9nZXdvaWpod2VmaW8="

type claim struct {
	Iss            string `json:"iss"`
	Sub            string `json:"sub"`
	Aud            string `json:"aud"`
	Exp            int32  `json:"exp"`
	Iat            int32  `json:"iat"`
	Azp            string `json:"azp"`
	At_hash        string `json:"at_hash"`
	Email          string `json:"email"`
	Email_verified string `json:"email_verified"`
	Name           string `json:"name"`
}
type debugTransport struct {
	t http.RoundTripper
}

func init() {
	rootCmd.AddCommand(loginCmd)
}

var loginCmd = &cobra.Command{
	Use:   "login",
	Short: "Login using Sk8s",
	Long:  `Login using Sk8s`,
	Run: func(cmd *cobra.Command, args []string) {
		err := login(cmd, args)
		if err != nil {
			glog.Errorf("Error: %v", err)
			os.Exit(1)
		}
	},
}

func login(cmd *cobra.Command, args []string) error {
	if len(args) != 0 {
		return errors.New("surplus arguments provided")
	}

	u, err := url.Parse(c.redirectURI)
	if err != nil {
		return fmt.Errorf("parse redirect-uri: %v", err)
	}
	listenURL, err := url.Parse(c.listen)
	if err != nil {
		return fmt.Errorf("parse listen address: %v", err)
	}

	if c.debug {
		if c.client == nil {
			c.client = &http.Client{
				Transport: debugTransport{http.DefaultTransport},
			}
		} else {
			c.client.Transport = debugTransport{c.client.Transport}
		}
	}

	if c.client == nil {
		c.client = http.DefaultClient
	}
	ctx := oidc.ClientContext(context.Background(), c.client)
	provider, err := oidc.NewProvider(ctx, c.issuerURL)
	if err != nil {
		return fmt.Errorf("Failed to query provider %q: %v", c.issuerURL, err)
	}

	var s struct {
		// What scopes does a provider support?
		//
		// See: https://openid.net/specs/openid-connect-discovery-1_0.html#ProviderMetadata
		ScopesSupported []string `json:"scopes_supported"`
	}
	if err := provider.Claims(&s); err != nil {
		return fmt.Errorf("Failed to parse provider scopes_supported: %v", err)
	}

	if len(s.ScopesSupported) == 0 {
		// scopes_supported is a "RECOMMENDED" discovery claim, not a required
		// one. If missing, assume that the provider follows the spec and has
		// an "offline_access" scope.
		c.offlineAsScope = true
	} else {
		// See if scopes_supported has the "offline_access" scope.
		c.offlineAsScope = func() bool {
			for _, scope := range s.ScopesSupported {
				if scope == oidc.ScopeOfflineAccess {
					return true
				}
			}
			return false
		}()
	}

	c.provider = provider
	clientid, err := helper.GetClientID(c.clusterConfig, c.environment)
	if err != nil {
		glog.Fatalf("Error: %v", err)
	}
	c.verifier = provider.Verifier(&oidc.Config{ClientID: clientid})

	closeConnection := make(chan bool)
	channelHandleCallback := handleCallback(closeConnection)

	http.HandleFunc("/", handleLogin)
	http.HandleFunc("/login", handleLogin)
	http.HandleFunc(u.Path, channelHandleCallback)

	helper.LaunchBrowser(true, c.listen)

	switch listenURL.Scheme {
	case "http":
		glog.V(8).Infof("listening on %s", c.listen)
		srvCLoser, err := helper.ListenAndServeWithClose(listenURL.Host, nil)
		if err != nil {
			log.Fatalln("Error listening - ", err)
			os.Exit(1)
		}

		<-closeConnection

		err = srvCLoser.Close()
		if err != nil {
			log.Fatalln("Server Close Error - ", err)
		}

		glog.V(8).Info("Server Closed")
	case "https":
		glog.Infof("listening on %s", c.listen)
		http.ListenAndServeTLS(listenURL.Host, c.tlsCert, c.tlsKey, nil)
	default:
		return fmt.Errorf("listen address %q is not using http or https", c.listen)
	}
	return nil
}

func handleLogin(w http.ResponseWriter, r *http.Request) {
	var scopes []string

	clientid, err := helper.GetClientID(c.clusterConfig, c.environment)
	if err != nil {
		glog.Fatalf("Error: %v", err)
	}

	scopes = append(scopes, "audience:server:client_id:"+clientid)

	authCodeURL := ""
	scopes = append(scopes, "openid", "profile", "email")
	if r.FormValue("offline_access") != "yes" {
		authCodeURL = oauth2Config(scopes).AuthCodeURL(exampleAppState)
	} else if c.offlineAsScope {
		scopes = append(scopes, "offline_access")
		authCodeURL = oauth2Config(scopes).AuthCodeURL(exampleAppState)
	} else {
		authCodeURL = oauth2Config(scopes).AuthCodeURL(exampleAppState, oauth2.AccessTypeOffline)
	}

	http.Redirect(w, r, authCodeURL, http.StatusSeeOther)
}

func handleCallback(closeConnection chan bool) func(http.ResponseWriter, *http.Request) {
	return func(w http.ResponseWriter, r *http.Request) {
		var (
			err   error
			token *oauth2.Token
		)

		ctx := oidc.ClientContext(r.Context(), c.client)
		oauth2Config := oauth2Config(nil)
		switch r.Method {
		case "GET":
			// Authorization redirect callback from OAuth2 auth flow.
			if errMsg := r.FormValue("error"); errMsg != "" {
				http.Error(w, errMsg+": "+r.FormValue("error_description"), http.StatusBadRequest)
				return
			}
			code := r.FormValue("code")
			if code == "" {
				http.Error(w, fmt.Sprintf("no code in request: %q", r.Form), http.StatusBadRequest)
				return
			}
			if state := r.FormValue("state"); state != exampleAppState {
				http.Error(w, fmt.Sprintf("expected state %q got %q", exampleAppState, state), http.StatusBadRequest)
				return
			}
			token, err = oauth2Config.Exchange(ctx, code)
		case "POST":
			// Form request from frontend to refresh a token.
			refresh := r.FormValue("refresh_token")
			if refresh == "" {
				http.Error(w, fmt.Sprintf("no refresh_token in request: %q", r.Form), http.StatusBadRequest)
				return
			}
			t := &oauth2.Token{
				RefreshToken: refresh,
				Expiry:       time.Now().Add(-time.Hour),
			}
			token, err = oauth2Config.TokenSource(ctx, t).Token()
		default:
			http.Error(w, fmt.Sprintf("method not implemented: %s", r.Method), http.StatusBadRequest)
			return
		}

		if err != nil {
			http.Error(w, fmt.Sprintf("failed to get token: %v", err), http.StatusInternalServerError)
			return
		}

		rawIDToken, ok := token.Extra("id_token").(string)
		if !ok {
			http.Error(w, "no id_token in token response", http.StatusInternalServerError)
			return
		}

		idToken, err := c.verifier.Verify(r.Context(), rawIDToken)
		if err != nil {
			http.Error(w, fmt.Sprintf("Failed to verify ID token: %v", err), http.StatusInternalServerError)
			return
		}
		var jsonClaims json.RawMessage
		idToken.Claims(&jsonClaims)

		var claims claim
		idToken.Claims(&claims)

		name := fmt.Sprintf("%s-%s", claims.Name, c.environment)

		writeConfig(name, rawIDToken)

		buff := new(bytes.Buffer)
		json.Indent(buff, []byte(jsonClaims), "", "  ")
		helper.RenderToken(w, c.redirectURI, rawIDToken, token.RefreshToken, buff.Bytes(), c.environment)
		closeConnection <- true
	}
}

func writeConfig(name, idToken string) {

	clientid, err := helper.GetClientID(c.clusterConfig, c.environment)
	if err != nil {
		glog.Fatalf("Error: %v", err)
	}
	issuer, err := helper.GetIssuer(c.clusterConfig, c.environment)
	if err != nil {
		glog.Fatalf("Error: %v", err)
	}
	authInfo := helper.GenerateAuthInfo(issuer, clientid, returnClientSecret(), idToken)
	clusters := helper.GenerateClusters(c.clusterConfig, c.environment)
	contexts := helper.GenerateContexts(c.clusterConfig, c.sk8sConfig, c.environment, name)

	config := &clientcmdapi.Config{
		AuthInfos: map[string]*clientcmdapi.AuthInfo{name: authInfo},
		Clusters:  clusters,
		Contexts:  contexts,
	}

	currentContext := &clientcmdapi.Config{
		CurrentContext: "sandbox.k.do.ws.sonos.com",
	}

	tempKubeConfig, err := ioutil.TempFile("", "")
	if err != nil {
		glog.Errorf("Could not create tempfile: %v\n", err)
		os.Exit(1)
	}
	defer os.Remove(tempKubeConfig.Name())
	clientcmd.WriteToFile(*config, tempKubeConfig.Name())
	tempCurrentContextConfig, err := ioutil.TempFile("", "")
	if err != nil {
		glog.Errorf("Could not create tempfile: %v\n", err)
		os.Exit(1)
	}
	defer os.Remove(tempCurrentContextConfig.Name())
	clientcmd.WriteToFile(*currentContext, tempCurrentContextConfig.Name())

	var kubeConfigPath string
	if c.kubeConfigPath == "" {
		usr, err := user.Current()
		if err != nil {
			glog.Errorf("Could not determine current: %v\n", err)
			os.Exit(1)
		}
		kubeConfigPath = filepath.Join(usr.HomeDir, ".kube", "config")
	} else {
		kubeConfigPath = c.kubeConfigPath
	}

	loadingRules := clientcmd.ClientConfigLoadingRules{
		// Overrides Current Kubeconfig, with our changes and finally overriding back to the existing context.
		Precedence: []string{kubeConfigPath, tempKubeConfig.Name(), tempCurrentContextConfig.Name()},
	}
	mergedConfig, err := loadingRules.Load()
	if err != nil {
		glog.Errorf("Could not merge configuration: %v\n", err)
		os.Exit(1)
	}

	clientcmd.WriteToFile(*mergedConfig, kubeConfigPath)
	fmt.Printf("Configuration has been written to %s\n", kubeConfigPath)
	fmt.Printf("\nEnvironment: %s\n", c.environment)
	fmt.Println("This token will last 4 hours.\n")
	fmt.Println("\nSwitch to a context with: kubectx")
	fmt.Println("Then issue commands via: kubectl")
}

func oauth2Config(scopes []string) *oauth2.Config {
	clientid, err := helper.GetClientID(c.clusterConfig, c.environment)
	if err != nil {
		glog.Fatalf("Error: %v", err)
	}

	return &oauth2.Config{
		ClientID:     clientid,
		ClientSecret: returnClientSecret(),
		Endpoint:     c.provider.Endpoint(),
		Scopes:       scopes,
		RedirectURL:  c.redirectURI,
	}
}

func (d debugTransport) RoundTrip(req *http.Request) (*http.Response, error) {
	reqDump, err := httputil.DumpRequest(req, true)
	if err != nil {
		return nil, err
	}
	glog.Infof("%s", reqDump)

	resp, err := d.t.RoundTrip(req)
	if err != nil {
		return nil, err
	}

	respDump, err := httputil.DumpResponse(resp, true)
	if err != nil {
		resp.Body.Close()
		return nil, err
	}
	glog.Infof("%s", respDump)
	return resp, nil
}

func returnClientSecret() string {
	if c.clientSecret != "" {
		glog.V(8).Infof("Returning overridden client secret: %v", c.clientSecret)
		return c.clientSecret
	} else {
		glog.V(8).Info("Decoding client secret")
		secret := *helper.GetClientSecret(c.clusterConfig, c.environment)
		data, err := base64.StdEncoding.DecodeString(secret)
		if err != nil {
			glog.Error("Error decoding client secret", err)
		}
		glog.V(8).Infof("Returning decoded client secret: %v", string(data))
		return string(data)
	}
}
