package cmd

import (
	"fmt"
	"os"

	"github.com/spf13/cobra"
)

func init() {
	rootCmd.AddCommand(completionCmd)
}

var completionCmd = &cobra.Command{
	Use:   "completion",
	Short: "Supply shell completion files for Sk8s",
	Long: `Supply shell completion files for Sk8s. The following shells are supported:
	
		bash
		zsh

	Run using sk8s completion zsh or sk8s completion bash`,
	Run: func(cmd *cobra.Command, args []string) {
		if len(args) > 1 {
			fmt.Println("Please provide a shell for which to generate autocompletion")
			os.Exit(1)
		} else if len(args) < 1 {
			fmt.Println("Please provide only one shell for which to generate autocompletion")
			os.Exit(1)
		}
		if args[0] == "bash" {
			rootCmd.GenBashCompletion(os.Stdout)
			return
		}
		if args[0] == "zsh" {
			rootCmd.GenZshCompletion(os.Stdout)
			return
		}
	},
	ValidArgs: []string{"bash", "zsh"},
}
