package helper

import (
	"github.com/golang/glog"
	"github.com/spf13/viper"
)

// Issuer config values for a cluster
type Issuer struct {
	Name         string `json:"name"`
	URL          string `json:"URL"`
	Default      string `json:"default,omitempty"`
	ClientID     string `json:"clientID,omitempty"`
	ClientSecret string `json:"clientSecret,omitempty"`
}

func GetEnvironments(v *viper.Viper) []Issuer {
	var environments []Issuer

	err := v.UnmarshalKey("issuers", &environments)
	if err != nil {
		glog.Errorf("Error unmarshaling cluster config: %v", err)
	}

	return environments
}
