package helper

import (
	"bytes"
	"fmt"
	"io/ioutil"
	"net/http"
	"time"

	"github.com/spf13/viper"

	"github.com/golang/glog"
)

func ClusterConfigUpdates(v *viper.Viper, bucket string) {
	url := fmt.Sprintf("%s/clusters.yaml", bucket)
	resp, err := http.Get(url)
	if err != nil {
		glog.Errorf("Error getting cluster config: %s", err)
	}
	defer resp.Body.Close()

	if err != nil || resp.StatusCode != 200 {
		glog.V(4).Info("Warning: Unable to get updated Kubernetes cluster config from s3.")
		glog.V(4).Info("  Ensure you're either in a Sonos office or on Full Tunnel VPN.")
		return
	}

	body, err := ioutil.ReadAll(resp.Body)

	v.ReadConfig(bytes.NewBuffer(body))
	v.Set("last-update", time.Now())

	err = v.WriteConfig()
	if err != nil {
		glog.Errorf("Unable to write new cluster config to file: %v", err)
	}

	glog.Info("Sk8s Cluster data updated.")
}
