package helper

import (
	"github.com/golang/glog"
)

// Returns the next environment to login to
func GetNextEnvironment(args []string, previousEnvironment string) string {
	var nextEnvironment string
	if len(args) > 0 {
		nextEnvironment = args[0]

		glog.Infof("Switching environment to: %s", nextEnvironment)
	} else {
		nextEnvironment = previousEnvironment
		glog.Infof("Switching environment to your previous: %s", previousEnvironment)
	}

	return nextEnvironment
}
