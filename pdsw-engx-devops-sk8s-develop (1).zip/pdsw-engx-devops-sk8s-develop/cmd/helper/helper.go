package helper

import (
	"bufio"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"os/user"
	"runtime"
	"strings"
	"time"

	"github.com/golang/glog"
	"github.com/pkg/errors"
	"github.com/spf13/viper"
	v "github.com/spf13/viper"

	clientcmdapi "k8s.io/client-go/tools/clientcmd/api"
)

type DiscoverySpec struct {
	AuthorizationEndpoint  string   `json:"authorization_endpoint"`
	TokenEndpoint          string   `json:"token_endpoint"`
	ScopesSupported        []string `json:"scopes_supported"`
	ResponseTypesSupported []string `json:"response_types_supported"`
	UserinfoEndpoint       string   `json:"userinfo_endpoint"`
}

func GetDiscoverySpec(issuer string) (DiscoverySpec, error) {
	ds := &DiscoverySpec{}
	resp, err := http.Get(issuer + "/.well-known/openid-configuration")
	if err != nil {
		return *ds, err
	}

	if resp.StatusCode == 403 {
		glog.Error("Unable to login, access denied.")
		resp.Body.Close()
		return *ds, nil
	}

	defer resp.Body.Close()
	err = json.NewDecoder(resp.Body).Decode(ds)
	if err != nil {
		return *ds, err
	}
	return *ds, nil
}

func GenerateAuthInfo(issuer, clientId, clientSecret, idToken string) *clientcmdapi.AuthInfo {
	return &clientcmdapi.AuthInfo{
		AuthProvider: &clientcmdapi.AuthProviderConfig{
			Name: "oidc",
			Config: map[string]string{
				"client-id":      clientId,
				"client-secret":  clientSecret,
				"id-token":       idToken,
				"idp-issuer-url": issuer,
			},
		},
	}
}

func ListenAndServeWithClose(addr string, handler http.Handler) (sc io.Closer, err error) {

	var listener net.Listener

	srv := &http.Server{Addr: addr, Handler: handler}

	if addr == "" {
		addr = ":http"
	}

	listener, err = net.Listen("tcp", addr)
	if err != nil {
		return nil, err
	}

	go func() {
		err := srv.Serve(tcpKeepAliveListener{listener.(*net.TCPListener)})
		if err != nil {
			glog.V(8).Infof("HTTP Server Error - %v", err)
		}
	}()

	return listener, nil
}

type tcpKeepAliveListener struct {
	*net.TCPListener
}

func (ln tcpKeepAliveListener) Accept() (c net.Conn, err error) {
	tc, err := ln.AcceptTCP()
	if err != nil {
		return
	}
	tc.SetKeepAlive(true)
	tc.SetKeepAlivePeriod(3 * time.Minute)
	return tc, nil
}

func CreateOpenCmd(oauthUrl string) (*exec.Cmd, error) {
	switch os := runtime.GOOS; os {
	case "darwin":
		return exec.Command("open", oauthUrl), nil
	case "linux":
		return exec.Command("xdg-open", oauthUrl), nil
	case "windows":
		return exec.Command("rundll32", "url.dll,FileProtocolHandler", oauthUrl), nil
	}
	return nil, fmt.Errorf("Could not detect the open command for OS: %s", runtime.GOOS)
}

func LaunchBrowser(openBrowser bool, oauthUrl string) {
	openInstructions := fmt.Sprintf("Open this url in your browser: %s\n", oauthUrl)

	if !openBrowser {
		glog.Infoln(openInstructions)
		return
	}

	cmd, err := CreateOpenCmd(oauthUrl)
	if err != nil {
		glog.Infoln(openInstructions)
		return
	}

	err = cmd.Start()
	if err != nil {
		glog.Infoln(openInstructions)
	}
}

// return an HTTP client which trusts the provided root CAs.
func HttpClientForRootCAs(rootCAs string) (*http.Client, error) {
	tlsConfig := tls.Config{RootCAs: x509.NewCertPool()}
	rootCABytes, err := ioutil.ReadFile(rootCAs)
	if err != nil {
		return nil, fmt.Errorf("failed to read root-ca: %v", err)
	}
	if !tlsConfig.RootCAs.AppendCertsFromPEM(rootCABytes) {
		return nil, fmt.Errorf("no certs found in root CA file %q", rootCAs)
	}
	return &http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tlsConfig,
			Proxy:           http.ProxyFromEnvironment,
			Dial: (&net.Dialer{
				Timeout:   30 * time.Second,
				KeepAlive: 30 * time.Second,
			}).Dial,
			TLSHandshakeTimeout:   10 * time.Second,
			ExpectContinueTimeout: 1 * time.Second,
		},
	}, nil
}

// Prepares config files
func SetupConfig(config *v.Viper, configDir string, configFullPath string, defaults map[string]string) {
	err := os.MkdirAll(configDir, 0755)
	if err != nil {
		fmt.Errorf("Error creating directory: %s", err)
	}

	config.SetConfigName("config")
	config.SetConfigType("yaml")
	config.AddConfigPath(configDir)

	err = config.ReadInConfig() // Find and read the config file
	if err != nil {             // Handle errors reading the config file
		fmt.Errorf("Fatal error config file: %s \n", err)
	}

	username := config.GetString("username")

	if username == "" {
		user, err := user.Current()
		if err != nil {
			log.Fatal(err)
		}

		if !strings.Contains(user.Username, ".") || strings.Contains(user.Username, "@") {
			fmt.Printf("Sk8s found username %s however that doesn't seem valid.\n", user.Username)
			fmt.Printf("Please provide your corp username, e.g. first.lastname \n\n")
			reader := bufio.NewReader(os.Stdin)
			fmt.Println()
			fmt.Print("Enter Username: ")
			username, _ = reader.ReadString('\n')
			username = strings.TrimSpace(username)
		} else {
			username = user.Username
		}
		config.Set("username", username)
	}

	userNamespace := strings.ReplaceAll(username, ".", "-")

	config.SetDefault("issue-all", "false")
	config.SetDefault("environment", "dev")
	config.SetDefault("previousEnvironment", "devops")
	config.SetDefault("defaultNamespace", userNamespace)

	for k, v := range defaults {
		config.SetDefault(k, v)
	}

	err = config.WriteConfigAs(configFullPath) // Find and write the config file
	if err != nil {                            // Handle errors reading the config file
		panic(fmt.Errorf("Fatal error config file: %s \n", err))
	}
}

// Prepares Cluster Configs files
func SetupClusterConfig(c *viper.Viper, configDir string, configFullPath string, sk8sBucket string) {
	err := os.MkdirAll(configDir, 0755)
	if err != nil {
		fmt.Errorf("Error creating directory: %s", err)
	}

	c.SetConfigName("clusters")
	c.SetConfigType("yaml")
	c.AddConfigPath(configDir)

	err = c.ReadInConfig() // Find and read the config file
	if err != nil {        // Handle errors reading the config file
		fmt.Errorf("Fatal error config file: %s \n", err)
	}

	if _, err := os.Stat(configFullPath); os.IsNotExist(err) {
		emptyFile, err := os.Create(configFullPath)
		if err != nil {
			log.Fatal(err)
		}
		emptyFile.Close()
		ClusterConfigUpdates(c, sk8sBucket)
	}

	// If clusters is empty, reload cluster config
	if c.Get("clusters") == nil {
		glog.Warning("Cluster config appears to be empty, attempting to refetch...")
		ClusterConfigUpdates(c, sk8sBucket)
	}

	// Check if cluster config was pulled in the last 12 hours
	lastUpdate := c.GetTime("last-update")
	nextUpdate := lastUpdate.Add(12 * 60 * time.Minute)
	if nextUpdate.Before(time.Now()) {
		glog.V(8).Infof("Last cluster config update: %s", lastUpdate)
		glog.V(8).Info("Updating now.")
		ClusterConfigUpdates(c, sk8sBucket)
	} else {
		glog.V(8).Infof("Cluster info updated in the last 12 hours, skipping.")
	}

	// Warn user if cluster config is older than 30 days
	nextUpdate = lastUpdate.Add(30 * 24 * 60 * time.Minute)
	if nextUpdate.Before(time.Now()) {
		glog.Warningf("Warning: Cluster config is older than 30 days. Please check your VPN connection to ensure you're getting proper updates.")
	}

	err = c.WriteConfigAs(configFullPath) // Find and write the config file
	if err != nil {                       // Handle errors reading the config file
		panic(fmt.Errorf("Fatal error config file: %s \n", err))
	}
}

// Returns the issuer for a given environment
func GetIssuer(c *viper.Viper, environment string) (string, error) {
	environments := GetEnvironments(c)
	for _, v := range environments {
		glog.V(8).Infof("Checking issuer: %v", v.URL)
		if v.Name == environment {
			glog.V(8).Infof("Found issuer: %v", v.URL)
			return v.URL, nil
		}
	}
	err := errors.Errorf("Issuer does not exist for selected environment: %v", environment)
	return "", err
}

// Returns the Client ID for a given environment
func GetClientID(c *viper.Viper, environment string) (string, error) {
	environments := GetEnvironments(c)
	for _, v := range environments {
		glog.V(8).Infof("Checking Client ID: %v", v.URL)
		if v.Name == environment {
			glog.V(8).Infof("Found Client ID: %v", v.URL)
			return v.ClientID, nil
		}
	}

	err := errors.Errorf("Client ID does not exist for selected environment: %v", environment)
	return "", err
}

// Returns the Client Secret for a given environment
func GetClientSecret(c *viper.Viper, environment string) *string {
	environments := GetEnvironments(c)
	for _, v := range environments {
		glog.V(8).Infof("Checking Client ID: %v", v.URL)
		if v.Name == environment {
			glog.V(8).Infof("Found ClientSecret for  ID: %v", v.URL)
			return &v.ClientSecret
		}
	}

	glog.Errorf("Client ID does not exist for selected environment: %v", environment)
	return nil
}

// Returns the current namespace or "default"
func GetNamespace(config *clientcmdapi.Config) (string) {
	context := GetContext(config)
	if context == "" {
		return "default"
	}
	namespace := config.Contexts[context].Namespace
	if namespace == "" {
		return "default"
	} else {
		return namespace
	}
}

// Returns the current contextGetNamespace
func GetContext(config *clientcmdapi.Config) string {
	return config.CurrentContext
}
