package helper

import (
	"github.com/golang/glog"
	"github.com/spf13/viper"
)

// Cluster config values for a cluster
type Cluster struct {
	Name             string `json:"name"`
	Server           string `json:"server"`
	Issuer           string `json:"issuer"`
	PublicCert       string `json:"publicCert,omitempty"`
	DefaultNamespace bool   `json:"defaultNamespae,omitempty"`
}

func GetClusters(v *viper.Viper) []Cluster {
	var clusters []Cluster

	err := v.UnmarshalKey("clusters", &clusters)
	if err != nil {
		glog.Errorf("Error unmarshaling cluster config: %v", err)
	}

	return clusters
}
