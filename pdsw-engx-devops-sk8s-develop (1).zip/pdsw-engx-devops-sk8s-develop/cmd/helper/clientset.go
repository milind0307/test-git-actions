package helper

import (
	"os"
	"os/user"
	"path/filepath"

	"github.com/golang/glog"

	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/tools/clientcmd"

	_ "k8s.io/client-go/plugin/pkg/client/auth/oidc"
)

// GetClientSet generates and returns a kubernetes clientset based on a user's kubeconfig.
func GetClientSet(kubeConfigPath string) kubernetes.Interface {
	if kubeConfigPath == "" {
		usr, err := user.Current()
		if err != nil {
			glog.Errorf("Could not determine current user: %v\n", err)
			os.Exit(1)
		}
		kubeConfigPath = filepath.Join(usr.HomeDir, ".kube", "config")
	}

	// use the current context in kubeconfig
	config, err := clientcmd.BuildConfigFromFlags("", kubeConfigPath)
	if err != nil {
		panic(err.Error())
	}

	// create the clientset
	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		panic(err.Error())
	}

	return clientset
}
