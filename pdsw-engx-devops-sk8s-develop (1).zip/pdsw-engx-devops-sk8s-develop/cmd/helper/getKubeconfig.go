package helper

import (
	"os"
	"os/user"
	"path/filepath"

	"github.com/golang/glog"
	"github.com/pkg/errors"
	"k8s.io/client-go/tools/clientcmd"
	clientcmdapi "k8s.io/client-go/tools/clientcmd/api"
)

func GetKubeConfig(kubeConfig string) (*clientcmdapi.Config, error) {
	var kubeConfigPath string
	if kubeConfig == "" {
		usr, err := user.Current()
		if err != nil {
			glog.Errorf("Could not determine current user: %v\n", err)
			os.Exit(1)
		}
		kubeConfigPath = filepath.Join(usr.HomeDir, ".kube", "config")
	} else {
		kubeConfigPath = kubeConfig
	}

	if !fileExists(kubeConfigPath) {
		error := errors.Errorf("Error: Kubeconfig does not exist at: ", kubeConfigPath)
		return &clientcmdapi.Config{}, error
	}

	config, err := clientcmd.LoadFromFile(kubeConfigPath)
	if err != nil {
		glog.Fatal(err)
	}
	return config, nil
}

// Check if a file exists and is not a directory
func fileExists(filename string) bool {
    info, err := os.Stat(filename)
    if os.IsNotExist(err) {
        return false
    }
    return !info.IsDir()
}