package helper

import (
	"encoding/base64"

	"github.com/golang/glog"
	"github.com/spf13/viper"
	clientcmdapi "k8s.io/client-go/tools/clientcmd/api"
)

func GenerateClusters(c *viper.Viper, environment string) map[string]*clientcmdapi.Cluster {
	m := make(map[string]*clientcmdapi.Cluster)

	clusters := GetClusters(c)

	for _, cluster := range clusters {
		if cluster.Issuer == environment {
			m[cluster.Name] = &clientcmdapi.Cluster{
				Server:                   cluster.Server,
				CertificateAuthorityData: decodeCert(cluster.PublicCert),
			}
		}
	}
	return m
}

func decodeCert(c string) []byte {
	glog.V(8).Info("Decoding cert")

	data, err := base64.StdEncoding.DecodeString(c)

	if err != nil {
		glog.Error("Error decoding client secret", err)
	}
	return data
}

func GenerateContexts(clusterConfig *viper.Viper, sk8sConfig *viper.Viper, environment string, authName string) map[string]*clientcmdapi.Context {
	contexts := make(map[string]*clientcmdapi.Context)
	clusters := GetClusters(clusterConfig)

	for _, cluster := range clusters {
		if cluster.Issuer == environment {
			contexts[cluster.Name] = &clientcmdapi.Context{
				Cluster:  cluster.Name,
				AuthInfo: authName,
			}
			defaultNamespace := sk8sConfig.GetString("defaultNamespace")
			if defaultNamespace != "" && cluster.DefaultNamespace {
				contexts[cluster.Name].Namespace = defaultNamespace
			}
		}
	}
	return contexts
}
