package helper

import (
	"fmt"

	"github.com/fatih/color"
)

// PrintHelper helps format values with color
func PrintHelper(status string, value string, additionalContent string) {
	if status == "pass" {
		color.Green("%s - %s\n", checkmark(), value)
	} else if status == "warn" {
		color.Yellow("%s - %s\n", checkmark(), value)
	} else if status == "fail" {
		color.Red("%s - %s\n", xmark(), value)
	} else if status == "skip" {
		color.Yellow("%s - %s\n", checkmark(), value)
	} else if status == "info" {
		color.White("%s - %s\n", checkmark(), value)
	} else {
		color.Red("%s - %s\n", xmark(), value)
	}

	if additionalContent != "" {
		fmt.Printf("%s", additionalContent)
	}
}

func checkmark() string {
	return "\u2713"
}

func xmark() string {
	return "\u2717"
}
