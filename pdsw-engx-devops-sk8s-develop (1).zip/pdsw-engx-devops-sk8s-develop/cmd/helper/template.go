package helper

import (
	"encoding/json"
	"html/template"
	"net/http"
	"strings"

	"github.com/gobuffalo/packr/v2"
	"github.com/golang/glog"
	"github.com/jmoiron/jsonq"
)

var indexTmpl = template.Must(template.New("index.html").Parse(`<html>
  <body>
    <form action="/login" method="post">
       <p>
         Authenticate for:<input type="text" name="cross_client" placeholder="list of client-ids">
       </p>
       <p>
         Extra scopes:<input type="text" name="extra_scopes" placeholder="list of scopes">
       </p>
	   <p>
	     Request offline access:<input type="checkbox" name="offline_access" value="yes" checked>
       </p>
       <input type="submit" value="Login">
    </form>
  </body>
</html>`))

func renderIndex(w http.ResponseWriter) {
	renderTemplate(w, indexTmpl, nil)
}

type tokenTmplData struct {
	IDToken      string
	RefreshToken string
	RedirectURL  string
	Claims       string
	Name         string
	Environment  string
}

func RenderToken(w http.ResponseWriter, redirectURL, idToken, refreshToken string, claims []byte, environment string) {
	data := map[string]interface{}{}
	dec := json.NewDecoder(strings.NewReader(string(claims)))
	dec.Decode(&data)
	jq := jsonq.NewQuery(data)

	name, _ := jq.String("name")

	box := packr.New("templates", "../templates")
	index, err := box.FindString("index.html")
	tokenTmpl := template.Must(template.New("index.html").Parse(index))
	if err != nil {
		glog.Errorf("Error getting template: %v", err)
	}

	renderTemplate(w, tokenTmpl, tokenTmplData{
		IDToken:      idToken,
		RefreshToken: refreshToken,
		RedirectURL:  redirectURL,
		Claims:       string(claims),
		Name:         name,
		Environment:  environment,
	})

}

func renderTemplate(w http.ResponseWriter, tmpl *template.Template, data interface{}) {
	err := tmpl.Execute(w, data)
	if err == nil {
		return
	}

	switch err := err.(type) {
	case *template.Error:
		// An ExecError guarantees that Execute has not written to the underlying reader.
		glog.Infof("Error rendering template %s: %s", tmpl.Name(), err)

		// TODO(ericchiang): replace with better internal server error.
		http.Error(w, "Internal server error", http.StatusInternalServerError)
	default:
		// An error with the underlying write, such as the connection being
		// dropped. Ignore for now.
	}
}
