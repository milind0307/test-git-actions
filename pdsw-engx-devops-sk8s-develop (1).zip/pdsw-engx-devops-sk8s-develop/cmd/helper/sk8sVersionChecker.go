package helper

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"runtime"

	"github.com/golang/glog"
	version "github.com/mcuadros/go-version"
)

func CheckVersion(sk8sVersionURL string, currentVersion string, checkVersionComplete chan bool) {
	resp, err := http.Get(sk8sVersionURL)
	if err != nil {
		glog.Errorf("Unable to check current sk8s version url: %v", err)
	}

	if resp.StatusCode == 403 {
		resp.Body.Close()
		return
	}

	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	latestVersion := string(body)

	glog.V(8).Infof("Checking update status against URL: %v", sk8sVersionURL)
	glog.V(8).Infof("   resp: %v", body)
	glog.V(8).Infof("   latestVersion: %v", latestVersion)
	glog.V(8).Infof("   current installed version: %v", string(currentVersion))

	if !isAVersion(version.Normalize(latestVersion)) {
		glog.V(8).Infof("Returned version is not valid:\n%v", latestVersion)
		checkVersionComplete <- true
		return
	}

	upToDate := version.Compare(version.Normalize(latestVersion), version.Normalize(currentVersion), "<=")
	if !upToDate {
		fmt.Println("+-----------------------------------------------------------+")
		fmt.Println("Your version of Sk8s is out of date.\n")
		fmt.Printf("Current version: %s\n", currentVersion)
		fmt.Printf("Latest version: %s\n", latestVersion)
		fmt.Println("To ensure Sk8s continues to work as planned, please update!")
		fmt.Println("\n https://github.com/Sonos-Inc/pdsw-engx-devops-sk8s\n")
		if runtime.GOOS == "darwin" {
			fmt.Println("We're in the process of migrating from our one off brew install to")
			fmt.Println("taps with automatic updating.\n")
			fmt.Println("Please uninstall sk8s and reinstall with our tap by run the following:\n")
			fmt.Println("$ brew uninstall sk8s && brew install Sonos-Inc/homebrew-pdsw-devops/sk8s\n")
			fmt.Println("In the future, you'll be able upgrade in standard brew fashion:")
			fmt.Println("\n$ brew upgrade Sonos-Inc/homebrew-pdsw-devops/sk8s\n")
			fmt.Println("Or even:")
			fmt.Println("\n$ brew upgrade\n")

		}
		fmt.Println("+-----------------------------------------------------------+\n")
	}

	checkVersionComplete <- true
}

func isAVersion(latestVersion string) bool {
	versionConstraint := version.NewConstrainGroupFromString(">0.0.0")
	return versionConstraint.Match(latestVersion)
}
