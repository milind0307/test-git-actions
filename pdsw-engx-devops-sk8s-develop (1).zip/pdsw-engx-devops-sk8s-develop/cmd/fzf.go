package cmd

import (
	"fmt"
	"os"
	"os/user"
	"path/filepath"

	"github.com/Sonos-Inc/pdsw-engx-devops-sk8s/cmd/helper"
	"github.com/golang/glog"
	"github.com/ktr0731/go-fuzzyfinder"
	"github.com/spf13/cobra"
	"k8s.io/client-go/tools/clientcmd"
)

type clusterFzf struct {
	Name    string
	Env     string
	Current bool
}

func init() {
	rootCmd.AddCommand(fzfCmd)
}

var fzfCmd = &cobra.Command{
	Use:     "find",
	Aliases: []string{"f"},
	Short:   "Fuzzyfinder to switch context and Sk8s environment",
	Long: `Fuzzyfinder to switch kubectl context and Sk8s environment

This command will log in for you to the Sk8s environment corresponding to
the context you switch to.`,
	Run: func(cmd *cobra.Command, args []string) {
		fzfClusters(getClusters(helper.GetClusters(c.clusterConfig)), cmd, args)
	},
}

func getClusters(clusters []helper.Cluster) []clusterFzf {
	var clustersWithEnv []clusterFzf
	kubeconfig, err := helper.GetKubeConfig(c.kubeConfigPath)
	if err != nil {
		glog.Errorf("Could not determine current context: %v\n", err)
	}
	currentContext := helper.GetContext(kubeconfig)
	for _, cluster := range clusters {
		var newCluster clusterFzf
		newCluster.Name = cluster.Name
		newCluster.Env = cluster.Issuer
		if currentContext == cluster.Name {
			newCluster.Current = true
		}
		clustersWithEnv = append(clustersWithEnv, newCluster)
	}
	return clustersWithEnv
}

func fzfClusters(clusters []clusterFzf, cmd *cobra.Command, args []string) {
	idx, err := fuzzyfinder.Find(
		clusters,
		func(i int) string {
			if clusters[i].Current {
				return fmt.Sprintf("%s - %s (current)", clusters[i].Name, clusters[i].Env)
			}
			return fmt.Sprintf("%s - %s", clusters[i].Name, clusters[i].Env)
		}, fuzzyfinder.WithPromptString("Select your environment to login: "))
	if err != nil {
		glog.Fatal(err)
	}
	fmt.Printf("Switching context to %s - %s\n", clusters[idx].Name, clusters[idx].Env)
	currentEnvironment := c.sk8sConfig.Get("environment")

	nextEnvironment := helper.GetNextEnvironment([]string{clusters[idx].Env}, c.sk8sConfig.GetString("previousEnvironment"))

	c.environment = nextEnvironment
	c.clientID, err = helper.GetClientID(c.clusterConfig, c.environment)
	if err != nil {
		glog.Errorf("Error: %v\n", err)
		glog.Errorln("Please confirm you've selected a configured environment.")
		glog.Errorln("You can list environments by running: sk8s environments")
		os.Exit(1)
	}
	issuer, err := helper.GetIssuer(c.clusterConfig, c.environment)
	if err != nil {
		glog.Fatalf("Error: %v", err)
	}
	c.issuerURL = issuer

	// Write config after all other calls succeed
	c.sk8sConfig.Set("environment", nextEnvironment)
	c.sk8sConfig.Set("previousEnvironment", currentEnvironment)
	c.sk8sConfig.WriteConfig()

	if err = login(cmd, nil); err != nil {
		glog.Errorf("Error: %v", err)
		os.Exit(1)
	}
	var kubeConfigPath string
	if c.kubeConfigPath == "" {
		usr, err := user.Current()
		if err != nil {
			glog.Errorf("Could not determine current user: %v\n", err)
			os.Exit(1)
		}
		kubeConfigPath = filepath.Join(usr.HomeDir, ".kube", "config")
	} else {
		kubeConfigPath = c.kubeConfigPath
	}
	kubeConfig, _ := helper.GetKubeConfig(kubeConfigPath)
	kubeConfig.CurrentContext = clusters[idx].Name
	if err := clientcmd.WriteToFile(*kubeConfig, kubeConfigPath); err != nil {
		glog.Fatal(err)
	}
}
