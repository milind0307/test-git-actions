package cmd

import (
	"fmt"

	"github.com/golang/glog"

	"github.com/spf13/cobra"
)

const (
	VERSION = "v1.13.2"
)

var quiet bool

func init() {
	rootCmd.AddCommand(versionCmd)
	versionCmd.Flags().BoolVarP(&quiet, "quiet", "q", false, "to turn off all other output except version")
}

var versionCmd = &cobra.Command{
	Use:   "version",
	Short: "Print the version number of Sk8s",
	Long:  `All software has versions. This is Sk8s's`,
	Run: func(cmd *cobra.Command, args []string) {
		if quiet {
			fmt.Println(VERSION)
		} else {
			glog.Info("Sk8s ", VERSION)
		}
	},
}

func GetVersion() string {
	return VERSION
}
