package cmd

import (
	"fmt"

	"github.com/Sonos-Inc/pdsw-engx-devops-sk8s/cmd/helper"
	"github.com/golang/glog"
	"github.com/spf13/cobra"
)

func init() {
	setCmd.AddCommand(setEnvironmentCmd)
}

var setEnvironmentCmd = &cobra.Command{
	Use:   "environment",
	Short: "set environment config value",
	Long:  "Sets environment config value",
	Run: func(cmd *cobra.Command, args []string) {
		if len(args) < 1 {
			glog.Error("No arguments supplied, please include environment name")
			return
		}
		currentEnvironment := c.environment
		setEnvironment := args[0]
		availableEnvironments := helper.GetEnvironments(c.clusterConfig)
		for _, v := range availableEnvironments {
			if v.Name == setEnvironment {
				fmt.Printf("Environment set: %s\n", setEnvironment)
				c.sk8sConfig.Set("environment", setEnvironment)
				c.sk8sConfig.Set("previousEnvironment", currentEnvironment)
				c.sk8sConfig.WriteConfig()
				return
			}
		}

		fmt.Println("Environment not found.")
	},
}
