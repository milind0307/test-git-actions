package doctortests

import (
	"context"
	"fmt"
	"strings"

	"github.com/Sonos-Inc/pdsw-engx-devops-sk8s/cmd/helper"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"

	// Necessary for k8s client
	_ "k8s.io/client-go/plugin/pkg/client/auth/oidc"
)

// RunPodTests orchestrates running doctor tests based around pods
func RunPodTests(kubeConfigPath string, namespace string, pod string) {
	clientset := helper.GetClientSet(kubeConfigPath)

	fmt.Printf("\n# Pod Tests\n\n")

	fmt.Printf("## Pod State\n")
	helper.PrintHelper(podTestIfStarted(clientset, namespace, pod))
	helper.PrintHelper(podTestLastState(clientset, namespace, pod))
	helper.PrintHelper(podTestReadinessProbes(clientset, namespace, pod))

	fmt.Printf("## Pod Resources\n")
	helper.PrintHelper(podTestIfResourcesSet(clientset, namespace, pod))

	fmt.Printf("\n## Pod Annotations\n")
	helper.PrintHelper(podTestIfKiamAnnotationSet(clientset, namespace, pod))

	fmt.Printf("\n")
}

func podTestIfStarted(clientset kubernetes.Interface, namespace string, pod string) (string, string, string) {
	podObj, err := clientset.CoreV1().Pods(namespace).Get(context.TODO(), pod, metav1.GetOptions{})
	if err != nil {
		panic(err.Error())
	}

	if podObj.Status.Phase == "Running" {
		return "pass", fmt.Sprintf("Pod has started"), ""
	} else if podObj.Status.Phase == "Succeeded" {
		return "pass", fmt.Sprintf("Pod has already run and has Succeeded"), ""
	} else if podObj.Status.Phase == "Pending" {
		return "warn", fmt.Sprintf("Pod is Pending and has not started"), ""
	}
	return "fail", fmt.Sprintf("Pod is not running. Pod Status: %s", podObj.Status.Phase), ""
}

func podTestLastState(clientset kubernetes.Interface, namespace string, pod string) (string, string, string) {
	podObj, err := clientset.CoreV1().Pods(namespace).Get(context.TODO(), pod, metav1.GetOptions{})
	if err != nil {
		panic(err.Error())
	}

	if podObj.Status.Phase == "Running" {
		return "pass", fmt.Sprintf("Pod Last State - %s", podObj.Status.Phase), ""
	} else if podObj.Status.Phase == "Succeeded" {
		return "pass", fmt.Sprintf("Pod Last State - %s", podObj.Status.Phase), ""
	} else if podObj.Status.Phase == "Pending" {
		return "warn", fmt.Sprintf("Pod Last State - %s", podObj.Status.Phase), fmt.Sprintf("    Start Time: %s\n", podObj.Status.StartTime)
	}
	return "fail", fmt.Sprintf("Pod Last State - %s", podObj.Status.Phase), fmt.Sprintf("    Reason: %s\n    Message: %s\n    Start Time: %s\n", podObj.Status.Reason, podObj.Status.Message, podObj.Status.StartTime)
}

func podTestReadinessProbes(clientset kubernetes.Interface, namespace string, pod string) (string, string, string) {
	podObj, err := clientset.CoreV1().Pods(namespace).Get(context.TODO(), pod, metav1.GetOptions{})
	if err != nil {
		panic(err.Error())
	}

	var containers = ""
	var ready = true
	for _, container := range podObj.Status.ContainerStatuses {
		if !container.Ready {
			ready = false
		}
		var lastTerminationState string
		if container.LastTerminationState.Waiting != nil {
			lastTerminationState = container.LastTerminationState.Waiting.String()
		} else if container.LastTerminationState.Running != nil {
			lastTerminationState = container.LastTerminationState.Running.String()
		} else if container.LastTerminationState.Terminated != nil {
			lastTerminationState = container.LastTerminationState.Terminated.String()
		} else {
			lastTerminationState = "null"
		}

		containers = containers + fmt.Sprintf("    Name: %s\n    Ready: %t\n    LastTerminationState: %s\n    Restart Count: %d\n\n", container.Name, container.Ready, lastTerminationState, container.RestartCount)
	}
	if containers == "" {
		return "warn", fmt.Sprintf("No readiness checks found."), ""
	}
	if ready {
		return "pass", fmt.Sprintf("All containers are passing readiness probes"), fmt.Sprintf("%s", containers)
	}
	return "fail", fmt.Sprintf("Not all containers in this pod are passing readiness probes"), fmt.Sprintf("%s", containers)
}

func podTestIfResourcesSet(clientset kubernetes.Interface, namespace string, pod string) (string, string, string) {
	podObj, err := clientset.CoreV1().Pods(namespace).Get(context.TODO(), pod, metav1.GetOptions{})
	if err != nil {
		panic(err.Error())
	}

	var violatingContainers []string
	for _, container := range podObj.Spec.Containers {
		if len(container.Resources.Limits) == 0 || len(container.Resources.Requests) == 0 {
			violatingContainers = append(violatingContainers, container.Name)
		}
	}
	if len(violatingContainers) == 0 {
		return "pass", fmt.Sprintf("Pod resources defined"), ""
	}
	return "fail", fmt.Sprintf("Pod has containers missing resources"), fmt.Sprintf("    Violating Containers: %s\n", violatingContainers)
}

func podTestIfKiamAnnotationSet(clientset kubernetes.Interface, namespace string, pod string) (string, string, string) {
	podObj, err := clientset.CoreV1().Pods(namespace).Get(context.TODO(), pod, metav1.GetOptions{})
	if err != nil {
		panic(err.Error())
	}

	for k, v := range podObj.ObjectMeta.Annotations {
		if strings.Contains(k, "iam") {
			if strings.Contains(k, "iam.amazonaws.com/role") {
				// Annotation verified, ensure that the role matches
				return "pass", fmt.Sprintf("kiam Annotation Found"), fmt.Sprintf("    If you are still encountering AWS access problems, ensure that the AWS role '%s' is valid, and that your namespace is annotated\n", v)
			}
			// Invalid annotation, ensure follows format
			return "fail", fmt.Sprintf("Invalid kiam annotation formatting"), fmt.Sprintf("    Ensure your pod annotation follows the format 'iam.amazonaws.com/role:<aws_role>'\n")
		}
	}

	// No annotation found
	return "warn", fmt.Sprintf("No annotation was found"), fmt.Sprintf("    If an annotation is required, annotate your pod with 'iam.amazonaws.com/role:<aws_role>'")
}
