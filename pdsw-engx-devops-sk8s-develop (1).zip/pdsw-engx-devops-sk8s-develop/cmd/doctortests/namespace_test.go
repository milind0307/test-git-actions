package doctortests

import (
	"fmt"
	"testing"

	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/kubernetes/fake"
)

func Test_namespaceTestIfkiamAnnotationSet(t *testing.T) {
	type args struct {
		clientset      kubernetes.Interface
		inputNamespace string
		inputPod       string
		err            error
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "Test namespace is not annotated",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Namespace{
						ObjectMeta: metav1.ObjectMeta{
							Name:        "exampleNamespace",
							Annotations: map[string]string{},
						},
					}),
				inputNamespace: "exampleNamespace",
				inputPod:       "examplePod",
			},
			want: "No annotation was found",
		},
		{
			name: "Test namespace has an invalid annotation",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Namespace{
						ObjectMeta: metav1.ObjectMeta{
							Name: "exampleNamespace",
							Annotations: map[string]string{
								"iam.amazonaws.com/permit": ".*",
							},
						},
					}),
				inputNamespace: "exampleNamespace",
				inputPod:       "examplePod",
			},
			want: "Invalid kiam annotation formatting",
		},
		{
			name: "Test namespace has a valid annotation",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Namespace{
						ObjectMeta: metav1.ObjectMeta{
							Name: "exampleNamespace",
							Annotations: map[string]string{
								"iam.amazonaws.com/permitted": ".*",
							},
						},
					}),
				inputNamespace: "exampleNamespace",
				inputPod:       "examplePod",
			},
			want: "kiam Annotation Found",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			fmt.Println(namespaceTestIfkiamAnnotationSet(tt.args.clientset, tt.args.inputNamespace, tt.args.inputPod))
			if _, got, _ := namespaceTestIfkiamAnnotationSet(tt.args.clientset, tt.args.inputNamespace, tt.args.inputPod); got != tt.want {
				t.Errorf("namespaceTestIfkiamAnnotationSet() = %v, want %v", got, tt.want)
			}
		})
	}
}
