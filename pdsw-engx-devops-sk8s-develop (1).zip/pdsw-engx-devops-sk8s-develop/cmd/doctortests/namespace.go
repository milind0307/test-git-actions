package doctortests

import (
	"context"
	"fmt"
	"strings"

	"github.com/Sonos-Inc/pdsw-engx-devops-sk8s/cmd/helper"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"

	// Necessary for k8s client
	_ "k8s.io/client-go/plugin/pkg/client/auth/oidc"
)

// RunNamespaceTests orchestrates running doctor tests based around namespaces
func RunNamespaceTests(kubeConfigPath string, namespace string, pod string) {
	clientset := helper.GetClientSet(kubeConfigPath)

	fmt.Printf("\n# Namespace Tests\n\n")

	fmt.Printf("## kiam Annotation\n")
	helper.PrintHelper(namespaceTestIfkiamAnnotationSet(clientset, namespace, pod))

	fmt.Printf("\n")
}

func namespaceTestIfkiamAnnotationSet(clientset kubernetes.Interface, namespace string, pod string) (string, string, string) {
	namespaceObj, err := clientset.CoreV1().Namespaces().Get(context.TODO(), namespace, metav1.GetOptions{})
	if err != nil {
		panic(err.Error())
	}

	for k, v := range namespaceObj.ObjectMeta.Annotations {
		if strings.Contains(k, "iam") {
			if strings.Contains(k, "iam.amazonaws.com/permitted") {
				// Annotation verified, ensure that the role matches
				return "pass", fmt.Sprintf("kiam Annotation Found"), fmt.Sprintf("    If you are still encountering AWS access problems, ensure that the AWS role '%s' is valid\n", v)
			}
			// Invalid annotation, ensure follows format
			return "fail", fmt.Sprintf("Invalid kiam annotation formatting"), fmt.Sprintf("    Ensure your namespace annotation follows the format 'iam.amazonaws.com/permitted:<aws_role>'\n")
		}
	}

	// No annotation found
	return "warn", fmt.Sprintf("No annotation was found"), fmt.Sprintf("    If an annotation is required, annotate your namespace with 'iam.amazonaws.com/permitted:<aws_role>'")
}
