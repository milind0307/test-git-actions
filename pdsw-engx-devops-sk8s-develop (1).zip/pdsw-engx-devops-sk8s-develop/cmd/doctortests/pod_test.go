package doctortests

import (
	"fmt"
	"testing"

	v1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/kubernetes/fake"
)

func Test_podTestIfStarted(t *testing.T) {
	type args struct {
		clientset      kubernetes.Interface
		inputNamespace string
		inputPod       string
		err            error
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "Test Pod has Started",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Pod{
						ObjectMeta: metav1.ObjectMeta{
							Name:        "examplePod",
							Namespace:   "default",
							Annotations: map[string]string{},
						},
						Status: v1.PodStatus{
							Phase: "Running",
						},
					}),
				inputNamespace: "default",
				inputPod:       "examplePod",
			},
			want: "Pod has started",
		},
		{
			name: "Test Pod has Succeeded",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Pod{
						ObjectMeta: metav1.ObjectMeta{
							Name:        "examplePod",
							Namespace:   "default",
							Annotations: map[string]string{},
						},
						Status: v1.PodStatus{
							Phase: "Succeeded",
						},
					}),
				inputNamespace: "default",
				inputPod:       "examplePod",
			},
			want: "Pod has already run and has Succeeded",
		},
		{
			name: "Test Pod is Pending",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Pod{
						ObjectMeta: metav1.ObjectMeta{
							Name:        "examplePod",
							Namespace:   "default",
							Annotations: map[string]string{},
						},
						Status: v1.PodStatus{
							Phase: "Pending",
						},
					}),
				inputNamespace: "default",
				inputPod:       "examplePod",
			},
			want: "Pod is Pending and has not started",
		},
		{
			name: "Test Pod is not Running",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Pod{
						ObjectMeta: metav1.ObjectMeta{
							Name:        "examplePod",
							Namespace:   "default",
							Annotations: map[string]string{},
						},
						Status: v1.PodStatus{
							Phase: "Failed",
						},
					}),
				inputNamespace: "default",
				inputPod:       "examplePod",
			},
			want: "Pod is not running. Pod Status: Failed",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			fmt.Println(podTestIfStarted(tt.args.clientset, tt.args.inputNamespace, tt.args.inputPod))
			if _, got, _ := podTestIfStarted(tt.args.clientset, tt.args.inputNamespace, tt.args.inputPod); got != tt.want {
				t.Errorf("podTestIfStarted() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_podTestLastState(t *testing.T) {
	type args struct {
		clientset      kubernetes.Interface
		inputNamespace string
		inputPod       string
		err            error
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "Test Pod is Running",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Pod{
						ObjectMeta: metav1.ObjectMeta{
							Name:        "examplePod",
							Namespace:   "default",
							Annotations: map[string]string{},
						},
						Status: v1.PodStatus{
							Phase: "Running",
						},
					}),
				inputNamespace: "default",
				inputPod:       "examplePod",
			},
			want: "Pod Last State - Running",
		},
		{
			name: "Test Pod has Succeeded",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Pod{
						ObjectMeta: metav1.ObjectMeta{
							Name:        "examplePod",
							Namespace:   "default",
							Annotations: map[string]string{},
						},
						Status: v1.PodStatus{
							Phase: "Succeeded",
						},
					}),
				inputNamespace: "default",
				inputPod:       "examplePod",
			},
			want: "Pod Last State - Succeeded",
		},
		{
			name: "Test Pod is Pending",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Pod{
						ObjectMeta: metav1.ObjectMeta{
							Name:        "examplePod",
							Namespace:   "default",
							Annotations: map[string]string{},
						},
						Status: v1.PodStatus{
							Phase: "Pending",
						},
					}),
				inputNamespace: "default",
				inputPod:       "examplePod",
			},
			want: "Pod Last State - Pending",
		},
		{
			name: "Test Pod is Failing",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Pod{
						ObjectMeta: metav1.ObjectMeta{
							Name:        "examplePod",
							Namespace:   "default",
							Annotations: map[string]string{},
						},
						Status: v1.PodStatus{
							Phase: "Failed",
						},
					}),
				inputNamespace: "default",
				inputPod:       "examplePod",
			},
			want: "Pod Last State - Failed",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			fmt.Println(podTestLastState(tt.args.clientset, tt.args.inputNamespace, tt.args.inputPod))
			if _, got, _ := podTestLastState(tt.args.clientset, tt.args.inputNamespace, tt.args.inputPod); got != tt.want {
				t.Errorf("podTestLastState() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_podTestReadinessProbes(t *testing.T) {
	type args struct {
		clientset      kubernetes.Interface
		inputNamespace string
		inputPod       string
		err            error
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "Test Pod is Passing Readiness Probes",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Pod{
						ObjectMeta: metav1.ObjectMeta{
							Name:        "examplePod",
							Namespace:   "default",
							Annotations: map[string]string{},
						},
						Status: v1.PodStatus{
							ContainerStatuses: []v1.ContainerStatus{
								{
									Name:                 "exampleContainer1",
									LastTerminationState: v1.ContainerState{},
									Ready:                true,
									RestartCount:         0,
								},
								{
									Name:                 "exampleContainer2",
									LastTerminationState: v1.ContainerState{},
									Ready:                true,
									RestartCount:         1,
								},
							},
						},
					}),
				inputNamespace: "default",
				inputPod:       "examplePod",
			},
			want: "All containers are passing readiness probes",
		},
		{
			name: "Test Pod is Passing Readiness Probes with all termination states",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Pod{
						ObjectMeta: metav1.ObjectMeta{
							Name:        "examplePod",
							Namespace:   "default",
							Annotations: map[string]string{},
						},
						Status: v1.PodStatus{
							ContainerStatuses: []v1.ContainerStatus{
								{
									Name: "exampleContainer1",
									LastTerminationState: v1.ContainerState{
										Waiting: &v1.ContainerStateWaiting{},
									},
									Ready:        true,
									RestartCount: 0,
								},
								{
									Name: "exampleContainer2",
									LastTerminationState: v1.ContainerState{
										Running: &v1.ContainerStateRunning{},
									},
									Ready:        true,
									RestartCount: 1,
								},
								{
									Name: "exampleContainer2",
									LastTerminationState: v1.ContainerState{
										Terminated: &v1.ContainerStateTerminated{},
									},
									Ready:        true,
									RestartCount: 0,
								},
							},
						},
					}),
				inputNamespace: "default",
				inputPod:       "examplePod",
			},
			want: "All containers are passing readiness probes",
		},
		{
			name: "Test Pod has a container that isn't passing Readiness Probes",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Pod{
						ObjectMeta: metav1.ObjectMeta{
							Name:        "examplePod",
							Namespace:   "default",
							Annotations: map[string]string{},
						},
						Status: v1.PodStatus{
							ContainerStatuses: []v1.ContainerStatus{
								{
									Name:                 "exampleContainer1",
									LastTerminationState: v1.ContainerState{},
									Ready:                true,
									RestartCount:         0,
								},
								{
									Name:                 "exampleContainer2",
									LastTerminationState: v1.ContainerState{},
									Ready:                false,
									RestartCount:         1,
								},
							},
						},
					}),
				inputNamespace: "default",
				inputPod:       "examplePod",
			},
			want: "Not all containers in this pod are passing readiness probes",
		},
		{
			name: "Test Pod has no containers",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Pod{
						ObjectMeta: metav1.ObjectMeta{
							Name:        "examplePod",
							Namespace:   "default",
							Annotations: map[string]string{},
						},
						Status: v1.PodStatus{
							ContainerStatuses: []v1.ContainerStatus{},
						},
					}),
				inputNamespace: "default",
				inputPod:       "examplePod",
			},
			want: "No readiness checks found.",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			fmt.Println(podTestReadinessProbes(tt.args.clientset, tt.args.inputNamespace, tt.args.inputPod))
			if _, got, _ := podTestReadinessProbes(tt.args.clientset, tt.args.inputNamespace, tt.args.inputPod); got != tt.want {
				t.Errorf("podTestReadinessProbes() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_podTestIfResourcesSet(t *testing.T) {
	type args struct {
		clientset      kubernetes.Interface
		inputNamespace string
		inputPod       string
		err            error
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "Test Pod has resources set",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Pod{
						ObjectMeta: metav1.ObjectMeta{
							Name:        "examplePod",
							Namespace:   "default",
							Annotations: map[string]string{},
						},
						Spec: v1.PodSpec{
							Containers: []v1.Container{
								{
									Name: "exampleContainer",
									Resources: v1.ResourceRequirements{
										Limits: v1.ResourceList{
											"Cpu":    resource.MustParse("1"),
											"Memory": resource.MustParse("1Gi"),
										},
										Requests: v1.ResourceList{
											"Cpu":    resource.MustParse("500m"),
											"Memory": resource.MustParse("500Mi"),
										},
									},
								},
							},
						},
					}),
				inputNamespace: "default",
				inputPod:       "examplePod",
			},
			want: "Pod resources defined",
		},
		{
			name: "Test Pod has resources set",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Pod{
						ObjectMeta: metav1.ObjectMeta{
							Name:        "examplePod",
							Namespace:   "default",
							Annotations: map[string]string{},
						},
						Spec: v1.PodSpec{
							Containers: []v1.Container{
								{
									Name:      "exampleContainer",
									Resources: v1.ResourceRequirements{},
								},
							},
						},
					}),
				inputNamespace: "default",
				inputPod:       "examplePod",
			},
			want: "Pod has containers missing resources",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			fmt.Println(podTestIfResourcesSet(tt.args.clientset, tt.args.inputNamespace, tt.args.inputPod))
			if _, got, _ := podTestIfResourcesSet(tt.args.clientset, tt.args.inputNamespace, tt.args.inputPod); got != tt.want {
				t.Errorf("podTestIfResourcesSet() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_podTestIfKiamAnnotationSet(t *testing.T) {
	type args struct {
		clientset      kubernetes.Interface
		inputNamespace string
		inputPod       string
		err            error
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "Test pod is not annotated",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Pod{
						ObjectMeta: metav1.ObjectMeta{
							Name:        "examplePod",
							Namespace:   "default",
							Annotations: map[string]string{},
						},
					}),
				inputNamespace: "default",
				inputPod:       "examplePod",
			},
			want: "No annotation was found",
		},
		{
			name: "Test pod has an invalid annotation",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Pod{
						ObjectMeta: metav1.ObjectMeta{
							Name:      "examplePod",
							Namespace: "default",
							Annotations: map[string]string{
								"iam.amazonaws.com/permitted": ".*",
							},
						},
					}),
				inputNamespace: "default",
				inputPod:       "examplePod",
			},
			want: "Invalid kiam annotation formatting",
		},
		{
			name: "Test pod has a valid annotation",
			args: args{
				clientset: fake.NewSimpleClientset(
					&v1.Pod{
						ObjectMeta: metav1.ObjectMeta{
							Name:      "examplePod",
							Namespace: "default",
							Annotations: map[string]string{
								"iam.amazonaws.com/role": ".*",
							},
						},
					}),
				inputNamespace: "default",
				inputPod:       "examplePod",
			},
			want: "kiam Annotation Found",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			fmt.Println(podTestIfKiamAnnotationSet(tt.args.clientset, tt.args.inputNamespace, tt.args.inputPod))
			if _, got, _ := podTestIfKiamAnnotationSet(tt.args.clientset, tt.args.inputNamespace, tt.args.inputPod); got != tt.want {
				t.Errorf("podTestIfKiamAnnotationSet() = %v, want %v", got, tt.want)
			}
		})
	}
}
