package cmd

import (
	"fmt"

	"github.com/Sonos-Inc/pdsw-engx-devops-sk8s/cmd/helper"

	"github.com/spf13/cobra"
)

func init() {
	rootCmd.AddCommand(environmentsCmd)
}

var environmentsCmd = &cobra.Command{
	Use:   "environments",
	Short: "lists environments for sk8s to login to",
	Long:  "Lists potential environments/dex issuers for sk8s to authenticate against",
	Run: func(cmd *cobra.Command, args []string) {
		environments := helper.GetEnvironments(c.clusterConfig)
		fmt.Println("Available environments (* = current):")
		for _, v := range environments {
			current := " "
			if v.Name == c.environment {
				current = "*"
			}
			fmt.Printf("%s %s\n", current, v.Name)
		}
	},
}
