# Developing For Sk8s

## Getting Started

First, you need to install golang. If you're running homebrew, it should be as easy as `brew install golang`.
Then clone this repo into your [gopath](https://github.com/golang/go/wiki/GOPATH):

```sh
go get github.com/Sonos-Inc/pdsw-engx-devops-sk8s
```

Make sure to install development dependencies:

```sh
brew bundle
```

Standard go development should work with this repo:

```sh
make
# will output binary to bin/sk8s
```

## Release workflow

Releases are published to s3 and synced into manifests so users/apps can grab specific versions they may want in the future. This is all done through a retro/hacky makefile.

### Automated Releases

Sk8s is automatically released via our [Prow Bot](https://github.com/Sonos-Inc/pdsw-engx-devops-sk8s/blob/8af8e2f8f75afb42c87e74456d2f920021bed3e4/.prow.yaml#L55-L86) when code is merged to main.  This job will automatically add a github check to your merge commit and a link to the job.  Jobs can also be [viewed with filters](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-sk8s&job=post-pdsw-devops-sk8s-release-push) in prow.

Currently this process:

* Cross builds multiple versions of sk8s for available platforms
* Creates manifests for managing versions in s3
* Updates current version file to new version
* Uploads all manifests and release artifacts to s3
* Ensures version is different from currently released version

TODO:

* Automatically bumping the [homebrew formula](https://github.com/Sonos-Inc/homebrew-pdsw-devops/blob/master/Formula/sk8s.rb)

#### How it works

The prow job works the same as the below manual directions however requires a few overrides. These overrides are provided via [the job config](https://github.com/Sonos-Inc/pdsw-engx-devops-sk8s/blob/8af8e2f8f75afb42c87e74456d2f920021bed3e4/.prow.yaml#L55-L86):

```yaml
...
      - name: GOX
        value: go run github.com/mitchellh/gox
      # For testing use something like this:
      - name: BUCKET
        value: 093d2402-1813-11e9-b269-33c14c94eed6\/test
      - name: AWS_REGION
        value: us-east-1
...
  annotations:
    iam.amazonaws.com/role: build.k.do.ws.sonos.com-prow-sk8s
```

* The above configuration replaces the `gox` command with a full `go run` based gox command, since we had issues running gox in the container with pathing issues.
* The bucket is generally defined in [the makefile](https://github.com/Sonos-Inc/pdsw-engx-devops-sk8s/blob/8af8e2f8f75afb42c87e74456d2f920021bed3e4/Makefile#L8-L9) but can be overriden if the user would like to test.
  In the example above, you can override that bucket name with one that includes a path, allowing your deploy to only goto a test folder, not the actual release folder.  Note, these paths need to be escaped via a `\` since they're also used in [a sed command.](https://github.com/Sonos-Inc/pdsw-engx-devops-sk8s/blob/8af8e2f8f75afb42c87e74456d2f920021bed3e4/Makefile#L109-L110)
* Finally, you see an annotation that provides this job access to a role for kiam to provide read and write access tot he included bucket.

### Manual Releases

Manual releases should nto be required in general as mentioned above, Prow should be able to automatically deploy when merged to main.  To begin a manual release, make sure you have a development workflow setup as above and you've changed the version in [version.go](cmd/version.go).

```bash
make release

# Makefile:
# release: check-aws-creds
#   $(MAKE) release-compile
#   $(MAKE) template-brew
#   $(MAKE) release-manifest
#   $(MAKE) all-versions-manifest
#   $(MAKE) release-upload
```

Releasing will include all [gox](https://github.com/mitchellh/gox) supported cross compiled targets.
