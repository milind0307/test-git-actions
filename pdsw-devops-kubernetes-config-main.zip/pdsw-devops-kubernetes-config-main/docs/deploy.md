# Deploying SONOS DevOps Kubernetes

The config repo manages the configruation needed to run the DevOps Team's Kubernetes Clusters. Our clusters are updated using prow. Below is a step by step guide on how this automation works.

## Deploy Workflow

There are two ways a deploy job can get triggered.

Note that this guide will use examples for the `sandbox.k.do.ws.sonos.com` cluster, but is applicable to all other clusters.

### Pre-Upgrade Steps

#### Kubernetes Repo

When a merge is made to develop in the [pdsw-engx-devops-kubernetes](https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes) repo, a job is kicked off which updates the [01.us-east-2.dev.devops.k8s.sonos.com](https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow.yaml#L366-L415) cluster. There is a periodic job that monitors this job. When a successful run of the devops-dev updater completes with a new git SHA, the [periodic version updater job](https://github.com/Sonos-Inc/pdsw-devops-prow/blob/main/jobs/Sonos-Inc/pdsw-devops-kubernetes-config/pdsw-engx-devops-kubernetes-config-periodics.yaml#L2-L62) will run and update an associated [`deployedKubernetesRepoSHA`](https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/7afb1df27405a9121f9a3056daadc1b2b1a21e62/environments/sandbox.k.do.ws.sonos.com/deployedKubernetesRepoSHA) file. A PR will be created in the config repo with this updated git SHA. This will trigger the associated cluster update job on merge into main.

#### Config Repo

Alternatively a change can be made for an associated cluster under `environments/{CLUSTER_NAME}` for that cluster. This will trigger the associated cluster update job on merge into main.

### Upgrade Steps

Either way the cluster config is updated, upon a merge to main will trigger the associated [cluster update](https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/main/.prow.yaml#L114-L172) job. This job will deploy the latest version of the config repo along with the version of the kubernetes repo defined by the `deployedKubernetesRepoSHA`.
