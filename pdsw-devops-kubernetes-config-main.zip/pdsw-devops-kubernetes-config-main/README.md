# pdsw-devops-kubernetes-config

Core Engineering DevOps' Kubernetes cluster configuration

[![GitHub license](https://img.shields.io/badge/license-UNLICENSED-blue.svg?style=for-the-badge)](.//LICENSE)
[![Maintained](https://img.shields.io/badge/Maintained%3F-yes-green.svg?style=for-the-badge)](https://github.com/Sonos-Inc/pdsw-apigee-agproxytool/graphs/commit-activity)

- [pdsw-devops-kubernetes-config](#pdsw-devops-kubernetes-config)
  - [Core Engineering DevOps Kubernetes Configuration](#core-engineering-devops-kubernetes-configuration)
  - [Automation](#automation)
    - [Test Jobs](#test-jobs)
    - [Deploy Jobs](#deploy-jobs)

## Core Engineering DevOps Kubernetes Configuration

This repository contains configuration for Core Engineering DevOps' Kubernetes clusters and configuration/Terraform for managing related AWS account bootstrapping (DNS, S3 bucket, etc.).

The configuration in this repo is used by our automation repo: [pdsw-engx-devops-kubernetes](https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes). See that repo's README for up-to-date information on using this repo.

If you're looking for information that's not found in one of this repo's READMEs, take a look in the [automation repo's docs/ directory](https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/tree/develop/docs).

## Automation

This repo is automated by the devops team's [Prow bot](https://github.com/Sonos-Inc/pdsw-devops-prow).

For more information on interacting with Prow and our pull request process [visit our prow docs](https://github.com/Sonos-Inc/pdsw-devops-prow/blob/main/docs/working_with_prow.md).

Almost all prowjobs for this repo are configured in the [.prow.yaml](/.prow.yaml) file.

### Test Jobs

| Test name                                                  | Trigger         | Prow Link                                                                                                                                                 | Description                                                                             |
| :--------------------------------------------------------- | :-------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------- | :-------------------------------------------------------------------------------------- |
| [presubmit-sonos-kubernetes-config-yamllint]               | Pull Request    | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-devops-kubernetes-config&job=presubmit-sonos-kubernetes-config-yamllint)               | Runs a [yaml lint] against the configurations.                                          |
| [presubmit-sonos-kubernetes-config-cluster-template-lint]  | Pull Request    | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-devops-kubernetes-config&job=presubmit-sonos-kubernetes-config-cluster-template-lint)  | Runs a [helmfile lint] against the each cluster configuration given the current branch. |
| [presubmit-sonos-kubernetes-config-terraform-validate]     | Pull Request    | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-devops-kubernetes-config&job=presubmit-sonos-kubernetes-config-terraform-validate)     | Runs a [terraform validate] against the current configuration.                          |
| [postsubmit-sonos-kubernetes-config-yamllint]              | Merge to main | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-devops-kubernetes-config&job=postsubmit-sonos-kubernetes-config-yamllint)              | Same as presubmit                                                                       |
| [postsubmit-sonos-kubernetes-config-cluster-template-lint] | Merge to main | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-devops-kubernetes-config&job=postsubmit-sonos-kubernetes-config-cluster-template-lint) | Same as presubmit                                                                       |
| [postsubmit-sonos-kubernetes-config-terraform-validate]    | Merge to main | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-devops-kubernetes-config&job=postsubmit-sonos-kubernetes-config-terraform-validate)    | Same as presubmit                                                                       |

<!-- Link Refs -->

[yaml lint]: https://github.com/adrienverge/yamllint
[helmfile lint]: https://github.com/roboll/helmfile#lint
[terraform validate]: https://www.terraform.io/docs/commands/validate.html
[presubmit-sonos-kubernetes-config-yamllint]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/5ecee9d26c4067310cc6e50b0930a20a4350c9d1/.prow.yaml#L4-L16
[presubmit-sonos-kubernetes-config-cluster-template-lint]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/5ecee9d26c4067310cc6e50b0930a20a4350c9d1/.prow.yaml#L18-L38
[presubmit-sonos-kubernetes-config-terraform-validate]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/5ecee9d26c4067310cc6e50b0930a20a4350c9d1/.prow.yaml#L40-L52
[postsubmit-sonos-kubernetes-config-yamllint]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/5ecee9d26c4067310cc6e50b0930a20a4350c9d1/.prow.yaml#L57-L72
[postsubmit-sonos-kubernetes-config-cluster-template-lint]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/5ecee9d26c4067310cc6e50b0930a20a4350c9d1/.prow.yaml#L75-L95
[postsubmit-sonos-kubernetes-config-terraform-validate]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/5ecee9d26c4067310cc6e50b0930a20a4350c9d1/.prow.yaml#L97-L112

### Deploy Jobs

Explanations of how Deploy Jobs work can be found [here](docs/deploy.md).

| Test name                                                           | Trigger                                                                                                                                                                                                                       | Prow Link                                                                                                                                                          | Description                                                                                                                                   |
| :------------------------------------------------------------------ | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------- | :-------------------------------------------------------------------------------------------------------------------------------------------- |
| [postsubmit-sonos-k8s-deploy-sandbox-cluster]                | Change to [sandbox environment][sandbox environment], including the [deployedKubernetesRepoSHA][sandbox deployedkubernetesreposha] (see [here][config deploy automation]) on merge to main                                  | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-devops-kubernetes-config&job=postsubmit-sonos-k8s-deploy-sandbox-cluster)            | Upgrades the sandbox.k.do.ws.sonos.com cluster with the latest kubernetes repo develop & config repo.                                         |
| [postsubmit-sonos-k8s-deploy-build-cluster]                  | Change to [build environment][build environment], including the [deployedKubernetesRepoSHA][build deployedkubernetesreposha] (see [here][config deploy automation]) on merge to main                                        | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-devops-kubernetes-config&job=postsubmit-sonos-k8s-deploy-build-cluster)              | Upgrades the build.k.do.ws.sonos.com cluster with the latest kubernetes repo develop & config repo.                                           |
| [postsubmit-sonos-k8s-deploy-test-cluster]                   | Change to [test environment][test environment], including the [deployedKubernetesRepoSHA][test deployedkubernetesreposha] (see [here][config deploy automation]) on merge to main                                           | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-devops-kubernetes-config&job=postsubmit-sonos-k8s-deploy-test-cluster)               | Upgrades the test.k.do.ws.sonos.com cluster with the latest kubernetes repo develop & config repo.                                            |
| [postsubmit-sonos-k8s-deploy-us-east-1-01-stage-cluster] | Change to [01-us-east-1-stage environment][01-us-east-1-stage environment], including the [deployedKubernetesRepoSHA][01-us-east-1-stage deployedkubernetesreposha] (see [here][config deploy automation]) on merge to main | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-devops-kubernetes-config&job=postsubmit-sonos-k8s-deploy-us-east-1-01-stage-cluster) | Upgrades the 01.us-east-1.stage.k8s.sonos.com cluster with the latest kubernetes repo develop & config repo. |
| [postsubmit-sonos-k8s-deploy-eu-west-1-01-stage-cluster] | Change to [01-eu-west-1-stage environment][01-eu-west-1-stage environment], including the [deployedKubernetesRepoSHA][01-eu-west-1-stage deployedkubernetesreposha] (see [here][config deploy automation]) on merge to main | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-devops-kubernetes-config&job=postsubmit-sonos-k8s-deploy-eu-west-1-01-stage-cluster) | Upgrades the 01.eu-west-1.stage.k8s.sonos.com cluster with the latest kubernetes repo develop & config repo. |
| [postsubmit-sonos-k8s-kubernetes-deploy-tools-cluster] | Change to [tools environment][tools environment], including the [deployedKubernetesRepoSHA][tools deployedkubernetesreposha] (see [here][config deploy automation]) | [Jobs](https://prow.build.k.do.ws.sonos.com/?job=postsubmit-sonos-k8s-kubernetes-deploy-tools-cluster) | Upgrades the tools.k.do.ws.sonos.com cluster with the latest kubernetes repo main & config repo. |
| [postsubmit-sonos-k8s-kubernetes-deploy-us-east-1-prod-cluster] | Change  to [01-us-east-1-prod environment][01-us-east-1-prod environment], including the [deployedKubernetesRepoSHA][01-us-east-1-prod deployedkubernetesreposha] (see [here][config deploy automation]) | [Jobs](https://prow.build.k.do.ws.sonos.com/?job=postsubmit-sonos-k8s-kubernetes-deploy-us-east-1-prod-cluster) | Upgrades the 01.us-east-1.prod.k8s.sonos.com cluster with the latest kubernetes repo main & config repo. |
| [postsubmit-sonos-k8s-kubernetes-deploy-eu-west-1-prod-cluster] | Change to [01-eu-west-1-prod environment][01-eu-west-1-prod environment], including the [deployedKubernetesRepoSHA][01-eu-west-1-prod deployedkubernetesreposha] (see [here][config deploy automation]) | [Jobs](https://prow.build.k.do.ws.sonos.com/?job=postsubmit-sonos-k8s-kubernetes-deploy-eu-west-1-prod-cluster) | Upgrades the 01.eu-west-1.prod.k8s.sonos.com cluster with the latest kubernetes repo main & config repo. |
<!-- Link Refs -->
<!-- sandbox -->
[sandbox environment]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/tree/main/environments/sandbox.k.do.ws.sonos.com
[sandbox deployedkubernetesreposha]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/main/environments/sandbox.k.do.ws.sonos.com/deployedKubernetesRepoSHA
[config deploy automation]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/5ecee9d26c4067310cc6e50b0930a20a4350c9d1/docs/deploy.md
[postsubmit-sonos-k8s-deploy-sandbox-cluster]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/f2a218d8f4a8fcb830fa7cff4438ef70e8598571/.prow.yaml#L117-L187
<!-- build -->
[build environment]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/tree/main/environments/build.k.do.ws.sonos.com
[build deployedkubernetesreposha]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/main/environments/build.k.do.ws.sonos.com/deployedKubernetesRepoSHA
[postsubmit-sonos-k8s-deploy-build-cluster]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/f2a218d8f4a8fcb830fa7cff4438ef70e8598571/.prow.yaml#L192-L259
<!-- test -->
[test environment]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/tree/main/environments/test.k.do.ws.sonos.com
[test deployedkubernetesreposha]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/main/environments/test.k.do.ws.sonos.com/deployedKubernetesRepoSHA
[postsubmit-sonos-k8s-deploy-test-cluster]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/f2a218d8f4a8fcb830fa7cff4438ef70e8598571/.prow.yaml#L264-L334
<!-- 01-us-east-1-stage -->
[01-us-east-1-stage environment]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/tree/main/environments/01.us-east-1.stage.k8s.sonos.com
[01-us-east-1-stage deployedkubernetesreposha]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/main/environments/01.us-east-1.stage.k8s.sonos.com/deployedKubernetesRepoSHA
[postsubmit-sonos-k8s-deploy-us-east-1-01-stage-cluster]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/f2a218d8f4a8fcb830fa7cff4438ef70e8598571/.prow.yaml#L339-L409
<!-- 01-eu-west-1-stage -->
[01-eu-west-1-stage environment]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/tree/main/environments/01.eu-west-1.stage.k8s.sonos.com
[01-eu-west-1-stage deployedkubernetesreposha]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/main/environments/01.eu-west-1.stage.k8s.sonos.com/deployedKubernetesRepoSHA
[postsubmit-sonos-k8s-deploy-eu-west-1-01-stage-cluster]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/f2a218d8f4a8fcb830fa7cff4438ef70e8598571/.prow.yaml#L414-L484
<!-- tools -->
[tools environment]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/tree/main/environments/tools.k.do.ws.sonos.com
[tools deployedkubernetesreposha]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/main/environments/tools.k.do.ws.sonos.com/deployedKubernetesRepoSHA
[postsubmit-sonos-k8s-kubernetes-deploy-tools-cluster]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/f2a218d8f4a8fcb830fa7cff4438ef70e8598571/.prow.yaml#L489-L559
<!-- 01-us-east-1-prod  -->
[01-us-east-1-prod environment]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/tree/main/environments/01.us-east-1.prod.k8s.sonos.com
[01-us-east-1-prod deployedkubernetesreposha]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/main/environments/01.us-east-1.prod.k8s.sonos.com/deployedKubernetesRepoSHA
[postsubmit-sonos-k8s-kubernetes-deploy-us-east-1-prod-cluster]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/f2a218d8f4a8fcb830fa7cff4438ef70e8598571/.prow.yaml#L639-L708
<!-- 01-eu-west-1-prod -->
[01-eu-west-1-prod environment]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/tree/main/environments/01.eu-west-1.prod.k8s.sonos.com
[01-eu-west-1-prod deployedkubernetesreposha]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/main/environments/01.eu-west-1.prod.k8s.sonos.com/deployedKubernetesRepoSHA
[postsubmit-sonos-k8s-kubernetes-deploy-eu-west-1-prod-cluster]: https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/blob/f2a218d8f4a8fcb830fa7cff4438ef70e8598571/.prow.yaml#L564-L634
