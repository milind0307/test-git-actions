---
name: Feature Request
about: Suggest an feature to sonos k8s configuration
labels: kind/feature

---
<!-- Please only use this template for submitting feature requests -->

**What would you like to be added**:

**Why is this needed**:
