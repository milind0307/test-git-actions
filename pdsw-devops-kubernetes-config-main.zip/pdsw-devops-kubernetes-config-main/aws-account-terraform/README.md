# Maintaining and Bootsrapping AWS Accounts for Kubernetes

<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->
**Table of Contents**

- [New Account](#new-account)
  - [Terraform](#terraform)
    - [Prepare](#prepare)
    - [Run](#run)
    - [Commit and PR](#commit-and-pr)
      - [Terraform State](#terraform-state)
      - [Account Config](#account-config)
  - [DNS (Route 53)](#dns-route-53)
    - [Get Nameservers](#get-nameservers)
    - [Add NS Record to `k8s` Zone in Tools Account](#add-ns-record-to-k8s-zone-in-tools-account)
    - [Validate](#validate)
    - [Consider a New OIDC Environment (Issuer)](#consider-a-new-oidc-environment-issuer)
- [Updating Existing Accounts](#updating-existing-accounts)
  - [Terraform Update](#terraform-update)
    - [Run Update](#run-update)
    - [Commit and PR Updated Terraform State](#commit-and-pr-updated-terraform-state)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

## New Account

When using this repo for a Kubernetes cluster in a new AWS account, there are tasks that need to be done once to bootstrap the account.

### Terraform

The account terraform in `aws-account-terraform/` will create the required Kops S3 bucket and a environment-level DNS zone (e.g. `stage.k8s.sonos.com`).

#### Prepare

First you will need to create a new directory:

```shell
$ mkdir /path/to/pdsw-devops-kubernetes-config/cluster/accounts/sonos-<account-name>-<account-id>
```

In that directory create a file `values.yaml`. Here's an example, but we recommend taking a look at current files in this repo rather than relying on this document being updated.

```yaml
kops_bucket: sonos-k8s-pd-staging
kops_bucket_versioning_enabled: true
kops_bucket_versioning_retention: 7
env_dns_zone_name: stage

cluster:
  # This matches the role used to access this account via `aws_auth`
  role: stage_admin
```

#### Run

```shell
$ cd /path/to/pdsw-devops-kubernetes-config/aws-account-terraform

$ terraform workspace new sonos-<account-name>-<account-id>
Created and switched to workspace "sonos-<account-name>-<account-id>"!

$ aws_okta_keyman -P # auth to the new account

$ terraform apply
```

#### Commit and PR

New files and directories created in this process should be tracked in Git.

##### Terraform State

The Terraform state files for the account config are being stored in Git.

Once the Terraform apply has completed successfully, commit the .tfstate files from the new workspace in `aws-account-terraform/terraform.tfstate.d` and put out a PR.

##### Account Config

Don't forget to commit the `values.yaml` file you added in `cluster/accounts/sonos-<account-name>-<account-id>`

### DNS (Route 53)

The terraform run in the previous step will have created a Route 53 public zone within your new account, with the subdomain specified in `values.yaml` with the value of `env_dns_zone_name`.

The zone of record for `k8s.sonos.com` is hosted in our `sonos-devops-tools` account.

For now it is a manual process to delegate `<env_dns_zone_name>.k8s.sonos.com` to the zone created by Terraform.

#### Get Nameservers

There are a few ways you can get the nameservers for your newly created zone, but probably the quickest way is to simply look in the `terraform.tfstate` file in your account's `aws-account-terraform` workspace. You can find  `name_servers` in the `env_zone` object.

#### Add NS Record to `k8s` Zone in Tools Account

Once you have the nameservers, it's time to add the NS record to our `k8s.sonos.com` zone in the `sonos-devops-tools` account.

1. Log in to console through Okta
2. Select role in `sonos-devops-tools` (PowerUserOkta or higher privelege)
3. Navigate to Route 53 console
4. Navigate to `Hosted Zones` > `k8s.sonos.com`
5. Create record set
   - Name: `<env_zone_name>.k8s.sonos.com`
   - Type: `NS - Name server`
   - Value: `<name servers>` (use name servers from last section)
6. Create

#### Validate

```shell
$ dig <env_zone_name>.k8s.sonos.com

; <<>> DiG 9.10.6 <<>> <env_zone_name>.k8s.sonos.com
;; global options: +cmd
;; Got answer:
;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 58191
;; flags: qr rd ra; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1

;; OPT PSEUDOSECTION:
; EDNS: version: 0, flags:; udp: 1452
;; QUESTION SECTION:
;<env_zone_name>.k8s.sonos.com.           IN      A

;; AUTHORITY SECTION:
<env_zone_name>.k8s.sonos.com.    900     IN      SOA     ns-1140.awsdns-14.org. awsdns-hostmaster.amazon.com. 1 7200 900 1209600 86400

;; Query time: 349 msec
;; SERVER: 192.168.1.1#53(192.168.1.1)
;; WHEN: Wed May 06 13:05:02 EDT 2020
;; MSG SIZE  rcvd: 152
```

Make sure that in `"AUTHORITY SECTION"`, the nameserver listed is in fact one of the nameservers in the NS record you just created.

#### Consider a New OIDC Environment (Issuer)

This new account probably represents an entirely new environment. You may want to create a new OIDC environment (issuer) as described in [Managing OIDC Environments (Issuers)](./oidc-issuers-environments.md)

## Updating Existing Accounts

### Terraform Update

#### Run Update

```shell
$ cd /path/to/pdsw-devops-kubernetes-config/aws-account-terraform

$ terraform workspace list
  default
  sonos-dev-858585593831
  sonos-devops-dev-519638027393
  sonos-devops-tools-183660415521
  sonos-production-142123442171
* sonos-staging-230391879291

$ terraform workspace select sonos-production-142123442171
Switched to workspace "sonos-production-142123442171".

$ aws_okta_keyman -P # auth to the account being updated

$ terraform apply
```

#### Commit and PR Updated Terraform State

The Terraform state files for the account config are being stored in Git.

Once the Terraform apply has completed successfully, commit the .tfstate files from the new workspace in `aws-account-terraform/terraform.tfstate.d` and put out a PR.
