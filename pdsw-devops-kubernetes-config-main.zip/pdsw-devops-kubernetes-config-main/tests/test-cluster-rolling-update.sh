#!/usr/bin/env bash

cd ../pdsw-engx-devops-kubernetes

tests/test-cluster-rolling-update.sh
