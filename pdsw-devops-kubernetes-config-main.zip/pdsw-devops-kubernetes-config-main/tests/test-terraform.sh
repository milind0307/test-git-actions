#!/usr/bin/env bash

set -o errexit
set -o nounset
set -o pipefail

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"
TERRAFORM_BINARY=${ROOT}/tools/bin/terraform.sh

cd aws-account-terraform
# Fake variables used for now.
export TF_VAR_region=us-east-1
export TF_VAR_transit_region=us-east-1
export TF_VAR_aws_profile=test
export TF_VAR_cluster_name=test
export TF_VAR_cluster_env=dev
export TF_VAR_cluster_transit=true
export TF_VAR_cluster_subdomain=test
export TF_VAR_cluster_logs=true
${TERRAFORM_BINARY} validate
