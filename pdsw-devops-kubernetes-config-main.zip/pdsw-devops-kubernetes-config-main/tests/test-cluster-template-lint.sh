#!/usr/bin/env bash

set -o errexit
set -o nounset
set -o pipefail

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"

# To trigger any debug modes
export CI=1
# Hide MOTD and prevent delay
export DISABLE_WARNING=true

# set in prow.yaml
cd $KUBERNETES_REPO_PATH
# used by kubernetes repo make commands
export CONFIG_REPO_PATH="${ROOT}"
# set up symlink within kubernetes repo
./tools/configfetcher.sh

for env in ${ROOT}/environments/*/ ; do
  cluster_name=$(echo ${env} | rev | cut -d/ -f2 | rev)
  export CLUSTER_NAME=${cluster_name}
  echo "******************************************************************************************"
  echo "* Test - Generate templates for: ${cluster_name}"
  echo "******************************************************************************************"
  make cluster-template
  echo "******************************************************************************************"
  echo "* Test - Running helmfile lint for: ${cluster_name}"
  echo "******************************************************************************************"
  make helmfile-lint
done
