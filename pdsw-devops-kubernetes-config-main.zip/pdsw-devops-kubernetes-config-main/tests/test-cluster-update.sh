#!/usr/bin/env bash

cd ../pdsw-engx-devops-kubernetes

"$1"
