Secret Encryption
==================

As a stopgap solution for secret encryption, we've chosen [git secret](https://git-secret.io/).
This is not intended to be a long term solution and relies on users trusting each other's GPG keys.

- [Secret Encryption](#secret-encryption)
  - [Requirements](#requirements)
  - [Generate GPG Key](#generate-gpg-key)
  - [Usage](#usage)
    - [Adding Files to be encrypted](#adding-files-to-be-encrypted)
    - [Decrypting & Updating Files](#decrypting--updating-files)
    - [Adding users](#adding-users)

## Requirements
Ensure git-secret and gpg-suite is installed locally:
```
brew bundle
```

## Generate GPG Key
There are many ways to generate a GPG key.  Below is one way:

Install the above bundle which includes `gpg-suite`.  Find the GPG Keychain application
on your computer.
* Click New
* Enter your name, sonos email address and a password that will be required when using the key
* Click Generate Key

In order to gain access, you'll need to provide your public key to a member of the devops team:
* Select your key in GPG Keychain
* Click export, ensure "Include secret key in exported file" is *NOT* selected.
* Send it to Mike Splain or David Muckle to gain access to secrets in this repo.


## Usage
Ensure you've been added as a user to the repo in order to decrypt values.

By default specific files are flagged for encryption, they can be found in
`.gitsecret/paths/mapping.cfg`

### Adding Files to be encrypted

To add a new file to the encryption, first add the decrypted file to `.gitignore`
to ensure it's never checked in as decrypted.

Then encrypt the file with:
```
git secret add file/path.txt
```
Checkin the encrypted file.

### Decrypting & Updating Files
To decrypt files run:
```
git secret reveal
```
This may propt you for a password if you added a password to your gpg key.

After making changes to the decrypted files, run the following to re-encrypt them:
```
git secret hide
```

### Adding users
To Add users, add the users public key into your gpg keychain, then run
this command in your terminal for the given user:
```
git secret tell user.name@sonos.com
# ensure the pubring files have been updated then re-encrypt the secrets
git secret hide
# commit all secrets and .gitsecret files
git add .gitsecret cluster
# git commit and open a PR for review
```
