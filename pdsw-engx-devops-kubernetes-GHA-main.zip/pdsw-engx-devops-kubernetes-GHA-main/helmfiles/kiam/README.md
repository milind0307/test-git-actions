# Kiam

We utilize Kiam in order to allow pods restricted IAM access to specified roles without the need for credentials.

By default, Kiam blocks most metadata service requests for pods and limits users to metadata requests that are whitelisted in our values.

## Components

### Helm Chart
Currently we forked the [Kiam chart](../../charts/kiam) to add support for init containers.  Our helmfile specifically utilizes this chart until we switch it back to open sources.

### Helmfile Values
We have curated [helmfile values](values.yaml.gotmpl) depending on CNI provider and required Kiam certs.

We also have a separate [versions file](version.yaml), which is parsed by the docker builds below and utilized by helmfile when deploying kiam.

### Docker Containers / Kiam Version
Currently we build and publish a version of Kiam to our internal registry since Kiam has not released required fixes.

Jobs:
- [Docker build](https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/8803acdf364b4ce186775bed86976a085d817cdc/.prow.yaml#L120-L151) - Builds a kiam container whenever the [version file](version.yaml) is changed.
- [Docker build & push](https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/8803acdf364b4ce186775bed86976a085d817cdc/.prow.yaml#L263-L299) - Builds and pushes a kiam container whenever the [version file](version.yaml) is changed on develop or main.
- TODO: future job for promoting to prod