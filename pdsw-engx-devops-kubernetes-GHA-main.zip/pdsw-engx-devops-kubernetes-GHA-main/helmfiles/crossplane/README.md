# Crossplane

## Getting started

An IAM User is created using terraform which can be found [here](https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/terraform/crossplane.tf). In the IAM console, you'll need to generate a new Access Key for the user that was generated. Take the access key and secret and put it into a new secret in Secrets Manager. This secret will need to be named `crossplane/{CLUSTER_NAME}/user` which will then be findable by external secrets [here](https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/charts/crossplane-additions/templates/externalsecret.yaml#L10).

The secret in Secrets Manager should be formatted like this in plaintext:

```json
{
  "key": "[default] \naws_access_key_id = AWS_KEY_ID \naws_secret_access_key = AWS_KEY_SECRET"
}
```

This secret should be viewable both as plaintext and as a key/value pair. Make sure to check that the secret `aws-creds` in the `sonos-system-crossplane` namespace is populated and decrypts from base64 to the contents above, with the newline escape sequences being replaced with actual newlines.

Should you tear down your cluster and bring a new one up, you will need to recreate the Access Key and put them into that secret in Secrets Manager.

Note: The Secrets Manager secret is intentionally not included in Terraform since AWS requires 7 days between deleting a secret and being able to reuse the same name. Thus this would impact clusters that regularly come and go from being able to come up.

## Cleanup Steps

[here](https://crossplane.io/docs/v1.4/reference/uninstall.html)

CRD Cleanup:

```bash
kubectl get crd -o name | grep crossplane.io | xargs kubectl delete
```
