# sonos-system-serviceids

This is a helmfile utilizing the wrapper for namespace creation via the helper for namespaces.

This will create the sonos-system-serviceids namespace, this is the current implementation for managing service accounts in the cluster (Jenkins instances requiring SAs)
