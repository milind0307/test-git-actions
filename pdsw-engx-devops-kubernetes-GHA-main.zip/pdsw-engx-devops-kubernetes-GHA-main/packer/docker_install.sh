#!/usr/bin/env bash

###
# This script downloads packages from source and checks their sha256. 
# The packages and their respective version numbers can be found in the ami_settings.json file
# Version numbers were copied from original kope.io images: https://github.com/kubernetes-sigs/image-builder/blob/master/images/kube-deploy/imagebuilder/templates/1.18-stretch.yml
###

sudo mkdir -p /var/cache/nodeup/archives
cd /var/cache/nodeup

KUBECTL_SHA=$(wget -qO- https://storage.googleapis.com/kubernetes-release/release/v${KUBECTL_VERSION}/bin/linux/amd64/kubectl.sha256)
KUBECTL_VERSION_UNDERSCORE=$(echo ${KUBECTL_VERSION} | tr '.' '_')
KUBELET_SHA=$(wget -qO- https://storage.googleapis.com/kubernetes-release/release/v${KUBELET_VERSION}/bin/linux/amd64/kubelet.sha256)
KUBELET_VERSION_UNDERSCORE=$(echo ${KUBELET_VERSION} | tr '.' '_')
CNIPLUGIN_SHA=$(echo $(wget -qO- https://storage.googleapis.com/k8s-artifacts-cni/release/v${CNIPLUGIN_VERSION}/cni-plugins-linux-amd64-v${CNIPLUGIN_VERSION}.tgz.sha256) | cut -d' ' -f1)
CNIPLUGIN_VERSION_UNDERSCORE=$(echo ${CNIPLUGIN_VERSION} | tr '.' '_')
CONTAINERD_SHA=$(wget -qO- https://storage.googleapis.com/cri-containerd-release/cri-containerd-${CONTAINERD_VERSION}.linux-amd64.tar.gz.sha256)

sudo wget -q https://storage.googleapis.com/kubernetes-release/release/v${KUBECTL_VERSION}/bin/linux/amd64/kubectl -O /var/cache/nodeup/sha256:${KUBECTL_SHA}_https___storage_googleapis_com_kubernetes-release_release_v${KUBECTL_VERSION_UNDERSCORE}_bin_linux_amd64_kubectl
echo ${KUBECTL_SHA} sha256:${KUBECTL_SHA}_https___storage_googleapis_com_kubernetes-release_release_v${KUBECTL_VERSION_UNDERSCORE}_bin_linux_amd64_kubectl | sha256sum -c -

sudo wget -q https://storage.googleapis.com/kubernetes-release/release/v${KUBELET_VERSION}/bin/linux/amd64/kubelet -O /var/cache/nodeup/sha256:${KUBELET_SHA}_https___storage_googleapis_com_kubernetes-release_release_v${KUBELET_VERSION_UNDERSCORE}_bin_linux_amd64_kubelet
echo ${KUBELET_SHA} sha256:${KUBELET_SHA}_https___storage_googleapis_com_kubernetes-release_release_v${KUBELET_VERSION_UNDERSCORE}_bin_linux_amd64_kubelet | sha256sum -c -

sudo wget -q https://storage.googleapis.com/k8s-artifacts-cni/release/v${CNIPLUGIN_VERSION}/cni-plugins-linux-amd64-v${CNIPLUGIN_VERSION}.tgz -O /var/cache/nodeup/sha256:${CNIPLUGIN_SHA}_https___storage_googleapis_com_k8s-artifacts-cni_release_v${CNIPLUGIN_VERSION_UNDERSCORE}_cni-plugins-linux-amd64-v${CNIPLUGIN_VERSION_UNDERSCORE}_tgz
echo ${CNIPLUGIN_SHA} sha256:${CNIPLUGIN_SHA}_https___storage_googleapis_com_k8s-artifacts-cni_release_v${CNIPLUGIN_VERSION_UNDERSCORE}_cni-plugins-linux-amd64-v${CNIPLUGIN_VERSION_UNDERSCORE}_tgz | sha256sum -c -

sudo wget -q https://storage.googleapis.com/cri-containerd-release/cri-containerd-${CONTAINERD_VERSION}.linux-amd64.tar.gz -O /var/cache/nodeup/archives/containerd.io
cd /var/cache/nodeup/archives
echo ${CONTAINERD_SHA} containerd.io | sha256sum -c -