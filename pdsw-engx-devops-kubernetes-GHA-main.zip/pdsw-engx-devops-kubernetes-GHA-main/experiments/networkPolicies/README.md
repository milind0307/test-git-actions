# Network Policy Testing

## Test Cases

### 1 - Default

Scenario: No changes made to networkPolicies.

Result: All traffic is allowed both internally and externally.

### 2 - "Baseline"

Scenario: Default deny of all ingress traffic outside of a given namespace, except for system namespaces.

Result: Traffic is properly locked down intra-pod, but does not allow external ingress into a pod.

### 3 - Allow 0.0.0.0 but Deny nonMasqueradeCIDR

Scenario: Allow all IP ingress but add an exception to deny nonMasqueradeCIDR block, which is the internal pod IP range.

Result: Allows ingress from within the same namespace and by LoadBalancer, but does not allow intra-pod ingress or system namespace ingress.

### 4 - Baseline & Allow 0.0.0.0 but Deny nonMasqueradeCIDR

Scenario: Default deny of all ingress traffic outside of a given namespace, except for system namespaces. Also allow all IP ranges except for nonMasqueradeCIDR. The idea is to test and see if our deny of intra-pod communication gets overwritten by the attempt to allow external communication.

Result: This seems to work!