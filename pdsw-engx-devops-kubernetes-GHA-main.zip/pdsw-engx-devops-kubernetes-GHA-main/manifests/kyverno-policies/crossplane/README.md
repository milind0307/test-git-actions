# Crossplane Policy & Testing

Due to the large amount of crossplane components I chose to break out the resources into seperate files and compile them all together in the `test.yaml` file. All sample Crossplane resources were taken from the [upstream repo](https://github.com/crossplane/provider-aws) and modified for testing purposes.
