# Disallow Privileged Containers Policy

Pulled from OSS [here](https://github.com/kyverno/policies/tree/main/pod-security/baseline/disallow-privileged-containers).

Dissallows containers from running in privileged mode since most security mechanisms are disabled in privileged mode.
