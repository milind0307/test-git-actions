# Kyverno Test Policies

This folder contains the kyverno policies to be applied to the clusters, in addition to their supporting test files.
The structure of each folder, which corresponds to a certain policy, is as such:

- `test.yaml` --> This file defines the testing profile of each policy
- `<policy_name>.yaml` --> This file contains the kyverno policy definition
- `resource.yaml` --> This file defines the dummy resources to be fed to the test suite (as input)
- `values.yaml` --> This file defines variables that would otherwise be scrapped from the cluster (e.g configmap data, api-server calls)

## Namespace Exemption

Much like the system used in Gatekeeper/OPA, we need a method to exempt our namespaces from Kyverno policies. We do this by the use of the `kyverno=exempt` flag which we add to DevOps-owned namespaces, and then exempting individual policies by the use of the following code block (which you may notice replicated across all policies because there is no way to group policies and apply logic to them today).

```yaml
exclude:
    resources:
        namespaceSelector:
        matchExpressions:
            - key: kyverno 
            operator: In
            values: 
            - exempt
```

There is a policy that validates all namespaces and checks that only DevOps-owned namespaces can have this label on them. This is our centralized list of owned namespaces, see `policy-restrict-exemption-label.yaml`

## Development

The [Kyverno CLI](https://kyverno.io/docs/kyverno-cli/) is a useful tool for testing and validating policies during development.

To run tests on all policies (after installation of CLI):

```bash
cd manifests/kyverno-policies
kyverno test .
```

Optional: use `-v 5` for hightest log level, useful for debugging.

Validation looks similar:

```bash
cd manifests/kyverno-policies
kyverno validate .
```
