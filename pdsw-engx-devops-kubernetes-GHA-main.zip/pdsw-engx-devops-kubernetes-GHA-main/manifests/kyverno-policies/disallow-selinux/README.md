# Disallow Privileged Containers Policy

Pulled from OSS [here](https://github.com/kyverno/policies/tree/main/pod-security/baseline/disallow-selinux).

Disallows SELinux options which can be used to escalate privileges.
