#!/bin/bash

# This script wraps our connect tool from tools/connect
docker run --pull always --rm -it -v $HOME/.aws:/root/.aws -e CLUSTER_NAME=$CLUSTER_NAME -e AWS_REGION=$AWS_REGION -e AWS_PROFILE=$AWS_PROFILE services-docker-dev.artifactory.sonos.com/pdsw/devops/kubernetes/connect