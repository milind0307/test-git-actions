#!/bin/bash

#
# This script attempts to unify cluster upgrades into one script allowing users (prow)
# to only reference one script for update and upgrade proceedures.
#

set -e

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"

# PROW_ENABLE_CLUSTER_UPDATE enables cluster updates
#   default: true
PROW_ENABLE_CLUSTER_UPDATE=${PROW_ENABLE_CLUSTER_UPDATE:-true}
# PROW_ENABLE_ROLLING_UPDATE enables cluster rolling updates
#   default: true
PROW_ENABLE_ROLLING_UPDATE=${PROW_ENABLE_ROLLING_UPDATE:-true}
# PROW_ENABLE_ARGO_SYNCING enables cluster argo syncing
#   default: true
PROW_ENABLE_ARGO_SYNCING=${PROW_ENABLE_ARGO_SYNCING:-true}

if [ "$PROW_ENABLE_CLUSTER_UPDATE" = true ]; then
  ${ROOT}/scripts/cluster-update.sh
fi

if [ "$PROW_ENABLE_ROLLING_UPDATE" = true ]; then
  ${ROOT}/scripts/cluster-rolling-update.sh
fi

if [ "$PROW_ENABLE_ARGO_SYNCING" = true ]; then
  ${ROOT}/scripts/argo-sync.sh
fi

