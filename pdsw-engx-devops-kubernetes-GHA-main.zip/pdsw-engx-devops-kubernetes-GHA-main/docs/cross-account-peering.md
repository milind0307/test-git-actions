# Cross Account Peering

Cross account peering support in this repo was added specifically to support peering to Instaclustr. This means that we have support for _incoming_ peering — that is peering connections that are initiated not from the AWS account with the Kubernetes cluster, but instead the peer account (e.g. the Instaclustr account requests the peering connection).

| If you are looking to peer to Instaclustr, documentation on initiating the peering request from Instaclustr [can be found in Confluence here](https://confluence.sonos.com/display/PDSW/Instaclustr+Cassandra+Hosting) |
| --- |

## Adding Incoming Peering for a Cluster

### Add Peering to Cluster values.yaml

You will need:

* The incoming peering connection ID (`pcx-xxxxxxxx`)
* The network CIDR of the VPC or subnet(s) within the VPC in the peer account
* A name for the peering connection (ideally would match any name used in the peer account)

Adding the connection is then simple. You will need to add a new peer to `cluster.incomingCrossAccountVpcPeers` in your cluster's `values.yaml`. Here is an example:

```yaml
cluster:
  incomingCrossAccountVpcPeers:
    us-east-1_pnp0_cassandra_to_us-east-1_k8s_test_cluster:
      cidr: 10.222.216.0/26
      id: pcx-0787bd80eeed6060f
```

### Testing

Make sure you have your terminal environment ready:

```bash
$ cd path/to/pdsw-engx-devops-kubernetes
$ export CLUSTER_NAME=<clustername.something.tld>
$ source source.sh
```

Then you can run a Terraform plan:

```bash
$ make terraform-plan
```

As of writing this doc, 5 resources will be created per peer, and the plan will look something like this (with one peer):

```bash
------------------------------------------------------------------------

An execution plan has been generated and is shown below.
Resource actions are indicated with the following symbols:
  + create

Terraform will perform the following actions:

  # aws_route.local_routes_to_incoming_cross_account_vpc_peers["rtb-00a96bb2b9d6b6146-us-east-1_pnp0_cassandra_to_us-east-1_k8s_test"] will be created
  + resource "aws_route" "local_routes_to_incoming_cross_account_vpc_peers" {
      + destination_cidr_block     = "pcx-0787bd80eeed6060f"
      + destination_prefix_list_id = (known after apply)
      + egress_only_gateway_id     = (known after apply)
      + gateway_id                 = (known after apply)
      + id                         = (known after apply)
      + instance_id                = (known after apply)
      + instance_owner_id          = (known after apply)
      + nat_gateway_id             = (known after apply)
      + network_interface_id       = (known after apply)
      + origin                     = (known after apply)
      + route_table_id             = "rtb-00a96bb2b9d6b6146"
      + state                      = (known after apply)
      + vpc_peering_connection_id  = "10.222.216.0/26"
    }

  # aws_route.local_routes_to_incoming_cross_account_vpc_peers["rtb-08a4883c47046ac4d-us-east-1_pnp0_cassandra_to_us-east-1_k8s_test"] will be created
  + resource "aws_route" "local_routes_to_incoming_cross_account_vpc_peers" {
      + destination_cidr_block     = "pcx-0787bd80eeed6060f"
      + destination_prefix_list_id = (known after apply)
      + egress_only_gateway_id     = (known after apply)
      + gateway_id                 = (known after apply)
      + id                         = (known after apply)
      + instance_id                = (known after apply)
      + instance_owner_id          = (known after apply)
      + nat_gateway_id             = (known after apply)
      + network_interface_id       = (known after apply)
      + origin                     = (known after apply)
      + route_table_id             = "rtb-08a4883c47046ac4d"
      + state                      = (known after apply)
      + vpc_peering_connection_id  = "10.222.216.0/26"
    }

  # aws_route.local_routes_to_incoming_cross_account_vpc_peers["rtb-0d27346b4363ab050-us-east-1_pnp0_cassandra_to_us-east-1_k8s_test"] will be created
  + resource "aws_route" "local_routes_to_incoming_cross_account_vpc_peers" {
      + destination_cidr_block     = "pcx-0787bd80eeed6060f"
      + destination_prefix_list_id = (known after apply)
      + egress_only_gateway_id     = (known after apply)
      + gateway_id                 = (known after apply)
      + id                         = (known after apply)
      + instance_id                = (known after apply)
      + instance_owner_id          = (known after apply)
      + nat_gateway_id             = (known after apply)
      + network_interface_id       = (known after apply)
      + origin                     = (known after apply)
      + route_table_id             = "rtb-0d27346b4363ab050"
      + state                      = (known after apply)
      + vpc_peering_connection_id  = "10.222.216.0/26"
    }

  # aws_route.local_routes_to_incoming_cross_account_vpc_peers["rtb-0f1f1722f4d5902e9-us-east-1_pnp0_cassandra_to_us-east-1_k8s_test"] will be created
  + resource "aws_route" "local_routes_to_incoming_cross_account_vpc_peers" {
      + destination_cidr_block     = "pcx-0787bd80eeed6060f"
      + destination_prefix_list_id = (known after apply)
      + egress_only_gateway_id     = (known after apply)
      + gateway_id                 = (known after apply)
      + id                         = (known after apply)
      + instance_id                = (known after apply)
      + instance_owner_id          = (known after apply)
      + nat_gateway_id             = (known after apply)
      + network_interface_id       = (known after apply)
      + origin                     = (known after apply)
      + route_table_id             = "rtb-0f1f1722f4d5902e9"
      + state                      = (known after apply)
      + vpc_peering_connection_id  = "10.222.216.0/26"
    }

  # aws_vpc_peering_connection_accepter.incoming_vpc_peer_accepters["us-east-1_pnp0_cassandra_to_us-east-1_k8s_test"] will be created
  + resource "aws_vpc_peering_connection_accepter" "incoming_vpc_peer_accepters" {
      + accept_status             = (known after apply)
      + auto_accept               = true
      + id                        = (known after apply)
      + peer_owner_id             = (known after apply)
      + peer_region               = (known after apply)
      + peer_vpc_id               = (known after apply)
      + tags                      = {
          + "Name" = "us-east-1_pnp0_cassandra_to_us-east-1_k8s_test"
          + "Side" = "Accepter"
        }
      + vpc_id                    = (known after apply)
      + vpc_peering_connection_id = "10.222.216.0/26"

      + accepter {
          + allow_classic_link_to_remote_vpc = (known after apply)
          + allow_remote_vpc_dns_resolution  = (known after apply)
          + allow_vpc_to_remote_classic_link = (known after apply)
        }

      + requester {
          + allow_classic_link_to_remote_vpc = (known after apply)
          + allow_remote_vpc_dns_resolution  = (known after apply)
          + allow_vpc_to_remote_classic_link = (known after apply)
        }
    }

Plan: 5 to add, 0 to change, 0 to destroy.

------------------------------------------------------------------------

Note: You didn't specify an "-out" parameter to save this plan, so Terraform
can't guarantee that exactly these actions will be performed if
"terraform apply" is subsequently run.
```

### Deploying

Please ensure you have tested, put in a PR, and merged your changes before doing this for any non-personal clusters.

Like with testing, you should make sure your terminal session is set up properly.

```bash
$ cd path/to/pdsw-engx-devops-kubernetes
$ export CLUSTER_NAME=<clustername.something.tld>
$ source source.sh
```

You can then deploy the changes

```bash
$ make terraform-apply
```
