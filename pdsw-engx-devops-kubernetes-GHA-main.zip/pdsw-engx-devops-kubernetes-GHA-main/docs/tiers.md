# Cluster Tiers

Tiers define the support level surrounding a given cluster.

## Tiers

Below are the current tiers defined/supported by SONOS PnP DevOps:

| Tier    | Role                                                                    |
| ------- | ----------------------------------------------------------------------- |
| tier1   | production-level clusters (i.e. production, staging, tools)             |
| tier2   | secondary clusters (i.e. sandbox, test, build)                          |
| tier3   | testing & development (i.e. devops-dev)                                  |
| default | No-Tier catch-all for any cluster. Also provides default cluster values |

## Cluster Services

Below are cluster infrastructure services that are enabled at each tier:

| Service          | tier1 | tier2 | tier3 | default |
| ---------------- | ----- | ----- | ----- | ------- |
| oauth2-proxy     | X     | X     | X     | X       |
| monitoring       | X     | X     | X     | X       |
| velero           | X     | X     |       |         |
| external-secrets | X     | X     | X     | X       |
| cert-manager     | X     | X     |       |         |
| kyverno          | X     | X     | X     | X       |
| alertmanager     | X     | X     |       |         |
| datadog          |       |       |       |         |
| kubecost         | X     | X     | X     | X       |
