# Managing OIDC Environments (Issuers)

<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->
## Table of Contents

- [What is an OIDC Issuer/Environment?](#what-is-an-oidc-issuerenvironment)
- [Why More Than One Issuer?](#why-more-than-one-issuer)
- [Creating a New Issuer](#creating-a-new-issuer)
  - [Configuration](#configuration)
    - [Deployment](#deployment)
  - [Sk8s](#sk8s)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

## What is an OIDC Issuer/Environment?

Dex is our OIDC authorization service that integrates with Okta and Kubernetes.

OIDC issuers (also referred to here as 'environments') are configurations within our various Dex instances. As of writing we are running two instances of Dex (one on `tools` and one on `sandbox`), however we will be expanding that to at least one new instance of Dex for uper environments.

In order for each cluster's authentication to function properly, the cluster must provide a client ID and secret key to Dex — the client ID and secret key are associated with the issuer.

## Why More Than One Issuer?

There are a few reasons we do not simply create one issuer for all clusters:

1. We have multiple Dex instances. Reusing client IDs and keys can be confusing and lead to errors
2. Separating issuers by environment simplifies and segments our auth workflow with sk8s (sk8s 'environments' map to issuers)

## Creating a New Issuer

Occasionally, there will be a need to create a new issuer to serve as a new auth environment.Most recently this was needed to create the `kubernetes-stage` and `kubernetes-prod` issuers. Usually you will not need to create a new issuer.

### Configuration

1. First, choose the Dex that will serve the new cluster(s) and locate (in this repo) the configs for the cluster that hosts that instance of Dex. This will be referred to as the "Dex cluster" for the rest of this guide.
  | Dex URL | Cluster Hosting Dex |
  |-|-|
  | `dex-dev.do.ws.sonos.com` | `sandbox.k.do.ws.sonos.com` |
  | `dex.do.ws.sonos.com` | `tools.k.do.ws.sonos.com` |
  | Upper environments TBD| TBD

2. Decrypt the `secret.yaml.secret` files

  ```shell
  $ git secret reveal
  ```

3. Within the Dex cluster's newly decrypted `secrets.yaml` file, you can add the issuer within the `dex.config.staticClients` list. Randomly generate a secret. The secrets are 43 alphanumeric characters.

  ```yaml
  dex:
    ...
    config:
    ...
      staticClients:
        - id: kubernetes-<new-env-name>
          redirectURIS:
          - http://127.0.0.1:5555/callback
          name: 'Kubernetes <Env> Clusters'
          secret: *******************************************
        ...
      ...
    ...
  ```

4. Update the secrets files (you can discard changes made to any clusters other than the one you are modifying)

  ```shell
  $ git secret hide
  ```

#### Deployment

**IMPORTANT: Do not perform these steps without checking in with the team! There may be things that have been merged that we do NOT want to deploy to the cluster hosting our Dex.**

5. Before you do anything read the warning above.

6. So did you check with the team yet? What about that one person who was offline in Slack today but has been working on cluster changes?

7. Prepare your local environment

  ```shell
  $ export CLUSTER_NAME=<dex-cluster-fqdn>
  $ source source.sh
  ```

8. Sync helm charts

  ```shell
  $ make helmfile-sync
  ```

### Sk8s

Now it's time to add a new environment to `sk8s`.

1. Check out our [sk8s repo](https://github.com/Sonos-Inc/pdsw-engx-devops-sk8s)
2. base64 encode the issuer's client secret

  ```bash
  echo -n <issuer-secret> | base64
  ```

  Note: use `echo -n` to strip newlines from the secret before encoding, otherwise you will likely end up frustrated and baffled about why `sk8s` isn't working.
3. Add new issuer to `issuers` in [clusters.yaml](https://github.com/Sonos-Inc/pdsw-engx-devops-sk8s/blob/develop/clusters.yaml)

```yaml
- URL: <dex-URL>
  name: <new-env-name>
  clientID: kubernetes-<new-env-name>
  clientSecret: <base64-secret>
```

4. Commit and PR!

| |
|-|
| Note: This is impossible to validate without a Kubernetes cluster configured to use the new issuer. If you already have a cluster that you would like to use the new issuer, you can follow the steps in [Creating Shared Clusters](./creating-shared-clusters.md#secretsyaml) starting with the `secrets.yaml` section. |
