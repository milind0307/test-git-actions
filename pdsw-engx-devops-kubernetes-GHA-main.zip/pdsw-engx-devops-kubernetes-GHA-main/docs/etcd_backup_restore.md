# Restoring an Etcd Backup

While Kubernetes clusters are supposed to be fault tolerant, including the Etcd database, the component responsible for storing all the information on objects in the cluster, a non-healable fault can nevertheless occur. Thankfully, we have automated backups of the Etcd database for each cluster.

## Interacting with Etcd Backups

To list backups and restore them, you'll need to use `etcd-manager-ctl`. You can grab the binary at [https://github.com/kopeio/etcd-manager/releases](https://github.com/kopeio/etcd-manager/releases). Download the version for your OS and place it somewhere in your PATH.

Next, in the [pdsw-engx-devops-kubernetes](https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes) repo, set the `CLUSTER_NAME` to the cluster you want to recover the Etcd of, and run `source source.sh` to get AWS credentials for the right account.

Etcd-manager, the tool used by kOps to manage Etcd, manages two Etcd clusters: main and events. The main cluster is the more important cluster, holding information on all objects in the cluster, while the latter holds events one can query for with `kubectl get events`. While both clusters may fail, the main cluster failing has more drastic implications.

To get the health of the Etcd clusters, the following can be run:

```bash
kubectl get --raw='/readyz?verbose'
```

## Listing Etcd Backups

To list backups to restore from, one can run a command like the following:

```bash
etcd-manager-ctl --backup-store=s3://sonos-k8s-pd-devops-dev/kops/$CLUSTER_NAME/backups/etcd/main list-backups
```

This will output a list that looks something like:

```bash
2021-10-05T15:10:48Z-000054
2021-10-05T16:11:32Z-000058
2021-10-05T17:12:21Z-000061
2021-10-05T18:12:55Z-000095
2021-10-05T19:13:42Z-000068
2021-10-05T19:28:58Z-000096
2021-10-05T19:44:03Z-000069
2021-10-05T19:59:13Z-000070
```

Note that the S3 bucket name will have to be changed depending on which account the cluster is in. This command also specifically lists backups made for the main Etcd cluster. To list backups for the events Etcd cluster, replace "main" in the above command with "events".

By default etcd-manager will make a backup once every fifteen minutes, retaining hourly backups for a week and daily backups for a year. This can be adjusted in cluster creation.

## Restoring A Backup

The `etcd-manager-ctl restore-backup` command, given a backup name, will not immediately restore a backup. Instead, it will place a command in the S3 bucket where backups are stored that will inform Etcd on restart to restore the backup. The full command will look something like the following:

```bash
etcd-manager-ctl --backup-store=s3://sonos-k8s-pd-devops-dev/kops/$CLUSTER_NAME/backups/etcd/main restore-backup 2021-10-04T06:14:13Z-000181
```

Again replacing the S3 bucket with the bucket for the account the cluster is in, and substituting "main" for "events" as necessary.

Next, the Etcd cluster must be restarted. Because the cluster's kubeapiserver will be down if Etcd is down, ssh into each control node using the `ssh.sh` script in the pdsw-engx-devops-kubernetes repo. The Etcd cluster leader will have to be restarted first. In order to do that, in each control node, run the following

```bash
cat /var/log/etcd.log | grep "I am leader"
```

Additionally, use `less` to parse through the logs and make sure the node is the current leader of the Etcd cluster. For the events cluster, the logs are stored in `/var/log/etcd-events.log`. Once the leader is determined, run the following on first the node with the Etcd leader, then the other control nodes. Again, for the events Etcd cluster, replace "main" with "events".

```bash
sudo ctr -namespace k8s.io task kill $(sudo ctr -namespace k8s.io task ls | grep $(ps aux | grep etcd | grep main | awk '{print $2}') | awk '{print $1}')
```

Because we use containerd in our clusters, and not Docker, we're using `ctr` here, the CLI tool for containerd. In the above command, we're finding the PID for the Etcd process that's running the main cluster, then finding the associated container to that PID, then killing that container.

After that, run the above command on all other control nodes. After that, the restore should start on the node with the leader Etcd process. To double check the restore command is taking, tail the log at `/var/log/etcd.log` for an entry something like:

```log
I1004 19:28:03.006465  232359 controller.go:406] got restore-backup command: timestamp:1633122652741385000 restore_backup:<cluster_spec:<member_count:3 etcd_version:"3.4.13" > backup:"2021-09-30T21:16:31Z-000001" >
```

The Etcd cluster should then come up shortly. If not, try killing the Etcd processes on the non-leader nodes, or starting all over from the beginning. Deleting the previously inserted restore command from the S3 bucket may also be necessary. Consult the output of the `etcd-manager-ctl restore-backup` command to find the restore command's path to delete it.

### Further Reading

[How to recover a Kubernetes cluster](https://medium.com/@youest/kubernetes-ha-kops-etcd-cluster-recovery-4a71a1f1bc90)
[kOps Documentation on Etcd](https://kops.sigs.k8s.io/operations/etcd_backup_restore_encryption/)
