# Kyverno Policy Management System

Kyverno is a policy management tool that we have decided to use in our clusters to replace Gatekeper and OPA. This decision was explored in-depth in a project proposal document that can be found [here](https://docs.google.com/document/d/1g0YlVHHr4J6wSFHwrX7sYaHvNP4NY6Q9cZH5axPdbgg/edit?usp=sharing).

The main reasons for this switch are:

1) Kyverno reduces Operational Toil

2) Kyverno allows for a better DevOps UX

3) Kyverno enables an improved Developer UX

## Gatekeeper/OPA to Kyverno Migration Path

If you are currently running Gatekeeper/OPA in your cluster and would like to migrate to Kyverno (which we recommend as this system will be kept updated and will provide industry-standard security practices), please follow this migration path:

- Disable Gatekeeper in your cluster
  - Disable gatekeeper in your [cluster config](TODO).

  - Manually call the `helmfile-destroy-gatekeeper` [make target](TODO) either locally when authenticated against your cluster or in CI.

- [Enable](TODO) Kyverno in your cluster
- Run `make helmfile-sync` to apply changes to your cluster.
