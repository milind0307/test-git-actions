# Ingress

## External Ingress

To enable external ingress and route traffic through it into your service simply add the `kubernetes.io/ingress.class: nginx-external` annotation to your ingress definition; This will create an associated load balancer in AWS and begin to route traffic through it to the connected service.

An example ingress object might look like so:

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: example-ingress
  annotations:
    kubernetes.io/ingress.class: nginx-external
    nginx.ingress.kubernetes.io/rewrite-target: /$1
spec:
  rules:
    - host: hello-world.info
      http:
        paths:
          - path: /
            backend:
              service:
                name: web
                port:
                  number: 8080
            pathType: ImplementationSpecific
```

An example use of the annotation inside a helmfile deployment might look like this:

```yaml
app_name:
  ingress:
    enabled: true
    hosts:
      - ...
    tls:
      - hosts:
          - ...
    annotations:
      kubernetes.io/ingress.class: nginx-external
```
