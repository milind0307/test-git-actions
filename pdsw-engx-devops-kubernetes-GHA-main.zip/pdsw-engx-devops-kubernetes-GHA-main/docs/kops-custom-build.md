# Using Kops Custom Build

You can use a custom build of Kops if you'd like to test new features that have yet to be merged in.

## Building Kops

You'll need to clone the `https://github.com/kubernetes/kops` to start. Create an S3 bucket in the account you're going to create the test cluster in. You'll upload the build artifacts from Kops to the bucket. Also make sure to install `https://github.com/bazelbuild/bazelisk`

```bash
aws_okta_keyman
export S3_BUCKET_NAME=example-bucket
export S3_BUCKET=s3://${S3_BUCKET_NAME}
make bazel-upload
export KOPS_BASE_URL=https://${S3_BUCKET_NAME}.s3.amazonaws.com/kops/${KOPS_VERSION}/
echo $KOPS_BASE_URL
```

Next, set the field `kops.baseUrl` in the cluster environment to the output of `$KOPS_BASE_URL` above, so the bucket from the build steps is used. You do not need to set the kops version because it may sometimes be a duplicate of real production versions.

```yaml
kops:
  # The version of kops to be used to create the cluster
  # version: v1.22.0-alpha.2
  baseUrl: https://splaintest.s3.amazonaws.com/kops/1.22.0-alpha.2/
```

After that, the usual workflow for bringing up a cluster should work. Be warned, there will probably be bugs!

## Accessing the Test Cluster

As of the latest version of Kops 1.19 prerelease, you may need to use `./tools/bin/kops.sh export kubecfg --admin` to get access to your cluster. Kops no longer default exports useful credentials for your cluster.
