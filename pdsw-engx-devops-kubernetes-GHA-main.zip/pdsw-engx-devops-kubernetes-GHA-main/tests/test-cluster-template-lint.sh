#!/usr/bin/env bash

set -o errexit
set -o nounset
set -o pipefail

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"
CONFIG_REPO=${CONFIG_REPO:="pdsw-devops-kubernetes-config"} # defaults to PDSW DevOps config repo
TEMP_DIR="${ROOT}/.tmp"
CONFIG_REPO_PATH="${CONFIG_REPO_PATH:-${TEMP_DIR}/${CONFIG_REPO}}" # can override

# To trigger any debug modes
export CI=1
# Hide MOTD and prevent delay
export DISABLE_WARNING=true

for env in ${CONFIG_REPO_PATH}/environments/*/ ; do
  cluster_name=$(echo ${env} | rev | cut -d/ -f2 | rev)
  export CLUSTER_NAME=${cluster_name}
  echo "******************************************************************************************"
  echo "* Test - Generate templates for: ${cluster_name}"
  echo "******************************************************************************************"
  make cluster-template
  echo "******************************************************************************************"
  echo "* Test - Running helmfile lint for: ${cluster_name}"
  echo "******************************************************************************************"
  make helmfile-lint
done
