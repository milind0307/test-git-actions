#!/usr/bin/env bash

set -e

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"
TEMP_DIR="${ROOT}/.tmp"
CONFIG_REPO=${CONFIG_REPO:-"pdsw-devops-kubernetes-config"} # defaults to PDSW DevOps config repo
CONFIG_DIR="${TEMP_DIR}/${CONFIG_REPO}"
YQ_BINARY="${ROOT}/tools/bin/yq.sh"
# To trigger any debug modes
export CI=1

# Assumes CLUSTER_NAME is set outside this script
# CLUSTER_NAME=ci-test.k.do.ws.sonos.com

# Source equivalent
${ROOT}/tools/configfetcher.sh
CONFIG_OUTPUT=$(${ROOT}/tools/configmerger.sh ${CLUSTER_NAME})
# We do not use the real cluster role since the permissions are actually granted through the AWS_PROFILE variable and kiam
AWS_S3_BUCKET=$(${YQ_BINARY} r ${CONFIG_OUTPUT} kops_bucket)
export AWS_PROFILE=default
export KOPS_STATE_STORE=s3://${AWS_S3_BUCKET}/kops

# Decrypt secrets
gpg --batch --passphrase $GITSECRET_PASSWORD -aq --import /gitsecret/key

cd ${CONFIG_DIR}
git secret reveal -p $GITSECRET_PASSWORD
cd ${ROOT}

mkdir -p touch $HOME/.aws
if ! grep -q "[default]" $HOME/.aws/config; then
  cat << EOF >> $HOME/.aws/config
[default]
region = ${AWS_REGION}
EOF
fi

export AWS_REGION=us-east-1

# Setup Kubectl
ln -sf ${ROOT}/tools/bin/kubectl.sh /usr/local/bin/kubectl

# Debug Output
make debug

set +e

# Retry loop for cluster up.
# Workaround for this issue: https://github.com/terraform-providers/terraform-provider-aws/issues/12829
count=0

while [ $count -lt 1 ]; do
  make cluster-down

  if [ $? -eq 0 ]; then
    echo Cluster-down exited successfully!
    break
  else
    echo Failure found, beginning cluster-down again
    count=$(( $count + 1 ))
  fi
done