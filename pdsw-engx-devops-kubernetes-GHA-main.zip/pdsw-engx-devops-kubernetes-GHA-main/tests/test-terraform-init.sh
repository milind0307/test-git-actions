#!/usr/bin/env bash

set -o errexit
set -o nounset
set -o pipefail

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"
TERRAFORM_BINARY=${ROOT}/tools/bin/terraform.sh

${TERRAFORM_BINARY} init