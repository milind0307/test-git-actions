#!/bin/bash

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"
KUBECTL=${ROOT}/tools/bin/kubectl.sh

if [ -z $1 ]; then
  echo "Error executing $0, please ensure proper format and arguments"
  echo "This script will check to see if the provided crd exists in this cluster and wait up to 5 minutes for it to exist"
  exit 1
fi

echo "Waiting for CRD $1 to be ready with $2 items in $3 context"

while true; do
  #> /dev/null 2>&1
  count=$(${KUBECTL} api-resources --context $3 | grep $1 | wc -l)
  if (($count >= $2)); then
    break;
  fi
  echo .
  sleep 1
done