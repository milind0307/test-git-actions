package main

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"log"
	"os"
	"reflect"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/awserr"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/ec2"
	"github.com/aws/aws-sdk-go/service/ec2instanceconnect"
	fuzzyfinder "github.com/ktr0731/go-fuzzyfinder"
	"github.com/urfave/cli/v2"
	"golang.org/x/crypto/ssh"
	"golang.org/x/crypto/ssh/terminal"
)

const defaultRegion = "us-east-1"

func getRegion() string {
	if os.Getenv("AWS_REGION") != "" {
		return os.Getenv("AWS_REGION")
	} else {
		log.Printf("Warning, AWS region not set. Defaulting to %s", defaultRegion)
		return defaultRegion
	}
}

func main() {
	var region string
	var clusterName string
	var sshUser string

	app := &cli.App{
		Name:  "connect",
		Usage: "find and connect to kubernetes instances",
		Action: func(c *cli.Context) error {
			hostname := c.Args().First()
			if hostname == "" {
				hostname, _ = findHost(region, clusterName)
				if hostname == "" {
					return fmt.Errorf("hostname argument not provided")
				}
			}
			instance, err := getInstance(region, hostname)
			if err != nil {
				return err
			}

			err = connect(instance, sshUser, region)
			if err != nil {
				fmt.Printf("Error: %v", err)
			}
			return nil
		},
		Flags: []cli.Flag{
			&cli.StringFlag{
				Name:        "region",
				Value:       getRegion(),
				Usage:       "region of the instance",
				Destination: &region,
			},
			&cli.StringFlag{
				Name:        "cluster-name",
				Value:       os.Getenv("CLUSTER_NAME"),
				Usage:       "cluster name to search for instances",
				Destination: &clusterName,
			},
			&cli.StringFlag{
				Name:        "ssh-user",
				Value:       "ubuntu",
				Usage:       "user to connect to instances as",
				Destination: &sshUser,
			},
		},
	}

	err := app.Run(os.Args)
	if err != nil {
		log.Fatal(err)
	}
}

// findHost looks for hosts in this cluster
func findHost(region, clusterName string) (hostname string, err error) {
	svc := ec2.New(session.New(), aws.NewConfig().WithRegion(region))
	input := &ec2.DescribeInstancesInput{
		Filters: []*ec2.Filter{
			{
				Name: aws.String("tag:KubernetesCluster"),
				Values: []*string{
					aws.String(clusterName),
				},
			},
		},
	}

	result, err := svc.DescribeInstances(input)
	if err != nil {
		if aerr, ok := err.(awserr.Error); ok {
			switch aerr.Code() {
			default:
				fmt.Println(aerr.Error())
			}
		} else {
			// Print the error, cast err to awserr.Error to get the Code and
			// Message from an error.
			fmt.Println(err.Error())
		}
		return "", err
	}

	instance, err := fuzzyListInstances(result.Reservations)
	if err != nil {
		fmt.Printf("%s - %s\n", err, clusterName)
		return "", err
	}

	return instance, nil
}

type finderInstance struct {
	Hostname      string
	IP            string
	Role          string
	InstanceGroup string
	Type          string
	State         string
	AZ            string
	ID            string
}

// fuzzyListInstances aws reservations into finderInstances
// and gives the user an interface for selecting their instance
func fuzzyListInstances(reservations []*ec2.Reservation) (string, error) {
	var list []finderInstance

	for _, r := range reservations {
		instance := r.Instances[0]
		var f finderInstance

		f.State = *instance.State.Name
		// You can't connect to non running instances, not all fields defined.
		if f.State != "running" {
			continue
		}

		f.Hostname = *instance.PrivateDnsName
		f.IP = *instance.PrivateIpAddress
		f.AZ = *instance.Placement.AvailabilityZone
		f.ID = *instance.InstanceId
		f.Type = *instance.InstanceType
		f.InstanceGroup = getTag(instance.Tags, "kops.k8s.io/instancegroup")
		f.Role = getTag(instance.Tags, "kops.k8s.io/instancegroup")
		if getTag(instance.Tags, "k8s.io/role/node") == "1" {
			f.Role = "Node"
		} else {
			f.Role = "Control Node"
		}

		list = append(list, f)
	}

	if len(list) == 0 {
		err := fmt.Errorf("no instances returned, is the selected cluster online?")
		return "", err
	}

	idx, err := fuzzyfinder.Find(
		list,
		func(i int) string {
			return fmt.Sprintf("%s - %s - %s", list[i].Hostname, list[i].Role, list[i].InstanceGroup)
		},
		fuzzyfinder.WithPreviewWindow(func(i, w, h int) string {
			if i == -1 {
				return ""
			}
			return fmt.Sprintf("Hostname: %s (%s)\nRole: %s\nType: %s\nInstanceGroup: %s\nState: %s\nAZ: %s\nID: %s",
				list[i].Hostname,
				list[i].IP,
				list[i].Role,
				list[i].Type,
				list[i].InstanceGroup,
				list[i].State,
				list[i].AZ,
				list[i].ID,
			)
		}))
	if err != nil {
		log.Fatal(err)
	}

	return list[idx].Hostname, nil
}

// getTag returns the value of the given AWS Tag
func getTag(tags []*ec2.Tag, tagToFind string) string {
	for _, t := range tags {
		if *t.Key == tagToFind {
			return *t.Value
		}
	}
	return ""
}

// getInstance gets required details for a given instance
func getInstance(region, hostname string) (ec2.Instance, error) {
	svc := ec2.New(session.New(), aws.NewConfig().WithRegion(region))
	input := &ec2.DescribeInstancesInput{
		Filters: []*ec2.Filter{
			{
				Name: aws.String("private-dns-name"),
				Values: []*string{
					aws.String(hostname),
				},
			},
		},
	}

	result, err := svc.DescribeInstances(input)
	if err != nil {
		if aerr, ok := err.(awserr.Error); ok {
			switch aerr.Code() {
			default:
				fmt.Println(aerr.Error())
			}
		} else {
			// Print the error, cast err to awserr.Error to get the Code and
			// Message from an error.
			fmt.Println(err.Error())
		}
		return ec2.Instance{}, err
	}

	instance := ec2.Instance{}

	for _, r := range result.Reservations {
		for _, i := range r.Instances {
			instance = *i
		}
	}

	if reflect.DeepEqual(instance, ec2.Instance{}) {
		return instance, fmt.Errorf("No instances returned, check your instance name.")
	}

	fmt.Printf("\nInstance selected: %s\n", hostname)

	return instance, nil
}

// connect allows users to connect to a given ec2 instance by:
// * Generating a one time use SSH Keypari
// * Sending the public key to the instance via AWS EC2 Instance Connect
// * Connects a user to a terminal on the given instance
func connect(instance ec2.Instance, sshUser string, region string) error {
	if instance.Placement == nil || instance.Placement.AvailabilityZone == nil {
		return fmt.Errorf("instance does not have an availability zone")
	}

	fmt.Println("Generating SSH Keypair")
	privateKey, err := rsa.GenerateKey(rand.Reader, 4096)
	pub, _ := ssh.NewPublicKey(&privateKey.PublicKey)
	pubString := string(ssh.MarshalAuthorizedKey(pub))

	fmt.Println("Preparing to send public key to Instance Connect")
	az := instance.Placement.AvailabilityZone
	host := instance.PrivateIpAddress
	instanceId := instance.InstanceId
	svc := ec2instanceconnect.New(session.New(), aws.NewConfig().WithRegion(region))

	input := &ec2instanceconnect.SendSSHPublicKeyInput{
		AvailabilityZone: aws.String(*az),
		InstanceId:       aws.String(*instanceId),
		InstanceOSUser:   aws.String(sshUser),
		SSHPublicKey:     aws.String(pubString),
	}

	_, err = svc.SendSSHPublicKey(input)
	if err != nil {
		if aerr, ok := err.(awserr.Error); ok {
			switch aerr.Code() {
			case ec2instanceconnect.ErrCodeAuthException:
				fmt.Println(ec2instanceconnect.ErrCodeAuthException, aerr.Error())
			case ec2instanceconnect.ErrCodeInvalidArgsException:
				fmt.Println(ec2instanceconnect.ErrCodeInvalidArgsException, aerr.Error())
			case ec2instanceconnect.ErrCodeServiceException:
				fmt.Println(ec2instanceconnect.ErrCodeServiceException, aerr.Error())
			case ec2instanceconnect.ErrCodeThrottlingException:
				fmt.Println(ec2instanceconnect.ErrCodeThrottlingException, aerr.Error())
			case ec2instanceconnect.ErrCodeEC2InstanceNotFoundException:
				fmt.Println(ec2instanceconnect.ErrCodeEC2InstanceNotFoundException, aerr.Error())
			default:
				fmt.Println(aerr.Error())
			}
		} else {
			// Print the error, cast err to awserr.Error to get the Code and
			// Message from an error.
			fmt.Println(err.Error())
		}
		return err
	}

	fmt.Println("SSH Key Successfully Transmitted")

	fmt.Println("\nPreparing to Connect to host")
	client, session, err := setupSSHClient(sshUser, *host, privateKey)
	if err != nil {
		panic(err)
	}

	// Terminal connection code adapted from: https://gist.github.com/atotto/ba19155295d95c8d75881e145c751372
	fd := int(os.Stdin.Fd())
	state, err := terminal.MakeRaw(fd)
	if err != nil {
		return fmt.Errorf("terminal make raw: %s", err)
	}
	defer terminal.Restore(fd, state)

	w, h, err := terminal.GetSize(fd)
	if err != nil {
		return fmt.Errorf("terminal get size: %s", err)
	}

	modes := ssh.TerminalModes{
		ssh.ECHO:          1,
		ssh.TTY_OP_ISPEED: 14400,
		ssh.TTY_OP_OSPEED: 14400,
	}

	term := os.Getenv("TERM")
	if term == "" {
		term = "xterm-256color"
	}
	if err := session.RequestPty(term, h, w, modes); err != nil {
		return fmt.Errorf("session xterm: %s", err)
	}

	session.Stdout = os.Stdout
	session.Stderr = os.Stderr
	session.Stdin = os.Stdin

	if err := session.Shell(); err != nil {
		return fmt.Errorf("session shell: %s", err)
	}

	if err := session.Wait(); err != nil {
		if e, ok := err.(*ssh.ExitError); ok {
			switch e.ExitStatus() {
			case 130:
				return nil
			}
		}
		return fmt.Errorf("ssh: %s", err)
	}

	client.Close()

	return nil
}

// setupSSHClient sets up required values and config to connect to a given host and return a client session
func setupSSHClient(user, host string, privateKey *rsa.PrivateKey) (*ssh.Client, *ssh.Session, error) {
	privateKeyPEM := &pem.Block{Type: "RSA PRIVATE KEY", Bytes: x509.MarshalPKCS1PrivateKey(privateKey)}
	pem := pem.EncodeToMemory(privateKeyPEM)

	signer, err := ssh.ParsePrivateKey(pem)
	if err != nil {
		log.Fatalf("unable to parse private key: %v", err)
	}

	sshConfig := &ssh.ClientConfig{
		User: user,
		Auth: []ssh.AuthMethod{ssh.PublicKeys(signer)},
	}
	sshConfig.HostKeyCallback = ssh.InsecureIgnoreHostKey()

	hostPort := fmt.Sprintf("%s:22", host)
	client, err := ssh.Dial("tcp", hostPort, sshConfig)
	if err != nil {
		return nil, nil, err
	}

	session, err := client.NewSession()
	if err != nil {
		client.Close()
		return nil, nil, err
	}

	return client, session, nil
}
