#!/bin/bash

if [ -z $1 ]; then
  echo "Error executing $0, please ensure proper format and arguments"
  echo "e.g. $0 v0.35.0 01.us-east-2.dev.devops.k8s.sonos.com"
  echo "  This script will check to see if the prometheus namespace crds label matches the passed"
  echo "version.  If the versions don't match, crds will be removed so they can be re-added."
  exit 1
fi

newVersion=$1
context=$2

crdVersion=$(kubectl get namespace sonos-system-prometheus --template={{.metadata.labels.crdVersion}} --context $context)

if [ "$crdVersion" != "$newVersion" ]; then
  echo "Removing CRDs since they're out of date.  This may be disruptive to Prometheus."
  sleep 2
  kubectl --context $context delete crd alertmanagers.monitoring.coreos.com \
                                        podmonitors.monitoring.coreos.com \
                                        prometheuses.monitoring.coreos.com \
                                        prometheusrules.monitoring.coreos.com \
                                        servicemonitors.monitoring.coreos.com
  while true; do
    #> /dev/null 2>&1
    count=$(kubectl api-resources --context $context | grep monitoring.coreos.com | wc -l | awk '{print $1}')
    if (($count == 0)); then
      break;
    fi
    echo .
    sleep 1
  done
fi

echo sleeping
sleep 5