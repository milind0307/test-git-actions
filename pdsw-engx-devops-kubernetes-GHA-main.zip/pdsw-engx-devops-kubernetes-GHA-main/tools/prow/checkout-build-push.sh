#!/bin/bash

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../../" >/dev/null 2>&1 && pwd )"

###############################
# docker-promote-prod.sh - The goal of this script is to checkout a version of a given dependency.
#  * The version is stored in a yaml file so YQ will be used to extract that version.
#  * Git will checkout the given git ref of a repository.
#  * We then build and publish the docker container with the image and version tags.
###############################

# Assume we want to pull down a tag vs a branch. User can override.
# VERSION_FILE_PATH
# YAML_TAG_LOCATION
# YAML_DOCKER_TAG_LOCATION
# YAML_BUILD_GIT_REF_LOCATION
# DOCKERFILE_PATH
# IMAGE_NAME

DOCKER_PUBLISH=${DOCKER_PUBLISH:-false}

if [ -z ${VERSION_FILE_PATH} ] || [ -z ${YAML_BUILD_GIT_REF_LOCATION} ]  || [ -z ${YAML_DOCKER_TAG_LOCATION} ] || [ -z ${DOCKERFILE_PATH} ] || [ -z ${IMAGE_NAME} ]; then
  echo "Required environment variables not defined."
  echo ""
  echo "$0  - Please define:"
  echo "VERSION_FILE_PATH = The file path local to the root of this directory that contains the yaml path to a version"
  echo "YAML_BUILD_GIT_REF_LOCATION = The yaml path to git ref that we should checkout prior to building"
  echo "YAML_DOCKER_TAG_LOCATION = The yaml path to the version value we should tag the docker container"
  echo "DOCKERFILE_PATH = Path of a dockerfile's directory.  See .prow.yaml for sample configs"
  echo "IMAGE_NAME = The full name of the docker image being built and published."
  exit 1
fi

BUILD_TAG=$(${ROOT}/tools/bin/yq.sh read ${ROOT}/${VERSION_FILE_PATH} ${YAML_BUILD_GIT_REF_LOCATION})
PUSH_TAG=$(${ROOT}/tools/bin/yq.sh read ${ROOT}/${VERSION_FILE_PATH} ${YAML_DOCKER_TAG_LOCATION})

cd ${DOCKERFILE_PATH}
git checkout ${BUILD_TAG}

docker build -t ${IMAGE_NAME}:${PUSH_TAG} .

if [ "${DOCKER_PUBLISH}" = "true" ]; then
  docker push ${IMAGE_NAME}:${PUSH_TAG}
else
  echo "Skipping push, please set DOCKER_PUBLISH to true."
fi
