#!/bin/bash

set -e
set -o pipefail

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"
TEMP_DIR="${ROOT}/.tmp"
CONFIG_REPO=${CONFIG_REPO:-"pdsw-devops-kubernetes-config"} # defaults to PDSW DevOps config repo
CONFIG_DIR="${TEMP_DIR}/${CONFIG_REPO}"

if [ ! -d "${CONFIG_DIR}" ]; then
  mkdir -p "${TEMP_DIR}"
  if [ -n "${CONFIG_REPO_PATH}" ]; then
    echo "\$CONFIG_REPO_PATH is set, symlinking ${CONFIG_REPO_PATH} to ${CONFIG_DIR}"
    ln -s $(realpath "${CONFIG_REPO_PATH}") "${CONFIG_DIR}"
  elif [ -n "${CONFIG_BRANCH}" ]; then
    echo "Cloning config repo on branch '${CONFIG_BRANCH}', set \$CONFIG_REPO_PATH to use local config repo instead"
    echo
    git clone -b $CONFIG_BRANCH "https://github.com/Sonos-Inc/${CONFIG_REPO}.git" "${TEMP_DIR}/${CONFIG_REPO}"
  else
    echo "Cloning config repo with branch main, set \$CONFIG_BRANCH to use a different branch or \$CONFIG_LOCAL=true to use local config repo instead"
    echo
    git clone "https://github.com/Sonos-Inc/${CONFIG_REPO}.git" "${TEMP_DIR}/${CONFIG_REPO}"
  fi
else
  echo "Config directory already exists (${CONFIG_DIR}), leaving it as-is, see available 'config-*' targets with 'make help'"

  # Disable strict exit since this sometimes breaks when a branch doesn't exist upstream
  set +e

  GIT_COMMAND="git --git-dir ${CONFIG_DIR}/.git"
  CURRENT_BRANCH=$(${GIT_COMMAND} rev-parse --abbrev-ref HEAD)
  CURRENT_SHA=$(${GIT_COMMAND} rev-parse ${CURRENT_BRANCH})

  UPSTREAM_SHA=$(${GIT_COMMAND} rev-parse origin/${CURRENT_BRANCH} 2> /dev/null)
  set -e

  # If branch != main
  if [ "${CURRENT_BRANCH}" != "main" ]; then
    echo
    echo "!! Warning config repo branch ${CURRENT_BRANCH} is not main !!"
  fi

  # If upstream exists
  if [ -n "${UPSTREAM_SHA}" ]; then
    if [ "${CURRENT_SHA}" != "${UPSTREAM_SHA}" ]; then
      echo
      echo "!! Warning config repo branch out of date !!"
      echo "    Run 'make config-pull' to update."
    fi
  fi
fi
