#!/bin/bash

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"
KUBECTL=${ROOT}/tools/bin/kubectl.sh

if [ ! -n "$TMPDIR" ]; then
  TMPDIR=/tmp
fi

if [ -z $1 ]; then
  echo "Error executing $0, please ensure proper format and arguments"
  echo "This script will check to see if a cluster is ready for helm deployment or other post-deployment actions"
  echo "$0 <context name>"
  exit 1
fi

context=$1

echo "Waiting for all pods to be in a ready state on $context"

# Count of successful checks with all pods up
count=0

color-green() { # Green
  echo -e "\x1B[0;32m${@}\x1B[0m"
}

color-red() { # Red
  echo -e "\x1B[0;31m${@}\x1B[0m"
}

while true; do
  #> /dev/null 2>&1
  not_ready_pods=$(${KUBECTL} get pods --all-namespaces --context $context | grep -v Completed | grep -v Evicted | grep -v '[sonos-system.*|kube-system]' | grep -Ev '([0-9]+)/\1' | wc -l)
  if (($not_ready_pods == "1")); then
    let "count+=1"
    echo All pods ready, successes: ${count}/5
    # Extra sleep time to make sure we're watching for additional crashloops
    sleep 5
  else
    # Notify the user if we've alrady had successful counts
    if [ $count -ge 1 ]; then
      echo $(color-red Failure detected, resetting counter.)
    fi
    # Reset count if any failures occur
    count=0
  fi
  if [ $count -ge 5 ]; then
    tmpKubectlOutput=$(mktemp ${TMPDIR}/kubectl.XXXXXXXXXX)
    exec 3>"$tmpKubectlOutput"
    rm "$tmpKubectlOutput"
    ${KUBECTL} get pods --all-namespaces --context $context > $tmpKubectlOutput

    echo ""
    echo $(color-green "All pods up!")
    echo ""
    echo $(color-green "=======================================================================================================================")
    awk '{print "\x1B[0;32m" $0 "\x1B[0m"}' $tmpKubectlOutput
    echo $(color-green "=======================================================================================================================")
    echo ""
    break
  fi
  echo .
  sleep 1
done
