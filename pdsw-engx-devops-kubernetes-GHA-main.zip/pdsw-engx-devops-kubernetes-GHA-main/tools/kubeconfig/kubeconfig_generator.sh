#!/bin/bash

# This script is adapted from https://docs.armory.io/docs/armory-admin/manual-service-account/#get-the-service-account-and-token
# It can be used to generate a kubeconfig file for a service account for consumption by automation

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../../" >/dev/null 2>&1 && pwd )"
TEMP_DIR="${ROOT}/.tmp"
KUBECTL=${ROOT}/tools/bin/kubectl.sh

if [ -z $1 ]; then
  echo "Error executing $0, please ensure proper format and arguments"
  echo "This script generates a kubeconfig in the '.tmp/kubeconfig' directory for a specified Service Account"
  echo "e.g. $0 <namespace> <serviceaccount> <context> <name>"
  exit 1
fi

# Namespace of Service Account
NAMESPACE=$1
# Service Account
SERVICE_ACCOUNT=$2
# Cluster Context
CONTEXT=$3
# Name of the Context you would like to use for your kubeconfig
NAME=$4

KUBECONFIG_FILE="kubeconfig-sa"

SECRET_NAME=$(${KUBECTL} get serviceaccount ${SERVICE_ACCOUNT} \
  --context ${CONTEXT} \
  --namespace ${NAMESPACE} \
  -o jsonpath='{.secrets[0].name}')
TOKEN_DATA=$(${KUBECTL} get secret ${SECRET_NAME} \
  --context ${CONTEXT} \
  --namespace ${NAMESPACE} \
  -o jsonpath='{.data.token}')

TOKEN=$(echo ${TOKEN_DATA} | base64 -d)

# Create dedicated kubeconfig
# Create a full copy
${KUBECTL} config view --raw > ${TEMP_DIR}/${KUBECONFIG_FILE}.full.tmp
# Switch working context to correct context
${KUBECTL} --kubeconfig ${TEMP_DIR}/${KUBECONFIG_FILE}.full.tmp config use-context ${CONTEXT}
# Minify
${KUBECTL} --kubeconfig ${TEMP_DIR}/${KUBECONFIG_FILE}.full.tmp \
  config view --flatten --minify > ${TEMP_DIR}/${KUBECONFIG_FILE}.tmp
# Rename context
${KUBECTL} config --kubeconfig ${TEMP_DIR}/${KUBECONFIG_FILE}.tmp \
  rename-context ${CONTEXT} ${NAME}
# Create token user
${KUBECTL} config --kubeconfig ${TEMP_DIR}/${KUBECONFIG_FILE}.tmp \
  set-credentials ${CONTEXT}-${NAMESPACE}-token-user \
  --token ${TOKEN}
# Set context to use token user
${KUBECTL} config --kubeconfig ${TEMP_DIR}/${KUBECONFIG_FILE}.tmp \
  set-context ${NAME} --user ${CONTEXT}-${NAMESPACE}-token-user
# Set context to correct namespace
${KUBECTL} config --kubeconfig ${TEMP_DIR}/${KUBECONFIG_FILE}.tmp \
  set-context ${NAME} --namespace ${NAMESPACE}
# Flatten/minify kubeconfig
${KUBECTL} config --kubeconfig ${TEMP_DIR}/${KUBECONFIG_FILE}.tmp \
  view --flatten --minify > ${TEMP_DIR}/${KUBECONFIG_FILE}
# Remove tmp
rm ${TEMP_DIR}/${KUBECONFIG_FILE}.full.tmp
rm ${TEMP_DIR}/${KUBECONFIG_FILE}.tmp


exit 0