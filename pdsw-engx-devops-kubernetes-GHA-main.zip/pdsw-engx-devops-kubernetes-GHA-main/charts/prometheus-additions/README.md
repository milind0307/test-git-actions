# Prometheus Additions

## Grafana Dashboards

Note for future developers on these Grafana Dashboards - Many of these were adapted from the open source dashboards found here: <https://github.com/kubernetes-monitoring/kubernetes-mixin>. These are build with jsonnet and need to built locally for testing (installation notes on the page)

### Dashboard Local Development

We use configmaps that contain the raw JSON data to setup our dashboards, which means that you will need to both run `make helmfile-sync` to update the configmaps, as well as restart the grafana deployment to roll-over the pods.

Working JSON files can be tricky so I found it useful to edit the dashboards in UI then copy the raw JSON into your local files.
