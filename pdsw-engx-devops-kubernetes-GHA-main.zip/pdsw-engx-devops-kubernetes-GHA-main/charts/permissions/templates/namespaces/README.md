# Note on these namespaces

These namespaces were created as a part of PDOPS-4362. These namespaces are deployed manually:

```bash
kubectl apply -f <file_name>
```

TODO: We will eventually want to change this behavior (i.e. add this to the access repo).
