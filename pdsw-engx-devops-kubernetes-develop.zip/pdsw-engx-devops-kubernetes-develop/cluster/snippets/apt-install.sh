#!/usr/bin/env bash

export DEBIAN_FRONTEND=noninteractive

apt-get update

nohup apt-get install -yq --no-install-recommends \
  netcat-traditional \
  bridge-utils \
  perl \
  unattended-upgrades \
  cgroupfs-mount \
  util-linux \
  python-apt \
  pigz \
  wireguard \
  libseccomp2 \
  git \
  nfs-common \
  libapparmor1 \
  iptables \
  logrotate \
  curl \
  wget \
  ethtool \
  libltdl7 \
  apt-transport-https \
  conntrack \
  ebtables \
  socat \
  less &
