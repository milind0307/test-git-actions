#!/bin/bash

##
# This script should generate a markdown table of jobs.
#
# Job names must start with `- name: job-name-here`
# Job descriptions must start with `## Job description here`
#
# After running, copy the outputed final.md and paste it into the readme.md
#
##

SAVEIFS=$IFS   # Save current IFS
IFS=$'\n'      # Change IFS to new line
# IFS=$SAVEIFS   # Restore IFS

dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )/" >/dev/null 2>&1 && pwd )"


jobsPath=${dir}/jobs.md
refsPath=${dir}/refs.md
finalPath=${dir}/final.md

# Cleanup old runs
rm -rf ${jobsPath} ${refsPath} ${finalPath}

# Find files to iterate over
cd ${dir}
files="*.yaml"

# Header setup

header1="| Test name | Trigger | Prow Link | Description |"
header2="| :-- | :-- | :-- | :-- |"

echo $header1 > ${jobsPath}
echo $header2 >> ${jobsPath}

## Yaml Parser

for file in $files; do
  branch="develop"

  descriptions=$(grep -E '(^##.*)' ${file} | sed -E 's/## (.*)/\1/g')
  descriptions=($descriptions)
  names=$(grep -E '(^- name: .*)' ${file} | sed -E 's/- name: (.*)/\1/g')
  names=($names)


  # Output jobs and descriptions
  for (( i=0; i<${#names[@]}; i++ ))
  do
    # Determine type of job
    prefix=$(echo "${names[$i]}" | cut -d- -f1)
    type="Post Merge"
    if [ "${prefix}" = "presubmit" ]; then
      type="Pull Request"
    fi

    echo "| [${names[$i]}] | ${type} | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=${names[$i]}) | ${descriptions[$i]} |" >> ${jobsPath}
    echo "[${names[$i]}]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/${branch}/.prow/${file}" >> ${refsPath}
  done
done

# Combine docs
cat ${jobsPath} > ${finalPath}
echo "" >> ${finalPath}
echo "<!-- Link Refs -->" >> ${finalPath}
echo "" >> ${finalPath}
cat ${refsPath} >> ${finalPath}