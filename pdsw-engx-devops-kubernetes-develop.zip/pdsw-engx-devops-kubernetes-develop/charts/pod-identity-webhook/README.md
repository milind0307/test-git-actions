# Amazon EKS Pod Identity Webhook

This is a basic helm chart for the EKS pod identity webhook based on the files that can be found [here](https://github.com/aws/amazon-eks-pod-identity-webhook/tree/master/deploy).

Essentially, all this chart deploys is a daemonset that runs on control nodes and a mutating webhook. This can be run sans-webhook by disabling it in the values.

This also assumes that an OIDC provider has already been set up for your cluster.
