#!/usr/bin/env bash

set -e

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"
TEMP_DIR="${ROOT}/.tmp"
# Setup Kubectl
ln -sf ${ROOT}/tools/bin/kubectl.sh /usr/local/bin/kubectl


# ArgoCD syncing

echo ""
echo "Argo syncing"
echo ""

# Grab secrets from cluster
secret=$(kubectl get sa --context ${CLUSTER_NAME} -n sonos-system sonos-system-argocd-manager -o=jsonpath='{.secrets[0].name}')
ca=$(kubectl get secret --context ${CLUSTER_NAME} -n sonos-system ${secret} -o=jsonpath='{.data.ca\.crt}')
token=$(kubectl get secret --context ${CLUSTER_NAME} -n sonos-system ${secret} -o=jsonpath='{.data.token}' | base64 -d)

# Remove cluster config so we can target _this_ build cluster.
kubectl config delete-cluster ${CLUSTER_NAME}

# Create argo cluster secret for argo deployments to clusters
cat << EOF | kubectl apply -n app-argo -f -
apiVersion: v1
kind: Secret
metadata:
  name: ${CLUSTER_NAME}-automated
  labels:
    argocd.argoproj.io/secret-type: cluster
type: Opaque
stringData:
  name: ${CLUSTER_NAME}-automated
  server: https://api.${CLUSTER_NAME}
  config: |
    {
      "bearerToken": "${token}",
      "tlsClientConfig": {
        "insecure": false,
        "caData": "${ca}"
      }
    }
EOF

echo ""
echo "Argo syncing Complete"
echo ""