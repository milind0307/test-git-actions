#!/usr/bin/env bash

set -e

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"
TEMP_DIR="${ROOT}/.tmp"
CONFIG_REPO=${CONFIG_REPO:-"pdsw-devops-kubernetes-config"} # defaults to PDSW DevOps config repo
CONFIG_DIR="${TEMP_DIR}/${CONFIG_REPO}"

YQ_BINARY="${ROOT}/tools/bin/yq.sh"
# To trigger any debug modes & toggle automation components
export CI=1

# Assumes CLUSTER_NAME and AWS_REGION is set outside this script

# Source equivalent
${ROOT}/tools/configfetcher.sh
CONFIG_OUTPUT=$(${ROOT}/tools/configmerger.sh ${CLUSTER_NAME})
# We do not use the real cluster role since the permissions are actually granted through the AWS_PROFILE variable and kiam
AWS_S3_BUCKET=$(${YQ_BINARY} r ${CONFIG_OUTPUT} kops_bucket)

# Set tier value from merged config
TIER=$(${YQ_BINARY} r ${CONFIG_OUTPUT} tier)
CLUSTER_SUBDOMAIN=$(${YQ_BINARY} r ${CONFIG_OUTPUT} cluster.subdomain)
if [ "$CLUSTER_SUBDOMAIN" = "test.k.do.ws.sonos.com" ]; then # send test cluster notifications to int and test channels
EXTRA_CHANNELS="@slack-sonos-env-int"
else
EXTRA_CHANNELS=""
fi

# Send a datadog event that a cluster event is starting
if [ "$TIER" = "tier2" ]; then # current implementation of this script only applies to tier2
curl -X POST "https://api.datadoghq.com/api/v1/events" \
-H "Content-Type: application/json" \
-H "DD-API-KEY: ${DD_API_KEY}" \
-d @- << EOF
{
    "text": "@slack-sonos-env-test ${EXTRA_CHANNELS} \n Cluster Impacted: ${CLUSTER_NAME} \n Impact: Upgrading cluster with latest SHA on develop branch of k8s repo: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes",
    "title": "Kubernetes Update: Started",
    "alert_type": "info",
    "source_type_name": "kubernetes",
    "tags" : ["cluster-update","${CLUSTER_NAME}"]
}
EOF
fi

# export AWS_PROFILE=default
export KOPS_STATE_STORE=s3://${AWS_S3_BUCKET}/kops

if ! [[ -z "${CONFIG_REPO_PATH}/${DEPLOY_HASH_FILE}" ]]; then
  DEPLOY_HASH=$(cat ${CONFIG_REPO_PATH}/${DEPLOY_HASH_FILE} | cut -d: -f2)
	echo ""
	echo "			Checking out ${DEPLOY_HASH}"
	echo ""
  git checkout ${DEPLOY_HASH}
fi

# Decrypt secrets
gpg --batch --passphrase $GITSECRET_PASSWORD -aq --import /gitsecret/key

cd ${CONFIG_DIR}
git secret reveal -p $GITSECRET_PASSWORD
cd ${ROOT}

mkdir -p touch $HOME/.aws
if ! grep -q "[default]" $HOME/.aws/config; then
  cat << EOF >> $HOME/.aws/config
[default]
region = ${AWS_REGION}
EOF
fi

# Setup Kubectl
ln -sf ${ROOT}/tools/bin/kubectl.sh /usr/local/bin/kubectl

# Debug Output
make debug

color-green() { # Green
  echo -e "\x1B[0;32m${@}\x1B[0m"
}

color-red() { # Red
  echo -e "\x1B[0;31m${@}\x1B[0m"
}

make alertmanager-silence

echo ""
echo "Run rolling-update-cluster-control-nodes"
echo ""

# Retry loop for rolling-update-cluster-control-nodes.
count=0

set +e

while [ $count -lt 3 ]; do
  make rolling-update-cluster-control-nodes

  if [ $? -eq 0 ]; then
    echo ""
    echo $(color-green "rolling-update-cluster-control-nodes exited successfully!")
    echo ""
    break
  else
    echo ""
    echo $(color-red "Failure found, beginning rolling-update-cluster-control-nodes again.")
    echo ""
    count=$(( $count + 1 ))
  fi
done

set -e

if [ $count -ge 3 ]; then
    echo ""
    echo $(color-red "rolling-update-cluster-control-nodes retried 3 times and did not complete successfully.")
    echo ""
    make alertmanager-expire
    exit 1
else
    echo ""
    echo $(color-green "rolling-update-cluster-control-nodes Complete!")
    echo ""
fi

echo ""
echo "Run rolling-update-cluster-nodes"
echo ""

# Retry loop for rolling-update-cluster-nodes.
count=0

set +e

while [ $count -lt 3 ]; do
  make rolling-update-cluster-nodes

  if [ $? -eq 0 ]; then
    echo ""
    echo $(color-green "rolling-update-cluster-nodes exited successfully!")
    echo ""
    break
  else
    echo ""
    echo $(color-red "Failure found, beginning rolling-update-cluster-nodes again.")
    echo ""
    count=$(( $count + 1 ))
  fi
done

set -e

if [ $count -ge 3 ]; then
    echo ""
    echo $(color-red "rolling-update-cluster-nodes retried 3 times and did not complete successfully.")
    echo ""
    make alertmanager-expire
    exit 1
else
    echo ""
    echo $(color-green "rolling-update-cluster-nodes Complete!")
    echo ""
fi

make alertmanager-expire

echo ""
echo "Rolling Update complete!"
echo ""

# Send a datadog event that a cluster event has ended
if [ "$TIER" = "tier2" ]; then # current implementation of this script only applies to tier2
curl -X POST "https://api.datadoghq.com/api/v1/events" \
-H "Content-Type: application/json" \
-H "DD-API-KEY: ${DD_API_KEY}" \
-d @- << EOF
{
    "text": "Cluster Impacted: ${CLUSTER_NAME} \n Impact: Cluster upgrade is now complete",
    "title": "Kubernetes Update: Ended",
    "alert_type": "info",
    "source_type_name": "kubernetes",
    "tags" : ["cluster-update","${CLUSTER_NAME}"]
}
EOF
fi