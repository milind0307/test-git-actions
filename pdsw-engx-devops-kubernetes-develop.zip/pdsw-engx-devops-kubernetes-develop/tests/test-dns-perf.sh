#!/usr/bin/env bash

set -e

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"
TEMP_DIR="${ROOT}/.tmp"

DNS_TEST="$1"

# To trigger any debug modes & toggle automation components
export CI=1

# Assumes CLUSTER_NAME and AWS_REGION is set outside this script

KUBECONFIG="${HOME}/.kube/config"

# Setup Kubectl
ln -sf ${ROOT}/tools/bin/kubectl.sh /usr/local/bin/kubectl

echo Setting up kubectl context for cluster ${CLUSTER_NAME}
echo ${ACCESS_CA} | base64 -d > /tmp/ca.crt
kubectl config set-cluster default --server=https://api.${CLUSTER_NAME} --certificate-authority=/tmp/ca.crt --embed-certs=true
kubectl config set-credentials default --token ${ACCESS_TOKEN}
kubectl config set-context --cluster default default --user default
kubectl config use-context default
chmod +r ${KUBECONFIG}
echo ""

mkdir -p touch $HOME/.aws
if ! grep -q "[default]" $HOME/.aws/config; then
  cat << EOF >> $HOME/.aws/config
[default]
region = ${AWS_REGION}
EOF
fi

PERF_TEST_REPO="${PERF_TEST_REPO}"
PERF_TEST_BUCKET="${PERF_TEST_BUCKET}"

apt-get update -q
apt-get install python3-pip -yq
pip3 install numpy -q
pip3 install pyyaml==5.4.1 -q

pushd ../${PERF_TEST_REPO}/dns
echo "Run Perf"
mkdir out/
python3 py/run_perf.py --dns-server kube-dns --use-cluster-dns --params params/kubedns/${DNS_TEST}.yaml --out-dir out
echo "Ingest"
python3 py/ingest.py --db out/db out/latest/*.out
cat out/latest/*.out
echo "Upload"
OUTPUT_DIR="$(date -u +"%Y-%m-%d")/$(date -u +"%T")"
aws s3 cp out/latest s3://${PERF_TEST_BUCKET}/${OUTPUT_DIR} --recursive
aws s3 cp out/db s3://${PERF_TEST_BUCKET}/${OUTPUT_DIR}/db
echo "Done"
popd