#!/usr/bin/env bash

set -o errexit
set -o nounset
set -o pipefail

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"
CONFIG_REPO=${CONFIG_REPO:="pdsw-devops-kubernetes-config"} # defaults to PDSW DevOps config repo
TEMP_DIR="${ROOT}/.tmp"
CONFIG_REPO_PATH="${CONFIG_REPO_PATH:-${TEMP_DIR}/${CONFIG_REPO}}" # can override
PERF_TEST_REPO="${PERF_TEST_REPO}"
PERF_TEST_BUCKET="${PERF_TEST_BUCKET}"

DNS_TEST="$1"

export AWS_REGION=us-east-1

mkdir -p touch $HOME/.aws
if ! grep -q "[default]" $HOME/.aws/config; then
  cat << EOF >> $HOME/.aws/config
[default]
region = ${AWS_REGION}
EOF
fi

apt-get update -q
apt-get install python3-pip -yq
pip3 install numpy -q
pip3 install pyyaml==5.4.1 -q

ln -sf ${ROOT}/tools/bin/kubectl.sh /usr/local/bin/kubectl
kubectl create namespace app-prow-test-pods

pushd ../${PERF_TEST_REPO}/dns
echo "Run Perf"
mkdir out/
python3 py/run_perf.py --dns-server kube-dns --use-cluster-dns --params params/kubedns/${DNS_TEST}.yaml --out-dir out
echo "Ingest"
python3 py/ingest.py --db out/db out/latest/*.out
cat out/latest/*.out
echo "Upload"
OUTPUT_DIR="$(date -u +"%Y-%m-%d")/$(date -u +"%T")"
aws s3 cp out/latest s3://${PERF_TEST_BUCKET}/${OUTPUT_DIR} --recursive
aws s3 cp out/db s3://${PERF_TEST_BUCKET}/${OUTPUT_DIR}/db
echo "Done"
popd
