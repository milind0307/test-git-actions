#!/usr/bin/env bash

set -o errexit
set -o nounset
set -o pipefail

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"
TEMP_DIR="${ROOT}/.tmp"
KYVERNO_BINARY="${ROOT}/tools/bin/kyverno.sh"

KYVERNO_POLICIES_PATH="${ROOT}/manifests/kyverno-policies"

${KYVERNO_BINARY} version

echo ""
echo "Run Kyverno Test Suite"
${KYVERNO_BINARY} test ${KYVERNO_POLICIES_PATH}