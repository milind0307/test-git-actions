#!/usr/bin/env bash

# The purpose of this script is to bootstrap a kind cluster.
# This will set up a kind cluster and will then hand off the
# run to a passed in script to act upon that kind cluster.

set -o errexit
set -o nounset
set -o pipefail

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"
CONFIG_REPO=${CONFIG_REPO:="pdsw-devops-kubernetes-config"} # defaults to PDSW DevOps config repo
TEMP_DIR="${ROOT}/.tmp"
CONFIG_REPO_PATH="${CONFIG_REPO_PATH:-${TEMP_DIR}/${CONFIG_REPO}}" # can override

KIND_BINARY="https://github.com/kubernetes-sigs/kind/releases/download/v0.14.0/kind-$(uname)-amd64"
KIND_IMAGE="kindest/node:v1.24.0@sha256:0866296e693efe1fed79d5e6c7af8df71fc73ae45e3679af05342239cdc5bc8e"

mkdir -p ${TEMP_DIR}

# Prep helm config
if [ -n "${CI:-}" ]; then
  echo ">>> Setting up helm config"
  mkdir -p ${HOME}/.config/helm
  if [ -e "/helm-artifactory-creds/repositories.yaml" ]; then
    echo ">>> Copying artifactory config"
    cp /helm-artifactory-creds/repositories.yaml ${HOME}/.config/helm
  fi
fi

KIND=${TEMP_DIR}/kind

curl -Lo ${KIND} ${KIND_BINARY}
chmod +x ${KIND}

export CLUSTER_NAME=kind-test
${KIND} create cluster --config ${CONFIG_REPO_PATH}/environments/${CLUSTER_NAME}/kind-config.yaml --image ${KIND_IMAGE} --name test --verbosity 2
export CLUSTER_NAME=kind-test
export CLUSTER_CONTEXT_OVERRIDE=kind-test

# Execute test script
if [ ! -z "$1" ]; then
  echo "Passing to '$1'"
  ./$1 ${@:2}
fi

${KIND} delete cluster --name test
