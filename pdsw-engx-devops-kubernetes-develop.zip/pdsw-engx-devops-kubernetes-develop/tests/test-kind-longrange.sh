#!/usr/bin/env bash

set -o errexit
set -o nounset
set -o pipefail

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"
CONFIG_REPO=${CONFIG_REPO:="pdsw-devops-kubernetes-config"} # defaults to PDSW DevOps config repo
TEMP_DIR="${ROOT}/.tmp"
CONFIG_REPO_PATH="${CONFIG_REPO_PATH:-${TEMP_DIR}/${CONFIG_REPO}}" # can override

# Ensure secrets file exists
touch ${CONFIG_REPO_PATH}/environments/${CLUSTER_NAME}/secrets.yaml

# Checkout BASE
git checkout ${PULL_BASE_SHA}

# Rollout BASE
make helmfile-sync

${ROOT}/tools/wait_for_pods_ready.sh ${CLUSTER_NAME}

# Checkout PULL
git checkout ${PULL_PULL_SHA}

# Upgrade to PULL
make helmfile-sync

${ROOT}/tools/wait_for_pods_ready.sh ${CLUSTER_NAME}
