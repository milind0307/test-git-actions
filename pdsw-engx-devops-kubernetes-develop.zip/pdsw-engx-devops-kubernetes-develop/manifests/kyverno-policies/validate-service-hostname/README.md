# Validate Service Hostname Policy

The Kubernetes API Server is unfortunately unaware of the cluster's name (see [here](https://stackoverflow.com/questions/38242062/how-to-get-kubernetes-cluster-name-from-k8s-api)) and as such can't be relied upon for this data when evaluating policies. A workaround used here is to use a configmap, deployed with the Kyverno helmfile, to read the cluster's name during runtime.
