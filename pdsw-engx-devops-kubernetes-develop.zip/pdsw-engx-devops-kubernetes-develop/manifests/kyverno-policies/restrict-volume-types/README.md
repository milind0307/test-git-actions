# Restrict Volume Type Policy

Pulled from OSS [here](https://github.com/kyverno/policies/tree/main/pod-security/restricted/restrict-volume-types).

Restrict the usage of non-core volume types to those defined through PersistentVolumes.
