# Disallow Host Ports Policy

Pulled from OSS [here](https://github.com/kyverno/policies/tree/main/pod-security/baseline/disallow-host-ports).

Dissallows access to host ports, which prevents potential snooping of network traffic outright or to a known list (essentially vaidates that `hostPort` fields are empty).
