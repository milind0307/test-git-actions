# Disallow Host Ports Policy

Pulled from OSS [here](https://github.com/kyverno/policies/tree/main/pod-security/baseline/disallow-host-namespaces).

Dissallows pods from accessing host namespaces since those namespaces allow access to shared information that can be used to elevate privileges.
