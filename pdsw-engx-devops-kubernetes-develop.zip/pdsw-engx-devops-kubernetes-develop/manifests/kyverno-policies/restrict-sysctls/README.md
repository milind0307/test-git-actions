# Disallow Privileged Containers Policy

Pulled from OSS [here](https://github.com/kyverno/policies/tree/main/pod-security/baseline/restrict-sysctls).

Disallows unsafe sysctls which can disable security mechanisms or impact all containers on a host. Safe sysctls are namespaced in the container or the Pod and is isolated from other Pods or processes on the same node.
