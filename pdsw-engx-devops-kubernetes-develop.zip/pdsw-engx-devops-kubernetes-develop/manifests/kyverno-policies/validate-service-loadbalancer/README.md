# Service Loadbalancer Validation

The logic applied here can be summarized as such:

```bash
if public
  apply service.beta.kubernetes.io/aws-load-balancer-security-groups annotation OR loadbalancer source ranges
else if private
  apply service.beta.kubernetes.io/aws-load-balancer-internal with true or 0.0.0.0/0
```
