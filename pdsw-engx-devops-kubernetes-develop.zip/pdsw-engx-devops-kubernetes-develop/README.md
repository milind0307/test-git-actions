# Sonos-K8s Cluster Automation

Sonos' Kubernetes cluster management automation.

The purpose of this repo is to facilitate the automated version management of a multi-cluster, multi-region Kubernetes environment. Multiple layers of tools are required to make a self servicable platform for application development, deployment and monitoring.

- [Sonos-K8s Cluster Automation](#sonos-k8s-cluster-automation)
  - [How we build our clusters](#how-we-build-our-clusters)
    - [Core tenants](#core-tenants)
  - [Dependencies](#dependencies)
    - [Brewfile](#brewfile)
    - [Artifactory](#artifactory)
  - [Configuration](#configuration)
    - [Default](#default)
    - [Custom Branch](#custom-branch)
    - [Custom Repo](#custom-repo)
    - [Local Repo](#local-repo)
  - [Docs](#docs)
  - [Basic Usage](#basic-usage)
  - [Sonos Cluster Dependencies](#sonos-cluster-dependencies)
  - [Automation](#automation)
    - [Test Jobs](#test-jobs)
    - [Renovate Bot](#renovate-bot)
  - [Releases](#releases)
  - [Tips](#tips)

## How we build our clusters

![Image of cluster build flow](docs/images/deployment_diagram/deployment_diagram.svg)

When building our cluster on aws it came down to 2 sets of tools: [AWS EKS](https://aws.amazon.com/eks/) and CONFIG_REPO_PATHKops](https://kops.sigs.k8s.io/). EKS hasn't provided many of the automation tools and configuration options that make sense when operating a Kubernetes cluster so the team selected Kops to build our infrastructure on, however we expect to re-evaluate these decisions from time to time in the future.

To attach our clusters to the Sonos Transit VPC and setup required IAM, S3 and Route 53 dependencies, we [run terraform](/terraform) after cluster creation.

Finally, we bootstrap each cluster with [cluster dependencies](helmfile.yaml) via helm and helmfile. Some components here are tied to specific terraform, kubernetes and kops versions.

All of these tools are driven via [templates](cluster/templates/) and [configuration files](https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/cluster/tiers/default/values.yaml). This allows configuration to be set, overridden at many levels and merged prior to deployment:

- AWS account - some values, such as credentials or s3 buckets are tied to a specific AWS Account
- Tier - lower tiered and less critical clusters may not have the same tools deployed as highly critical, tier 1 clusters.
- Cluster - we can always override configuration for a specific cluster.

### Core tenants

- Version lock every tool - Kubernetes, Kubectl, Kops, Terraform
- Every Value has a sane default
- Everything lives in git, clusters will come and go.

## Dependencies

### Brewfile

Basic kubernetes dependencies are stored in the `Brewfile` in this repo. Install them via:

```bash
brew bundle
```

### Artifactory

It's also good to use some of Sk8s tools to setup artifactory:

```bash
sk8s setup artifactory
```

This will walk you through logging into artifactory for docker images usage and helm login.

## Configuration

This repo does not contain cluster configuration. [The configuration repo used by Core Engineering DevOps can be found here.](https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config)

Instead, a configuration repo is either cloned from GitHub in `.tmp/`, or a local repo directory is symlinked in `.tmp/`. This can be performed with `source.sh`. If source has already run, you can use `$ make config`.

### Default

By default, both `source.sh` and `$ make config` will clone [pdsw-devops-kubernetes-config](https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config) on branch `main` in `.tmp/`.

### Custom Branch

For automation to clone a branch other than `main`, set the `$CONFIG_BRANCH` environment variable to your desired branch.

### Custom Repo

For automation (`source.sh` or `make`) to clone a repo other than the default (`pdsw-devops-kubernetes-config`), set the `$CONFIG_REPO` environment variable to the name of the repo. Must be within the Sonos-Inc GitHub organization.

### Local Repo

If you want to use a local copy of a config repo, set the `$CONFIG_REPO_PATH` environment variable to the path (can be a relative path). The path provided will be symlinked to `.tmp/$CONFIG_REPO`. You can work with this local copy as though it is in `.tmp/`:

```
export CONFIG_REPO_PATH=/home/my.account/code/pdsw-devops-kubernetes-config
```

To unset this variable and clone a GitHub repo instead, you can export the variable as an empty string (`$ export CONFIG_REPO_PATH=''`).

Note: Removing the symlink (`.tmp/$CONFIG_REPO`) will not remove the linked "real" directory unless you use a destructive command that follows symlinks (`rm -rf` is SAFE by default).

## Docs

Checkout [the docs folder](docs) for the full list or a few highlights here:

- [Cluster Training Resources](docs/training.md)
- [Create Shared Clusters](docs/creating-shared-clusters.md)
- [Cluster Templating](docs/templating.md)
- [Auth](docs/auth.md)
- [Regions](docs/regions.md)
- [Spot](docs/spot.md)
- [Secret Encryption](docs/secret-encryption.md)
- [OIDC Issuers/Dex](docs/oidc-issuers-environments.md)
- [Custom kOps builds](docs/kops-custom-build.md)

## Basic Usage

1. Clone repo and setup dependencies above.
2. Setup shell:

   ```bash
   # Point to a specific cluster
   # export CLUSTER_NAME=<cluster name here>
   export CLUSTER_NAME=tools.k.do.ws.sonos.com

   # export a debug value and you'll get addition output if you run into errors
   export DEBUG=true

   # Get config, set environment variables, decrypt gitsecrets, get AWS auth
   source source.sh

   # Ensure variables are seen in make
   make debug
   # Output all options
   make help
   ```

3. Spin up cluster

```bash
make cluster
```

## Sonos Cluster Dependencies

To configure our cluster dependencies via helm/helmfile, ensure `CLUSTER_NAME` is set and you have run `source source.sh` as mentioned above.

```bash
make helmfile-sync
```

Note, some pods may take a few minutes to come up.

To remove our dependencies, run:

```bash
make helmfile-delete
```

## Automation

This repo is automated by the devops team's [Prow bot](https://github.com/Sonos-Inc/pdsw-devops-prow).

For more information on interacting with Prow and our pull request process [visit our prow docs](https://github.com/Sonos-Inc/pdsw-devops-prow/blob/main/docs/working_with_prow.md).

Almost all prowjobs for this repo are configured in the [.prow](.prow) directory.

### Test Jobs

<!-- Update these using the generator script in .prow/generate.sh -->

| Test name                                              | Trigger      | Prow Link                                                                                                                                           | Description                                                                                                  |
| :----------------------------------------------------- | :----------- | :-------------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------- |
| [postsubmit-sonos-k8s-deploy-dev-devops-cluster]       | Post Merge   | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=postsubmit-sonos-k8s-deploy-dev-devops-cluster)       | Will run a cluster-update on the devops dev cluster with latest develop & roll over instances if necessary   |
| [postsubmit-sonos-kubernetes-connect-build-push]       | Post Merge   | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=postsubmit-sonos-kubernetes-connect-build-push)       | Build and push connect tool                                                                                  |
| [postsubmit-sonos-kubernetes-e2e]                      | Post Merge   | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=postsubmit-sonos-kubernetes-e2e)                      | Will spin up an entire cluster in automation and spins it back down                                          |
| [postsubmit-sonos-kubernetes-yamllint]                 | Post Merge   | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=postsubmit-sonos-kubernetes-yamllint)                 | Runs yaml lint on the prow config, tiers and environments                                                    |
| [postsubmit-sonos-kubernetes-kind]                     | Post Merge   | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=postsubmit-sonos-kubernetes-kind)                     | Builds and deploys our helm charts to a [kind cluster](https://kind.sigs.k8s.io/)                             |
| [postsubmit-sonos-kubernetes-cluster-template-lint]    | Post Merge   | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=postsubmit-sonos-kubernetes-cluster-template-lint)    | Templates a cluster configs given checked in (non secret) contstraints and helmfile lints each               |
| [postsubmit-sonos-kubernetes-terraform-validate]       | Post Merge   | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=postsubmit-sonos-kubernetes-terraform-validate)       | Runs terraform validate for the user                                                                         |
| [postsubmit-sonos-kubernetes-helmfile-lint-short]      | Post Merge   | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=postsubmit-sonos-kubernetes-helmfile-lint-short)      | Runs helmfile lint                                                                                           |
| [postsubmit-sonos-kubernetes-main-merge-echo]          | Post Merge   | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=postsubmit-sonos-kubernetes-main-merge-echo)          | Runs echo command on merge to main branch for periodics to trigger a SHA update then a stage cluster upgrade |
| [presubmit-sonos-kubernetes-connect-build]             | Pull Request | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=presubmit-sonos-kubernetes-connect-build)             | Build connect tool                                                                                           |
| [presubmit-sonos-kubernetes-connect-test]              | Pull Request | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=presubmit-sonos-kubernetes-connect-test)              | Test connect tool                                                                                            |
| [presubmit-sonos-kubernetes-e2e-cleanup]               | Pull Request | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=presubmit-sonos-kubernetes-e2e-cleanup)               | Manual job to clean up a failed e2e test cluster                                                             |
| [presubmit-sonos-kubernetes-renovate-config-validator] | Pull Request | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=presubmit-sonos-kubernetes-renovate-config-validator) | Check renovate config to make sure it's formatted properly                                                   |
| [presubmit-sonos-kubernetes-renovate-dry-run]          | Pull Request | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=presubmit-sonos-kubernetes-renovate-dry-run)          | A Dry run version of renovate config, the real one runs as a periodic.                                       |
| [presubmit-sonos-kubernetes-terraform-validate]        | Pull Request | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=presubmit-sonos-kubernetes-terraform-validate)        | Runs terraform validate for the user                                                                         |
| [presubmit-sonos-kubernetes-terraform-init]            | Pull Request | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=presubmit-sonos-kubernetes-terraform-init)            | Runs terraform init                                                                                          |
| [presubmit-sonos-kubernetes-terraform-plan]            | Pull Request | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=presubmit-sonos-kubernetes-terraform-plan)            | Run terraform plan on tf changes                                                                             |
| [presubmit-sonos-kubernetes-yamllint]                  | Pull Request | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=presubmit-sonos-kubernetes-yamllint)                  | Runs yaml lint on the prow config, tiers and environments                                                    |
| [presubmit-sonos-kubernetes-kind]                      | Pull Request | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=presubmit-sonos-kubernetes-kind)                      | Builds and deploys our helm charts to a [kind cluster](https://kind.sigs.k8s.io/)                             |
| [presubmit-sonos-kubernetes-kind-longrange]            | Pull Request | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=presubmit-sonos-kubernetes-kind-longrange)            | Builds and deploys our helm charts to a kind cluster from BASE (main) and then upgrades to pull (develop)    |
| [presubmit-sonos-kubernetes-configmerger]              | Pull Request | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=presubmit-sonos-kubernetes-configmerger)              | Merges our configs and makes sure all required operations complete.                                          |
| [presubmit-sonos-kubernetes-cluster-template-lint]     | Pull Request | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=presubmit-sonos-kubernetes-cluster-template-lint)     | Templates a cluster configs given checked in (non secret) contstraints and helmfile lints each               |
| [presubmit-sonos-kubernetes-helmfile-diff]             | Pull Request | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=presubmit-sonos-kubernetes-helmfile-diff)             | Deploys the upstream helmfiles then upgrades to the current changes in a kind cluster                        |
| [presubmit-sonos-kubernetes-helmfile-lint-short]       | Pull Request | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=presubmit-sonos-kubernetes-helmfile-lint-short)       | Runs a short helmfile lint                                                                                   |
| [presubmit-dns-perf-testing-kind]                      | Pull Request | [Jobs](https://prow.build.k.do.ws.sonos.com/?repo=Sonos-Inc%2Fpdsw-engx-devops-kubernetes&job=presubmit-dns-perf-testing-kind)                      | Runs a test dns perf test on a kind cluster                                                                  |

<!-- Link Refs -->

[postsubmit-sonos-k8s-deploy-dev-devops-cluster]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/postsubmits-deploy.yaml
[postsubmit-sonos-kubernetes-connect-build-push]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/postsubmits-deploy.yaml
[postsubmit-sonos-kubernetes-e2e]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/postsubmits-e2e.yaml
[postsubmit-sonos-kubernetes-yamllint]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/postsubmits-tests.yaml
[postsubmit-sonos-kubernetes-kind]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/postsubmits-tests.yaml
[postsubmit-sonos-kubernetes-cluster-template-lint]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/postsubmits-tests.yaml
[postsubmit-sonos-kubernetes-terraform-validate]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/postsubmits-tests.yaml
[postsubmit-sonos-kubernetes-helmfile-lint-short]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/postsubmits-tests.yaml
[postsubmit-sonos-kubernetes-main-merge-echo]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/postsubmits-tests.yaml
[presubmit-sonos-kubernetes-connect-build]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/presubmits-connect.yaml
[presubmit-sonos-kubernetes-connect-test]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/presubmits-connect.yaml
[presubmit-sonos-kubernetes-e2e-cleanup]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/presubmits-optional.yaml
[presubmit-sonos-kubernetes-renovate-config-validator]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/presubmits-renovate.yaml
[presubmit-sonos-kubernetes-renovate-dry-run]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/presubmits-renovate.yaml
[presubmit-sonos-kubernetes-terraform-validate]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/presubmits-terraform.yaml
[presubmit-sonos-kubernetes-terraform-init]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/presubmits-terraform.yaml
[presubmit-sonos-kubernetes-terraform-plan]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/presubmits-terraform.yaml
[presubmit-sonos-kubernetes-yamllint]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/presubmits-tests.yaml
[presubmit-sonos-kubernetes-kind]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/presubmits-tests.yaml
[presubmit-sonos-kubernetes-kind-longrange]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/presubmits-tests.yaml
[presubmit-sonos-kubernetes-configmerger]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/presubmits-tests.yaml
[presubmit-sonos-kubernetes-cluster-template-lint]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/presubmits-tests.yaml
[presubmit-sonos-kubernetes-helmfile-diff]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/presubmits-tests.yaml
[presubmit-sonos-kubernetes-helmfile-lint-short]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/presubmits-tests.yaml
[presubmit-sonos-kubernetes-test-rego]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/presubmits-tests.yaml
[presubmit-dns-perf-testing-kind]: https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/.prow/presubmits-tests.yaml

### Renovate Bot

We run [renovate bot](https://docs.renovatebot.com/) to keep some of our dependencies up to date. We run renovate bot in a container using prow on a [periodic basis][periodic-sonos-kubernetes-renovate].
It will scan all files in this repository and try to open PRs for outdated dependencies. It will run a [validation job][presubmit-sonos-kubernetes-renovate-config-validator] and a [dry run job][presubmit-sonos-kubernetes-renovate-dry-run] whenever any renovate file is changed (see renovate\* files in [.github/](/.github)).

You can trigger a dry run (meaning PRs won't be opened) in any PR by running `/test renovate`.

It currently does not like our helmfiles since they contain templating but [regex and other checks should function](https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/f6245d80c887aa2f74ce45e583416506b662f851/.github/renovate.json#L7-L42).

For more info on usage and configuration options, view [Renovate Bot Documentation](https://docs.renovatebot.com/).

## Releases

Currently the release process is manual but the [Release drafter bot](https://probot.github.io/apps/release-drafter/) will automatically prep release notes here:

[https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/releases](https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/releases)

The process is outlined below:

1. Tag PRs with feature, bug fix or maintance to be included in proper part of release notes
2. Create merge request from develop to main
3. Once approved, merge pull request to main using a merge commit (required for Release drafter)
4. Edit draft release to create a tag off main for the given version
5. Release release.

## Tips

To disable the cluster warning and sleep, run:

```bash
export DISABLE_WARNING=true
```
