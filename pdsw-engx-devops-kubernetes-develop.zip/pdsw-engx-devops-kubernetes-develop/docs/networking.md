# Cluster Networking

Currently our suggested and default networking stack utilizes Calico which ships with Kops.  Kops supports a number of providers and a number of "bring your own" options.  CNI (Container Networking Interface) is considered the standard bring your own networking.  The providers Kops ships with are also CNIs however they are very tightly coupled to Kops releases.  Using your own external provider gives flexibility that we may require in the future.  You can find more information on Kops networking [here](https://kops.sigs.k8s.io/networking/).

## Currently supported options

* Calico
  * Overlay network
* AWS VPC CNI
  * VPC Networking with pods in the same IP space as instances
* CNI
  * With the CNI option we can install any CNI we wish
  * We chose an updated version of AWS VPC CNI that supports running pods in their own subnets

## Configuration

In a cluster values yaml:

```yaml
# Calico
cluster:
  networking: calico

# CNI
cluster:
  networking: cni
```

### References

* Calico
  * [Calico Kops documentation](https://kops.sigs.k8s.io/networking/#calico-example-for-cni-and-network-policy)
  * [Calico official documentation](https://www.projectcalico.org/)
  * [Calico yaml config in kops](https://github.com/kubernetes/kops/tree/master/upup/models/cloudup/resources/addons/networking.projectcalico.org)
    * `k8s-1.12.yaml.template` is used for kops 1.15 while future versions of kops may rely on newer versions.
    * Switch to the tag of the version of kops you want to check the manifest, these change constantly.

* AWS VPC CNI
  * [AWS VPC CNI docs from Kops](https://kops.sigs.k8s.io/networking/#amazon-vpc-backend)
  * [AWS VPC CNI from amazon](https://github.com/aws/amazon-vpc-cni-k8s)

* CNI
  * [General CNI docs on kops](https://kops.sigs.k8s.io/networking)
  * [AWS VPC CNI Config under CNI mode](https://github.com/aws/amazon-vpc-cni-k8s/blob/master/config/v1.6/aws-k8s-cni.yaml)
  * [AWS VPC CNI Custom Networking](https://docs.aws.amazon.com/eks/latest/userguide/cni-custom-network.html)
  * [Additional Documentation of our AWS VPC CNI Configuration](../experiments/addon-aws-node/README.md)
