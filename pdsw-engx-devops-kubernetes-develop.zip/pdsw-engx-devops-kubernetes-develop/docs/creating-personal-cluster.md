# Creating a Personal Cluster

Follow the instructions on the main README to start up your environment, replacing the `export CLUSTER_NAME` step with your own name as a prefix to `dev.k.do.ws.sonos.com`. Names such as `test-cluster.dev.k.do.ws.sonos.com` are acceptable, but `test-cluster.k.do.ws.sonos.com` is not. If no cluser name is selected, `test-$(whoami | cut -d. -f2).dev.k.do.ws.sonos.com` will be used. After that, run:

```bash
make cluster-up
```

This may take a while, and involves steps with both `kops` and `terraform`. When completed `kops` will insert the credentials required into your `kubectl` config. You can now run any other commands you may need to test on the cluster. A next step may be to run:

```bash
make helmfile-sync
```

This will sync all of our base Helm charts.

These can also be run in one command, which will both create the cluster and install our base helm charts:

```bash
make cluster
```
