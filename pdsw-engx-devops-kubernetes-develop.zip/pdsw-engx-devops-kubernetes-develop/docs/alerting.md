# Alerting

Alerting on the kubernetes infrastructure is handled by prometheus-operator. From prometheus-operator, alertmanager handles routing alerts to various notification services. Behavior of alert routing is determined by the [tier](tiers.md) of the cluster itself.

Definitions of secrets (slack URL & channels, PagerDuty integration keys) are found in your cluster's secrets.yaml

## Overview

We use Alertmanager to manage alerts based on metrics from prometheus. Alertmanager will raise an alert when a certain metric threshold is reached. Examples of these alerts can be found [here](https://prometheus.sandbox.k.do.ws.sonos.com/alerts).

We specify how an alert will be handled based on its tier.

### Scope

The scope of kubernetes infrastructure alerting is limited to the concern of the underlying kubernetes infrastructure. In practical terms, this means services limited to the `kube-system` namespace and any `sonos-system.*` namespace.

## Alert Notification Structure

Severity

|         | Notification Method(s)                      | Critical       | Warning        | Info           | Priority |
| ------- | ------------------------------------------- | -------------- | -------------- | -------------- | -------- |
| Tier1   | PagerDuty (critical escalation) & Slack     | 24/7           | Business Hours | Business Hours | P1/P2    |
| Tier2   | PagerDuty (non-critical escalation) & Slack | Business Hours | Business Hours | N/A            | P3/P4    |
| Tier3   | Slack                                       | N/A            | N/A            | N/A            | N/A      |
| Default | None                                        | N/A            | N/A            | N/A            | N/A      |

## Incident Priority

We automatically set priority levels on incidents in order to classify the severity of the incident and show end-customers the level of impact that an incident may have. All P1 and P2 class incidents will automatically show as impacting dependant services in the status dashboard of the [Kubernetes Business Service on Pagerdury](https://sonos.pagerduty.com/business-services/PQT73CE). Configuration of the priority levels is set such that tier 1 critical alerts are set as P1, and tier 1 non-critical alerts are set as P2. The same logic holds for tier 2 and P3/P4 respectively.

## Maintenance Windows

On cluster updates/upgrades, many alerts will fire in prometheus. We will want to create a workflow on cluster config updates to specify a maintenance window in PagerDuty to prevent page-spam.
