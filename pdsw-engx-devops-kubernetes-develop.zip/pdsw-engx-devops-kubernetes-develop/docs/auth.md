# Auth

By default, auth on our clusters uses standard kubernetes ssh certs and kops cert generation. We have options for adding other auth methods, as described below.

For our non-test clusters (tools, sandbox, dev, etc), we have our own auth tool, [`sk8s`](https://github.com/Sonos-Inc/pdsw-engx-devops-sk8s) which uses Dex for auth. See below for more on Dex, and see the `sk8s` repo for more on `sk8s`.

## OAuth2_Proxy

https://github.com/oauth2-proxy/oauth2-proxy

Much of the magic that makes this all work, was figured out by Joel Speed, [this](https://github.com/bitly/oauth2_proxy/pull/621#issuecomment-402158430) thread is very useful.

He's also the author of this post which currently comes up early on in "kubernetes dashboard oauth" searches on [google](https://thenewstack.io/single-sign-on-for-kubernetes-dashboard-experience/).

## Dex

[Dex](https://github.com/dexidp/dex) is basically the middle man between Kubernetes and any other oauth or OIDC provider.

The most important part to note is the OIDC provider must be passed to the kubernetes control plane as a parameter and
the client id _must match_ the client id passed via _any_ client, oauth or what have you.
