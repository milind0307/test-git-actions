# Regions

By default Kubernetes supports most regions however code changes in Kops are required for new regions.

In our configs, you can declare your region via the following values:

```yaml
cluster:
  region: us-east-1
  transitRegion: us-east-1
```

By default we spin up in us-east-1 but you can use us-east-2 or other regions if you'd prefer.

In order to gain access to your cluster, it needs to be bootstrapped into our transit vpc system, which only exists in specific regions.

By default this should always work but may incur additional latency, so you can consult our networking team to see what regions you should use.