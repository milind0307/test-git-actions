# Cluster Templating

In order to make our clusters more dynamic, we use [Kops Cluster Templating](https://github.com/kubernetes/kops/blob/main/docs/cluster_template.md) which
converts templated yaml to static yaml templates for Kops to consume.

**Note: the following is deprecated. These configurations now live in the [config repo](https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config) rather than in this repo.**

## Using Templates

Begin by copying the sample cluster config to a file for yourself:

```bash
cp cluster/environments/sample.yaml cluster/environments/your-cluster.dev.k.do.ws.sonos.com.yaml
```

Modify values in your-cluster.dev.k.do.ws.sonos.com.yaml to make your own custom cluster without checking it in. Make sure to name this file like \$YOUR_CLUSTER_NAME.yaml

## Environment Templates

For now, specific environment templates live in `cluster/environments` based on name. They are split in three files, `values.yaml`, `secrets.yaml.secret`, and on `git secret reveal`, `secrets.yaml`, which is the decrypted form of `secrets.yaml.secret`. We do this in order to encrypt sensitive values such as tokens and other keys. See [the secrets section](secret-encryption.md) for more info.
They may be abstracted to another repo in the future or a non-static location but for now we can override specific values for shared environments into these files.

## Writing Templates

Templates should abstract variables that make sense and have a set of sane defaults located in a values file.

Templates are [go templates](https://golang.org/pkg/text/template/) and can also utilize [Sprig template](https://github.com/Masterminds/sprig) functions
