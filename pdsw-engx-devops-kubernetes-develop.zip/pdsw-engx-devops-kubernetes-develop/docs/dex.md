# Dex

Training on dex/oauth2 hosted by the cloud-infra team: https://drive.google.com/file/d/1O5T9sK3f3lA4c0-1aGJ6avY7mAtf6ffC/view?usp=sharing

## TODO: Update this

Get cert from xml, decode base64 then convert to pem.
openssl x509 -in ca.crt -out ca.pem -outform PEM -inform der