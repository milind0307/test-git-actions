# Instances

Instances are defined in cluster values, which speficy the type/size of instances that kubernetes nodes run on.

Instances are inherited from the tier of a given cluster. Additional instances can be defined as needed in an individual cluster's values file.

## Configurable Fields

| Field                 | Description                                                |
| --------------------- | ---------------------------------------------------------- |
| maxSize               | maximum number of nodes to run of this size                |
| minSize               | minimum number of nodes to run of this size                |
| spot                  | spot pricing for this node type                            |
| taintPreferNoSchedule | taint to prefer pods to not be scheduled on this node type |

## Example

If writing your own instanceTypes in a values file, ensure that you define both a spot and non-spot instanceType for each instance.

```yaml
cluster:
  instanceTypes:
    m5.xlarge:
      maxSize: 20
    m5.xlarge-spot:
      maxSize: 20
      spot: .1930
```

## Features

### SSH access

You can access instances using [ec2-instance-connect](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/Connect-using-EC2-Instance-Connect.html)
utilizing your IAM credentials to access instances with the connect client installed.

Currently this client is installed during the [startup process](https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/develop/cluster/templates/cluster.yaml#L342-L347)
but in the future we'll bake it into our AMI's.

You can use the `ssh.sh` script to use your AWS session to log onto any instance.

For private instances without a public IP, the AWS console version of ec2-instance-connect does not currently work but ssh works very well with
the [aws ec2 instance cli](https://github.com/aws/aws-ec2-instance-connect-cli)

e.g.

```bash
# I've already authenticated with aws_okta_keyman or aws_auth
mssh admin@i-04f6cc7c1e4cc11cb -r us-east-2
```
