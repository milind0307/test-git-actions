# Upgrading a cluster

Make changes in required places, starting in [default.yaml](../cluster/tiers/default/values.yaml) makes sense.

## Background

Kops versions and kubernetes version are maintained independently. You can read more about that [here](https://github.com/kubernetes/kops#kubernetes-version-support).

In our configs, we've allowed you to set a default kops and kubernetes version in the [default.yaml](../cluster/tiers/default/values.yaml) but you can also set it in
your specific environment's values.yaml. This allows us to roll specific environments prior to releasing to all of them.

You'll want to change default.yaml or your value file for:

```yaml
kops:
  version: 1.13.0

# and

cluster:
  kubernetesVersion: 1.13.11
```

Running the `kops upgrade cluster` command could also suggest upgrades to ami's and other values.
It is safe to run and will not change anything unless run with the `--yes` flag.

You man also want to try the latest AMIs when upgrading a cluster to the new version, again see default.yaml:

```yaml
instanceGroups:
  master:
    ...
    image: kope.io/k8s-1.14-debian-stretch-amd64-hvm-ebs-2019-09-26
  nodes:
    ...
    image: kope.io/k8s-1.14-debian-stretch-amd64-hvm-ebs-2019-09-26
    ...
  other:
    image: kope.io/k8s-1.14-debian-stretch-amd64-hvm-ebs-2019-09-26
    ...
```

The latest versions of these images are stored in the channels folder of the kops project.
In most cases we run "alpha" versions [here](https://github.com/kubernetes/kops/blob/master/channels/alpha).
Channels allows kops to suggest to users versions we feel are "production ready" of kops, kubernetes and AMIs.
This allows us to push out security fixes proactively yet gives operators the ability to wait until they're ready
to upgrade.

## Basic commands

```shell
export CLUSTER_NAME=01.us-east-2.dev.devops.k8s.sonos.com
source source.sh

# If this is an existing cluster, disable alarms for an hour:
make alertmanager-silence

make cluster-update
make helmfile-sync

make rolling-update-cluster-control-nodes
make rolling-update-cluster-nodes
```
