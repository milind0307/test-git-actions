# Creating Shared Clusters

This document is a how-to guide for creating shared clusters, with examples focused on "upper" environments (stage, prod, etc.).

|                                                                                                                                                                                                                                                                                                                                |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| IMPORTANT: If the cluster is going into a new AWS account, make sure to complete all of the steps described in [Maintaining and Bootsrapping AWS Accounts for Kubernetes](https://github.com/Sonos-Inc/pdsw-devops-kubernetes-config/tree/main/aws-account-terraform#maintaining-and-bootsrapping-aws-accounts-for-kubernetes) |

<!-- START doctoc generated TOC please keep comment here to allow auto update -->

## Table of Contents

- [Creating Shared Clusters](#creating-shared-clusters)
  - [Table of Contents](#table-of-contents)
  - [1. Name Cluster](#1-name-cluster)
  - [2. Create Cluster DNS Zone](#2-create-cluster-dns-zone)
  - [3. Cluster Configs](#3-cluster-configs)
    - [Get Started](#get-started)
    - [values.yaml](#valuesyaml)
    - [secrets.yaml](#secretsyaml)
  - [4. Create Cluster](#4-create-cluster)
    - [Prepare Local Environment for New Cluster](#prepare-local-environment-for-new-cluster)
    - [Create New Cluster](#create-new-cluster)
    - [Prepare Local Environment for Cluster Hosting Dex](#prepare-local-environment-for-cluster-hosting-dex)
    - [Deploy Changes to Dex](#deploy-changes-to-dex)
    - [Security Groups](#security-groups)
    - [Validate](#validate)
  - [5. Sk8s](#5-sk8s)
  - [6. Additional Followups](#6-additional-followups)
    - [Additional Security Groups](#additional-security-groups)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

## 1. Name Cluster

Our current naming scheme is as follows:

`<numeric 2-digit id>.<aws-region>.<env>.k8s.sonos.com`

For example, the first cluster in our stage account in the us-east-1 region is:

`01.us-east-1.stage.k8s.sonos.com`

## 2. Create Cluster DNS Zone

1. Log in to console through Okta
2. Select role in desired account (PowerUserOkta or higher privelege)
3. Navigate to Route 53 console
4. Create Hosted Zone
   - Domain Name: `<numeric id>.<aws-region>.<env>.k8s.sonos.com` (use FULL cluster name)
   - Comment: `<region> <env> cluster <numeric id>` (e.g. "us-east-1 stage cluster 01")
   - Type: Public Hosted Zone
5. Get name servers from newly created cluster DNS zone
6. Navigate to `Hosted Zones` > `<env>.k8s.sonos.com`
7. Create record set
   - Name: `<numeric id>.<aws-region>.<env>.k8s.sonos.com` (use FULL cluster name)
   - Type: `NS - Name server`
   - Value: `<name servers>` (use name servers from step 5)
8. Create
9. Save the new cluster DNS zone's ID for later use

## 3. Cluster Configs

### Get Started

1. Create a new directory in cluster/environments with the FQDN of your cluster
2. Start by copying a `values.yaml` and `secrets.yaml` from the most similar environment you can find (may need to run `source source.sh` to decrypt secrets first)

### values.yaml

3. Read [Cluster Tiers](./tiers.md) and set `tier` to the correct value (e.g. `tier: tier1`)
4. Set `aws_account`, this should be in the format `sonos-<account>-<account-id>` and should match the directory name in `clusters/accounts`
5. Check for an unused `/22` network block in our [Devops Networking Allocations](https://confluence.sonos.com/display/PDSW/Devops+Networking+Allocations) page, reserve it for the new cluster, and add it to `values.yaml` as the value of `networkCIDR`
6. Fill in the `dnsZone` with the ID of the cluster's Route 53 DNS zone, collected in step 2.9 above.
7. Fill in the correct `region`, make sure the cluster name matches the chosen region here.

### secrets.yaml

8. `secrets.yaml` can be entirely copied from a cluster in the same environment
   - You may need to decrypt the other clusters to do this, which can be done by running `$ git secret reveal`, see [Secret Encryption](./secret-encryption.md) for more details
   - If this requires a new OIDC environment, see [Managing OIDC Environments (Issuers)](./oidc-issuers-environments.md)
9. Locate the `secrets.yaml` of the cluster running the Dex that the new cluster will be connecting to, and the config for your OIDC issuer/environment
   - As of writing `sandbox` and `tools` are the two clusters hosting Dex instances, upper
   - In the `secrets.yaml` you should see a list under `dex.config.staticClients`. You've found the right cluster if one of the static client `id` fields matches your desired OIDC environment/issuer (e.g. `kubernetes-stage`)
10. Now that you've located the relevant OIDC issuer config, add your cluster to the redirectURIS list like this:

```yaml
   staticClients:
      - id: <existing-oidc-issuer-env>
      redirectURIs:
        - ...
        - https://login.<cluster-fqdn>/oauth2/callback
        - https://grafana.<cluster-fqdn>/login/generic_oauth
        - https://monitoring.<cluster-fqdn>/login/generic_oauth
      ...
```

12. Make sure all instances of `client-id` and `client-secret` in your new cluster's `secrets.yaml` match the issuer in the Dex cluster's `secrets.yaml`

13. Add your new `secrets.yaml` to git secret

```shell
$ git secret add /path/to/cluster/environments/<cluster>/secrets.yaml
```

14. Encrypt your `secrets.yaml` and update the Dex cluster's `secrets.yaml`

```shell
$ git secret hide
```

15. Git commit all of your files including the new cluster's `secrets.yaml.secret` binary file and the updated `secrets.yaml.secret` from the cluster hosting Dex (the rest can be discarded)

## 4. Create Cluster

Manual for now :(

### Prepare Local Environment for New Cluster

1. Export cluster name

```shell
$ export CLUSTER_NAME=<cluster-fqdn>
```

2. Source script (prepares local env including AWS credentials)

```shell
$ source source.sh
```

### Create New Cluster

3. Create the cluster:

```shell
$ make cluster-up
```

4. Once completed, wait until the cluster is up and you can successfully execute `kubectl` commands (note: requires VPN)

```shell
$ kubectl get nodes
NAME                            STATUS   ROLES    AGE   VERSION
ip-10-223-21-165.ec2.internal   Ready    node     9d    v1.16.8
ip-10-223-21-205.ec2.internal   Ready    node     9d    v1.16.8
ip-10-223-21-91.ec2.internal    Ready    master   9d    v1.16.8
ip-10-223-22-212.ec2.internal   Ready    master   9d    v1.16.8
ip-10-223-23-156.ec2.internal   Ready    node     9d    v1.16.8
ip-10-223-23-41.ec2.internal    Ready    node     8d    v1.16.8
ip-10-223-23-64.ec2.internal    Ready    master   9d    v1.16.8
```

5. Sync our base helm charts (requires VPN):

```shell
$ make helmfile-sync
```

### Prepare Local Environment for Cluster Hosting Dex

6. Export cluster name

```shell
$ export CLUSTER_NAME=<cluster-hosting-dex-fqdn>
```

7. Source script

```shell
$ source source.sh
```

### Deploy Changes to Dex

|                                                                                                                                                                                  |
| -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| IMPORTANT: Do not perform these steps without checking in with the team! There may be things that have been merged that we do NOT want to deploy to the cluster hosting our Dex. |

8. Before you do anything read the warning above.

9. So did you check with the team yet? What about that one person who was offline in Slack today but has been working on cluster changes?

10. Sync helm charts

```shell
$ make helmfile-sync
```

### Security Groups

11. Does the cluster require additional security groups? The current method for creation of security groups such as those for Akamai and Apigee are very manuali and require extensive Ansible changes, however the Route53 healthcheck security group can be created in the cluster VPC by tagging the VPC with `R53HealthCheck: true`. This will persist even after `make cluster-update`, and the tag can be done either with the AWS CLI, or with the AWS web UI. In the future the components that create and maintain these security groups will be refactored to allow for easier deploying into new VPCs.

### Validate

12. Navigate in your browser to `https://dashboard.<cluster-fqdn>/` — did it work? Make sure it doesn't redirect to the dashboard of the cluster hosting Dex. Check Dex logs on the cluster hosting Dex if you have issues with auth or redirects.

## 5. Sk8s

Now it's time to get access available to those who did not spin up the cluster!

1. Check out the [sk8s repo](https://github.com/Sonos-Inc/pdsw-engx-devops-sk8s)
2. In your local kube config (`~/.kube/config`), there will be an entry in `clusters` for your newly created cluster. It will look something like this:

```shell
- cluster:
    certificate-authority-data: <certificate>
    server: https://api.01.us-east-1.prod.k8s.sonos.com
  name: 01.us-east-1.prod.k8s.sonos.com
```

Grab the `certificate-authority-data` for the next step.

3. In [clusters.yaml](https://github.com/Sonos-Inc/pdsw-engx-devops-sk8s/blob/develop/clusters.yaml), add your cluster to the `clusters` list. For `publicCert` use the `certificate-authority-data` from the previous step. Make sure to use the OIDC issuer as in your cluster's `values.yaml` (note: in `sk8s` the environments/issuers are not prefixed with `kubernetes-`, so for example Dex issuer `kubernetes-stage` in `sk8s` is just `stage`)

4. PR and merge
5. Connect to full-tunnel VPN, then update your sk8s config

```shell
$ sk8s update
I0505 14:55:58.652218   87244 clusterConfigUpdates.go:39] Sk8s Cluster data updated.
I0505 14:55:59.154650   87244 clusterConfigUpdates.go:39] Sk8s Cluster data updated.
```

## 6. Additional Followups

The additional follow up items below may be done based on the type of cluster we're configuring, e.g. sonos service based, or devops team based.

### Additional Security Groups

For PDSW team's applications to successfully deploy and take traffic, a number of security groups are required. Some of these groups are created via ansible, while others are created with lambdas that automatically manage the security groups rules over time. In the future, we hope to handle this via tagging of VPCs and automated security group creation, see [PDOPS-4316](https://jira.sonos.com/browse/PDOPS-4316) for more information.

- Site-shield - Currently deployed via the site-shield lambda, the following PRs represent the code required for them to work on a new kubernetes cluster. A lambda security key must also exist or be be created as well. See the following PRs. Commands to run the ansible are located in the readme:
  - https://github.com/Sonos-Inc/pdsw-devops-ansible/pull/1707
  - https://github.com/Sonos-Inc/pdsw-devops-ansible/pull/1708
  - https://github.com/Sonos-Inc/pdsw-devops-ansible/pull/1711
- Apigee & webops - Currently deployed manually with ansible, these playbooks create security groups required for vpn and apigee config
  - https://github.com/Sonos-Inc/pdsw-devops-ansible/pull/1714
- Route 53 Healthcheckers - This lambda runs per account and updates route53 security group with AWS IPs. The following PR is currently a WIP and addresses deployment to new K8s clusters.
  - https://github.com/Sonos-Inc/pdsw-devops-ansible/pull/1717
  - In addition to the above PR, a label must be added to the VPC to trigger the SG creation.
