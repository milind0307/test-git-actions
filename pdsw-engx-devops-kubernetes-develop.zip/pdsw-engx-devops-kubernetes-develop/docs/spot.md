# Using Spot Instances

Spot instances can be used as cluster nodes. This can be specified in the cluster environment, under `cluster.instanceTypes`.

```yaml
cluster:
...
  instanceTypes:
    m1.medium:
    - zone: us-east-1a
      spot: 0.0087
    - zone: us-east-1c
      spot: 0.0870
    - zone: us-east-1b
…
```

This will create three `m1.medium` ASGs, two being spot instances in us-east-1a, and us-east-1c, and the third non-spot in us-east-1b. You can also use this to create spot and non-spot instances in the same AZ. If a spot instance is terminated due to over-capacity or an outbid, the node will be drained and cordoned, so all pods are cleanly terminated and no new pods can be scheduled to the node.

## How It Works

If the `spot` field is defined as above for a given AZ, the Kops instance group has its `maxPrice` field defined with the information from the `spot` field from the cluster environment. It also has several labels applied to the node, namely `sonos.k8s.io/spot-worker=""`. The `sonos-base` Helm chart has the `k8s-termination-notice-handler` roled into it, which will watch the `termination-time` from the instane metadata. This always returns a 400 unless the instance is about to be terminated. The termination handler only runs on spot nodes thanks to only selecting nodes with the `spot-worker` label. The setup was tested by creating spot instances groups and creating a solo spot instance outside of Kops with a set run time of one hour, which was then terminated in a manner to activate the termination handler.
