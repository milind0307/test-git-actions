# End-to-End (e2e) Cluster Test

The e2e cluster test spins up an entire cluster in automation, performs tests, and then spins down an entire cluster.

## Overview

This job runs as a postsubmit job to spin up the `ci-test.k.do.ws.sonos.com` cluster. This test ensures that the kops and terraform configuration are correct, checks that all installed services come up with a `helmfile-sync`, and spins the cluster back down gracefully. This job runs as a postsubmit so that the job isn't auto-terminated when a new job is queued.

In the current implmentation, this cluster will attach to the transit VPC in order to have connectivity to Artifactory.

## Usage

The e2e test, unlike most other tests in prow, will not run automatically. By using the `/test postsubmit-sonos-kubernetes-e2e` command, prow will trigger the test.

This test typically runs for about 30 to 40 minutes.

## Troubleshooting

If an error occurs during the run, manual intervention may be required in order for subsiquent runs to be successful.

If an error occurs when the cluster is either being spun up or spun down, you may need to run a `make cluster-down` command on the `ci-test.k.do.ws.sonos.com` cluster to ensure that all of its AWS resources are removed. You can also run `/test presubmit-sonos-kubernetes-e2e-cleanup` in any PR in this repository to clean up the e2e test cluster.

In rare cases, if the Terraform state gets out of sync, manual deletion of cluster resources may be required.
