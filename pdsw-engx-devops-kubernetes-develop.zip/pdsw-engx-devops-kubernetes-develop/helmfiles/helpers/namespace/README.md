# Namespace helper

The goal of the namespace helper is:

- Automate creation of namespaces
- Ensure namespaces are created _before_ releases to be installed in them
- Ensure testability of independent helmfiles
  - e.g. both priority-class and spot-instance-helpers need the sonos-system namespace.
    Both should attempt to create them but not break if it already exists.
- Namespaces should NOT be deleted before helm releases running in them are deleted
  - We create namespaces (except sonos-system) via helm chart hooks so they are not deleted.

Things of note:

- releases with nil are required to always ensure sonos-system namespace exists.
