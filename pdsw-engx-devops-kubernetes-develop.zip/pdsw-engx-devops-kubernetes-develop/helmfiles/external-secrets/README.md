# External Secrets

See more [here](https://docs.k8s.sonos.com/operations/external_secrets/).

Note that external secrets gets rescheduled once a day by the [k8s descheduler](https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/db603b3ca14257746597a293a35df40ae04254ec/helmfiles/spot-instance-helpers/descheduler.yaml.gotmpl#L51-L62). This ensures that the pod doesn't get into a bad state similar to [this](https://github.com/godaddy/kubernetes-external-secrets/issues/407) error.
