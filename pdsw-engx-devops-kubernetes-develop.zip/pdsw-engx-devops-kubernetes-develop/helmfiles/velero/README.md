# Velero

## Setup

```bash
brew install velero
velero client config set namespace=sonos-system-velero
```
