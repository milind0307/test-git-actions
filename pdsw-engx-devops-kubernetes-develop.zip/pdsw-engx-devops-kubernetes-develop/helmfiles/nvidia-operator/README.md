# nvidia GPU Operator

## Setup

To enable this operator, in your values ensure that you have gpu accelerated nodes created with the following formatting:

```yaml
cluster:
  instanceTypes:
    accelerated.xlarge:
      maxSize: 1
      gpu: true # Required for some GPU specific tagging
      ops_costcenter: 220
      mixedInstancesPolicy:
        instances:
        - g4dn.xlarge
```

And also:

```yaml
nvidia:
  enabled: true
```

At that point you should be off to the races! To test that the cores are working as expected you can deploy the `workloadTest.yaml` file. You should see output similar to below:

```txt
Skipping CreateDcgmGroups() since DCGM validation is disabled
CU_DEVICE_ATTRIBUTE_MAX_THREADS_PER_MULTIPROCESSOR: 1024
CU_DEVICE_ATTRIBUTE_MULTIPROCESSOR_COUNT: 40
CU_DEVICE_ATTRIBUTE_MAX_SHARED_MEMORY_PER_MULTIPROCESSOR: 65536
CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR: 7
CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR: 5
CU_DEVICE_ATTRIBUTE_GLOBAL_MEMORY_BUS_WIDTH: 256
CU_DEVICE_ATTRIBUTE_MEMORY_CLOCK_RATE: 5001000
Max Memory bandwidth: 320064000000 bytes (320.06 GiB)
CudaInit completed successfully.
Skipping WatchFields() since DCGM validation is disabled
TensorEngineActive: generated ???, dcgm 0.000 (27119.1 gflops)
TensorEngineActive: generated ???, dcgm 0.000 (28430.0 gflops)
TensorEngineActive: generated ???, dcgm 0.000 (28350.5 gflops)
```

With the important bit being `CudaInit completed successfully.`

## Guides

- [kOps setup](https://github.com/kubernetes/kops/blob/master/docs/gpu.md)
- [nvidia setup](https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/getting-started.html#install-gpu-operator)