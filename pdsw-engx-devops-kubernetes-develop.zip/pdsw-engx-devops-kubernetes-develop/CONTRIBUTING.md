# Contributing guidelines

We adhere to [Git flow](https://lucamezzalira.com/2014/03/10/git-flow-vs-github-flow/) so always open PRs against the develop branch.
The Develop branch is what is typically deployed to our lower level, tier 3 and tier 2 clusters.
The Main branch and release are what are typically deployed to our tier 1 / production clusters.

This repo is automated by the devops team's [Prow bot](https://github.com/Sonos-Inc/pdsw-devops-prow).

For more information on interacting with Prow and our pull request process [visit our prow docs](https://github.com/Sonos-Inc/pdsw-devops-prow/blob/main/docs/working_with_prow.md).

To mark a pull request as a work in progress, add `WIP` to the title of the PR or type `/hold` in a comment, ensuring prow will not merge the PR until you are ready.

All PRs should be reviewed by a team member. Once approved, Prow will merge PRs in batches once all tests have passed.

If you're a code reviewer on this repo, you may wish to add yourself to the cluster admins for our Dex-based clusters. You can add your user to `charts/permissions/templates/engx-devops.yaml`, which can then be deployed by an existing cluster admin.

If you wish to add yourself to this repo's secrets, please see [our secret docs](/docs/secret-encryption.md).
