# Extreme Memory Usage

There are cases where you'll want to use large amounts of memory to see how well protected nodes are from the pods running on them.

This deployment is a simple example that allows you to overwhelm a node with memory allocation.
Note, in most cases resource requirements are enforced by kyverno but there are cases where a cluster
may run into issues that this process provides a good example for.

## Prerequsites

Kyverno should not be running in the cluster you're looking to test or should be disabled for the namespace you utilize.

Creating a throw away namespace can be useful for this:

```bash
kubectl create namespace abc
```

Make sure to update the namespace in the extreme-memory-usage-test.yaml file to match your namespace.

## Deployment

Start by finding the node in the cluster you wish to assign your workload to. Add that node to the `nodeSelector` in the manifest.

```bash
# To start the test:
kubectl apply -f extreme-memory-usage-test.yaml
# To end the test:
kubectl delete -f extreme-memory-usage-test.yaml
# It's very likely, if you've overwhelmed a node, it will not recover and will need to be killed in ec2.
```

Eventually a node should taint it's self to prevent the pod from being scheduled on it. Once that occurs, you can add a tolaration
on your deployment to ensure the pods can still run and cause extra destruction.
