# Test Case 2

## How To Run

First, set up the namespaces, network policies, deployments, and services

```bash
$ kubectl apply -f namespaces.yaml
$ kubectl apply -f networkpolicies.yaml
$ kubectl apply -f deployments.yaml
$ kubectl apply -f service.yaml
```

You'll want to gather a bit of information about IPs and ports. To do so run

```bash
$ kubectl get svc -n testcase2-ingress

NAME         TYPE           CLUSTER-IP      EXTERNAL-IP                                                               PORT(S)        AGE
frontend-1   ClusterIP      100.70.174.17   <none>                                                                    80/TCP         2m15s
frontend-2   LoadBalancer   100.64.48.195   a15e5f289841f4818842610cc6bc6cd1-1237059331.us-east-2.elb.amazonaws.com   80:30988/TCP   2m15s
```

The output here is an example, but the key things here are the ClusterIP of frontend-1 and the URL of frontend-2.

You can then run the following test cases. Should you get some HTML returned, access was granted into the pod, and if not then it was denied.

## Tests

### Test 1

From testcase2-ingress to testcase2-ingress

```bash
$ kubectl run curl -n testcase2-ingress --image=radial/busyboxplus:curl -i --tty
If you don't see a command prompt, try pressing enter.
[ root@curl:/ ]$ curl {ClusterIP of frontend-1}
```

Expected Result: Succesful connection

### Test 2

From testcase2-egress to testcase2-ingress

```bash
$ kubectl run curl -n testcase2-egress --image=radial/busyboxplus:curl -i --tty
If you don't see a command prompt, try pressing enter.
[ root@curl:/ ]$ curl {ClusterIP of frontend-1}
```

Expected Result: Unsuccessful Connection

### Test 3

From testcase2-system to testcase2-ingress

```bash
$ kubectl run curl -n testcase2-system --image=radial/busyboxplus:curl -i --tty
If you don't see a command prompt, try pressing enter.
[ root@curl:/ ]$ curl {ClusterIP of frontend-1}
```

Expected Result: Succesful connection

### Test 4

From external to testcase2-ingress

Open a web browser and connect to the URL of frontend-2.

Expected Result: Unsucessful connection
