# addon-aws-node
When using aws-vpc-cni, we run our cluster in "cni" networking mode to allow us to bootstrap the exact version and configs of
the cni, since kops will be indefinitely behind (by design).

Configuration
--------------
Standard configuration for the aws vpc cni lives in the [k8s-1.15.yaml](k8s-1.15.yaml) manifest.
Most of the configs are lifted straight from [their github project](https://github.com/aws/amazon-vpc-cni-k8s).

In order to put our pods in a different subnet, we have added additional cidr blocks and subnets [via terraform(https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/9844c40dd9678edd5ff95b327d46de152de2c231/terraform/vpc.tf#L92-L125)].
This will be moved to Kops once [this issue](https://github.com/kubernetes/kops/issues/8470) is resolved.

To utilize [Custom Networking](https://docs.aws.amazon.com/eks/latest/userguide/cni-custom-network.html) (which allows us to move pods to a separate subnet),
an ENI object must be created a passed to the cluster.  This templating is currently [done via terraform](https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/9efc4185fddeefe996efebbf020fc37562179a6e/terraform/aws-vpc-cni.tf#L23-L34) after creation of subnets.

Finally, these configs are uploaded to the kops s3 bucket via terraform and kops master nodes will apply the [supplied addons](https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/9844c40dd9678edd5ff95b327d46de152de2c231/cluster/templates/cluster.yaml#L6-L10).
The aws vpc cni also needs additional [iam policies](https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/9844c40dd9678edd5ff95b327d46de152de2c231/cluster/templates/cluster.yaml#L233-L289) for IP and ENI attachment.

Cleanup
--------
Clusters must now detach all IPs from aws-vpc-cni prior to attempted deletion.  For now, we call [the aws cli](https://github.com/Sonos-Inc/pdsw-engx-devops-kubernetes/blob/9844c40dd9678edd5ff95b327d46de152de2c231/Makefile#L246)
to scale down all instances prior to running deletion to pervent terraform from blocking cluster deletion.