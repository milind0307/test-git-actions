#!/bin/bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null && pwd )"
TEMP_DIR="${DIR}/.tmp"
CONFIG_REPO=${CONFIG_REPO:-"pdsw-devops-kubernetes-config"} # defaults to PDSW DevOps config repo
CONFIG_DIR="${TEMP_DIR}/${CONFIG_REPO}"

KOPS_BINARY="${DIR}/tools/bin/kops.sh"

# Catch cases where the users tries to exit this script while we're running a subshell
trap ctrl_c INT

function ctrl_c() {
  # Ensure we cd back to root during a ctrl c
  cd ${DIR} &>/dev/null
  trap - INT
}

[ "$0" = "$BASH_SOURCE" ] && { printf "This script needs to be run as:\nsource ./source.sh\n" && exit 1; }

echo ""
echo "Setup your environment for cluster operations"
echo ""
if [ -z "$SHORT_USER" ]; then
  SHORT_USER=$(whoami | cut -d. -f2)
fi

YQ_BINARY=${DIR}/tools/bin/yq.sh

if [ -z "${CLUSTER_NAME}" ]; then
  export CLUSTER_NAME=${CLUSTER_NAME:-test-${SHORT_USER}.dev.k.do.ws.sonos.com}
  echo "No CLUSTER_NAME set, using default"
fi

export KOPS_CLUSTER_NAME=${CLUSTER_NAME}

echo "Current cluster name: $CLUSTER_NAME"
echo ""

# config time

echo "Fetching config..."
echo
CONFIG_FETCH_CMD="${DIR}/tools/configfetcher.sh"
$CONFIG_FETCH_CMD
echo

echo "Generating templates..."
CONFIG_MERGE_OUTPUT=$(${DIR}/tools/configmerger.sh ${CLUSTER_NAME})
if [ $? -ne 0 ]; then
  echo
  echo "${CONFIG_MERGE_OUTPUT}"
  return 1
fi
echo

echo "Getting AWS role from generated template (yq)..."
AWS_ROLE=$(${YQ_BINARY} r ${CONFIG_MERGE_OUTPUT} cluster.role)
AWS_ACCOUNT_NAME=$(${YQ_BINARY} r ${CONFIG_MERGE_OUTPUT} cluster.account)
AWS_KEYMAN_APPID=$(${YQ_BINARY} r ${CONFIG_MERGE_OUTPUT} cluster.appid)
if [ $? -ne 0 ]; then
  return 1
fi
echo

echo "Getting AWS region from generated template (yq)..."
AWS_REGION=$(${YQ_BINARY} r ${CONFIG_MERGE_OUTPUT} cluster.region)
if [ $? -ne 0 ]; then
  return 1
fi
echo

echo "Getting Kops S3 bucket from generated template (yq)..."
AWS_S3_BUCKET=$(${YQ_BINARY} r ${CONFIG_MERGE_OUTPUT} kops_bucket)
if [ $? -ne 0 ]; then
  return 1
fi
echo

echo AWS Role: $AWS_ROLE
echo AWS Account Name: $AWS_ACCOUNT_NAME
echo AWS Region: $AWS_REGION
echo

aws_okta_keyman --account $AWS_ACCOUNT_NAME --role $AWS_ROLE --appid $AWS_KEYMAN_APPID --name $AWS_ACCOUNT_NAME --region $AWS_REGION -du 7200 -P
if [ $? -ne 0 ]; then
  return 1
fi

export AWS_PROFILE=$AWS_ACCOUNT_NAME
export AWS_REGION=$AWS_REGION
export KOPS_STATE_STORE=s3://${AWS_S3_BUCKET}/kops

echo
echo State store set to $KOPS_STATE_STORE
echo

echo exporting kubecfg for 4h if it exists
${KOPS_BINARY} export kubecfg --admin=4h
echo

echo Decrypting Secrets:
cd ${CONFIG_DIR} &>/dev/null
which git-vaultsecret &>/dev/null
if [ $? -eq 0 ]; then
  git vaultsecret reveal
else
  git secret reveal -f
fi
cd ${DIR} &>/dev/null

trap - INT