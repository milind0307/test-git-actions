# Building this AMI
We currently build an AMI for our clusters that builds off the latest stable Ubuntu AMI (i.e ubuntu/images/hvm-ssd/ubuntu-focal-20.04-amd64-server-*). Available images can be found via the aws cli:

```bash
aws ec2 describe-images --region us-east-1 --output table \
  --owners 099720109477 \
  --query "sort_by(Images, &CreationDate)[*].[CreationDate,Name,ImageId]" \
  --filters "Name=name,Values=ubuntu/images/hvm-ssd/ubuntu-focal-20.04-amd64-*"
```

This AMI contains neccessary packages for the kubelet, docker, and other components of kubernetes nodes which cuts down the start-up time for nodes as they are created by kOps.

To build an AMI manually (TODO: Implement automation), you can run `make packer-ami`. Make sure that you have run `source source.sh` to get new AWS credentials. Currently, the AMI lives in `pd-devops-dev`, though this may change in the future.
