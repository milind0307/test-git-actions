#!/bin/bash

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../../" >/dev/null 2>&1 && pwd )"

###############################
# docker-promoter.sh - The goal of this script is to promote a given image tag from the provided
#  registry, using the artifactory copy command
###############################

function yq {
  # Use YQ to extract argument from file
  # $1 = yaml path
  ${ROOT}/tools/bin/yq.sh read ${ROOT}/${VERSION_FILE_PATH} $1
}

# Set script values if not hard coded, otherwise overwrite with YQ values.
PROMOTE_FROM_REPO=${PROMOTE_FROM_REPO:-$(yq $YAML_PROMOTE_FROM_REPO_LOCATION)}
PROMOTE_TO_REPO=${PROMOTE_TO_REPO:-$(yq $YAML_PROMOTE_TO_REPO_LOCATION)}
DOCKER_REPOSITORY_PATH=${DOCKER_REPOSITORY_PATH:-$(yq $YAML_DOCKER_REPOSITORY_PATH_LOCATION)}
DOCKER_IMAGE_TAG=${DOCKER_IMAGE_TAG:-$(yq $YAML_DOCKER_IMAGE_TAG_LOCATION)}

echo "Values found:"
echo "PROMOTE_FROM_REPO: ${PROMOTE_FROM_REPO}"
echo "PROMOTE_TO_REPO: ${PROMOTE_TO_REPO}"
echo "DOCKER_REPOSITORY_PATH: ${DOCKER_REPOSITORY_PATH}"
echo "DOCKER_IMAGE_TAG: ${DOCKER_IMAGE_TAG}"
echo ""

if [ -z ${PROMOTE_FROM_REPO} ] || [ -z ${PROMOTE_TO_REPO} ]  || [ -z ${DOCKER_REPOSITORY_PATH} ] || [ -z ${DOCKER_IMAGE_TAG} ] || [ -z ${ARTIFACTORY_USER} ] || [ -z ${ARTIFACTORY_PASSWORD} ]; then
  echo "Required environment variables not defined."
  echo ""
  echo "$0  - Please define:"
  echo "PROMOTE_FROM_REPO = The repo name we're promoting an image from"
  echo "PROMOTE_TO_REPO = The repo name we're promoting an image to"
  echo "DOCKER_REPOSITORY_PATH = The full path to the reposotiroy we're moving"
  echo "ARTIFACTORY_USER = Artifactory username"
  echo "ARTIFACTORY_PASSWORD = Artifactory Password"

  exit 1
fi

PROMOTE_TO_REPO_SHORT=$(echo ${PROMOTE_TO_REPO} | cut -d. -f1)


data=$(cat <<EOF
{
  "targetRepo": "${PROMOTE_TO_REPO_SHORT}",
  "dockerRepository": "${DOCKER_REPOSITORY_PATH}",
  "tag": "${DOCKER_IMAGE_TAG}",
  "copy": true
}
EOF
)

curl -ifS -u${ARTIFACTORY_USER}:${ARTIFACTORY_PASSWORD} -X POST "https://${PROMOTE_FROM_REPO}/v2/promote" -H "Content-Type: application/json" -d "${data}"
