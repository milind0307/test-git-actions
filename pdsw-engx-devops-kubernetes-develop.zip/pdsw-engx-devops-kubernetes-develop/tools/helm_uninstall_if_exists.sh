#!/bin/bash

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"
HELM=${ROOT}/.tmp/helm/helm


if [ -z $1 ]; then
  echo "Error executing $0, please ensure proper format and arguments"
  echo "This script uninstalls a helm chart if it's installed. It always returns exit 0."
  echo "e.g. $0 <namespace> <release> <context>"
  exit 1
fi

namespace=$1
release=$2
context=$3

${HELM} uninstall ${release} -n ${namespace} --kube-context ${context}

exit 0