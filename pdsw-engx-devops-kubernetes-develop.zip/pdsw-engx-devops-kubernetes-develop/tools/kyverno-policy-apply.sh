#!/usr/bin/env bash

set -e

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"
TEMP_DIR="${ROOT}/.tmp"
KUBECTL=${ROOT}/tools/bin/kubectl.sh

# Kyverno Policies syncing

echo ""
echo "Kyverno policies syncing"
echo ""

# Loop through manifests in policies folder and apply all those with the policy-* prefix. Check whether the additional two policies are enabled
for i in `find ${ROOT}/manifests/kyverno-policies -name "policy-*.yaml" -type f`; do
    NAME="$(basename $i .yaml)"
    if [ "$NAME" = "policy-validate-service-lb-internal-only" ]; then
        if [ "$1" = "true" ]; then
            ${KUBECTL} apply -f "$i"
        fi
    elif [ "$NAME" = "policy-validate-namespace-naming" ]; then
        if [ "$2" = "true" ]; then
            ${KUBECTL} apply -f "$i"
        fi
    else
        ${KUBECTL} apply -f "$i"
    fi
done