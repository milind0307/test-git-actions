#!/bin/bash

set -e
set -o pipefail

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"
# Use YQ container to ensure versioning.
# Mount root directory to workdir AND the full path.
# This allows full paths to work both inside the container and outside.
YQ="${ROOT}/tools/bin/yq.sh"

if [ -z $1 ]; then
  echo "Please pass cluster name to script to merge required values."
  echo " $ $0 01.us-east-2.dev.devops.k8s.sonos.com"
  echo
  echo "For additional debug output: "
  echo " $ DEBUG=true $0 01.us-east-2.dev.devops.k8s.sonos.com "
  exit 1
fi

# Pass DEBUG=true to output
print () {
  if [ -n "$DEBUG" ]; then
    # Output Debug output to stderr
    >&2 echo "> $1"
  fi
}

CLUSTER_NAME=$1

# Prepare Output Directory

CONFIG_REPO=${CONFIG_REPO:="pdsw-devops-kubernetes-config"} # defaults to PDSW DevOps config repo
TEMP_DIR="${ROOT}/.tmp"
CONFIG_REPO_PATH="${CONFIG_REPO_PATH:-${TEMP_DIR}/${CONFIG_REPO}}" # can override
CLUSTER_DIR="${ROOT}/cluster"
ACCOUNTS_DIR="${CONFIG_REPO_PATH}/accounts"
OUTPUT_DIR="${ROOT}/outputs/${CLUSTER_NAME}"
OUTPUT_FILE="${OUTPUT_DIR}/values.yaml"
CLUSTER_CONFIG_DIR="${CONFIG_REPO_PATH}/environments/${CLUSTER_NAME}"
# Confirm config exists for $CLUSTER_NAME
if [ ! -f "${CLUSTER_CONFIG_DIR}/values.yaml" ]; then
  echo "Cluster ${CLUSTER_NAME} doesn't appear to have any values files, please confirm." 1>&2
  exit 1
fi

#######################################################
# Initial Merge to gather all default and base layers #
#######################################################

TIER=${TIER:-default}
TIER_CONFIG_DIR="${CLUSTER_DIR}/tiers/${TIER}"

# Layers used to merge and create initial values files
INITIAL_MERGE_LAYERS=(
  # Tier is merged in first
  ${TIER_CONFIG_DIR}/values.yaml
  # This Cluster's Values
  ${CLUSTER_CONFIG_DIR}/values.yaml
  # This Cluster's Secrets
  ${CLUSTER_CONFIG_DIR}/secrets.yaml
  # Tier, based values based on the above merged values
)

print "Beginning Initial Merge process "
print

# Ensure outut directory exists
mkdir -p ${OUTPUT_DIR}

print "Creating empty values file."

# Ensure output file exists, overwrites, reduces risk of race condition
echo --- > ${OUTPUT_FILE}

for i in "${INITIAL_MERGE_LAYERS[@]}"; do
  if [ -r "${i}" ]; then
    print "Merging Layer ${i}"
    ${YQ} merge --overwrite --inplace --allow-empty ${OUTPUT_FILE} ${i}
  else
    print "Layer not readable, moving on: ${i}"
  fi
done

print
print "Initial Merging complete"

#####################################################
# Secondary Merge to gather dependant layers layers #
#  e.g. a cluster may set a different tier then     #
#   we are aware of during the initial merge.       #
#####################################################

TIER=$(${YQ} r ${OUTPUT_FILE} tier)
TIER_CONFIG_DIR="${CLUSTER_DIR}/tiers/${TIER}"

ACCOUNT=$(${YQ} r ${OUTPUT_FILE} aws_account)
ACCOUNT_CONFIG_DIR="${ACCOUNTS_DIR}/${ACCOUNT}"

# Layers used to merge and create values files
MERGE_LAYERS=(
  # Use initial values to populate first
  ${OUTPUT_FILE}
  # Tier is merged in first
  ${TIER_CONFIG_DIR}/values.yaml
  # Account Values based on cluster config. This will not take tier into account except default tier
  ${ACCOUNT_CONFIG_DIR}/values.yaml
  # This Cluster's Values
  ${CLUSTER_CONFIG_DIR}/values.yaml
  # This Cluster's Secrets
  ${CLUSTER_CONFIG_DIR}/secrets.yaml
)

print "Beginning Final Merge process "
print

for i in "${MERGE_LAYERS[@]}"; do
  if [ -r "${i}" ]; then
    print "Merging Layer ${i}"
    ${YQ} merge --overwrite --inplace --allow-empty ${OUTPUT_FILE} ${i}
  else
    print "Layer not readable, moving on: ${i}"
  fi
done

print
print "Merging complete"

print
print "Returning values file path"

echo ${OUTPUT_FILE}
