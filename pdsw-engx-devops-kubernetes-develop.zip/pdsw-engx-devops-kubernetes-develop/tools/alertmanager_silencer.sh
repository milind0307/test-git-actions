#!/bin/bash

# This script leverages the `amtool` built in to alertmanager https://github.com/prometheus/alertmanager#amtool
# which essentially makes API calls to alertmanager.
# 
# Because alertmanager is behind dex, this tool executes `amtool` on a running alertmanager pod
#
# State is stored in .tmp/alertmanager

set -e

if [ -z $1 ]; then
  echo "Please pass alertmanager action to script to create/expire a silence."
  echo " $ $0 silence|expire"
  echo
  echo "   silence"
  echo "       create a silence on all alerts"
  echo
  echo "   expire"
  echo "       expire silence(s) on all alerts"
  exit 1
fi

ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../" >/dev/null 2>&1 && pwd )"
TEMP_DIR="${ROOT}/.tmp"
KUBECTL_BINARY="${ROOT}/tools/bin/kubectl.sh"
ALERTMANAGER_DIR="${TEMP_DIR}/alertmanager"
ALERTMANAGER_ID="${ALERTMANAGER_DIR}/silence_id"
PROMETHEUS_NAMESPACE="sonos-system-prometheus"
ALERTMANAGER_URL="http://localhost:9093"
SILENCE_DURATION="1h"

if [ -n ${CI} ]; then
  SILENCE_DURATION="3h"
fi

POD=$(${KUBECTL_BINARY} get pods -n ${PROMETHEUS_NAMESPACE} | grep alertmanager | awk '{print $1; exit}')

if [ -z $POD ]; then
  echo "Alertmanager is not installed in the cluster"
  exit 0
fi

if [ "$1" = "silence" ]; then
  echo "Silence alerts for alertmanager in namespace '${PROMETHEUS_NAMESPACE}'"
  OUTPUT=$(${KUBECTL_BINARY} exec -i -n ${PROMETHEUS_NAMESPACE} ${POD} -c alertmanager \
    -- amtool --alertmanager.url ${ALERTMANAGER_URL} silence add \
    'severity=~warning|critical' \
    --comment 'update in progress' \
    --author 'PnP DevOps Automation' \
    --duration ${SILENCE_DURATION})

  echo "Silence: ${OUTPUT}"
  mkdir -p ${ALERTMANAGER_DIR}
  echo ${OUTPUT} > ${ALERTMANAGER_ID}
elif [ "$1" = "expire" ]; then
  SILENCE=$(cat ${ALERTMANAGER_ID} | tr -cd "[:print:]\n")
  if [ -z $SILENCE ]; then
    echo "Expire all silences for alertmanager in namespace '${PROMETHEUS_NAMESPACE}' within '${SILENCE_DURATION}'"
    SILENCES=$(${KUBECTL_BINARY} exec -i -n ${PROMETHEUS_NAMESPACE} ${POD} -c alertmanager \
      -- amtool --alertmanager.url ${ALERTMANAGER_URL} silence query \
      --within ${SILENCE_DURATION} | grep -v "ID" | awk '{print $1}')
    for i in "${SILENCES}"; do
      echo "Expire ${i}"
      ${KUBECTL_BINARY} exec -i -n ${PROMETHEUS_NAMESPACE} ${POD} -c alertmanager \
        -- amtool --alertmanager.url ${ALERTMANAGER_URL} silence expire ${i}
    done
    echo "Silences Expired"
  else
    echo "Expire silence '${SILENCE}' for alertmanager in namespace '${PROMETHEUS_NAMESPACE}'"
    ${KUBECTL_BINARY} exec -i -n ${PROMETHEUS_NAMESPACE} ${POD} -c alertmanager \
      -- amtool --alertmanager.url ${ALERTMANAGER_URL} silence expire ${SILENCE}
    echo "Silence Expired"
  fi
else
  echo "'$1' is not a valid command"
  exit 1
fi