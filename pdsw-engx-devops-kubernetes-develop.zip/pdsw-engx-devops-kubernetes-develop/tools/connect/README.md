# Connect

This tool makes it easy to ssh to instance in a given cluster

## Development

This tool requires golang 1.17, which you'll see listed in the root of this repo under `/go.mod`.

Sample commands:

```bash
# From root of repo
go run ./tools/connect/main.go
go test ./tools/connect
go fmt ./tools/connect

go build -o connect ./tools/connect/main.go

# Docker build
# This should run from root of repo to pick up the go.* files
docker build -t test -f tools/connect/Dockerfile .
```
