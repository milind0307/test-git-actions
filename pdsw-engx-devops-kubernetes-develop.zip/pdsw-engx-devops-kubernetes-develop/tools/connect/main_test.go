package main

import (
	"os"
	"testing"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/service/ec2"
)

func Test_getRegion(t *testing.T) {
	tests := []struct {
		name           string
		setRegion      bool
		setRegionValue string
		want           string
	}{
		{
			name:      "Default",
			setRegion: false,
			want:      "us-east-1",
		},
		{
			name:           "Default",
			setRegion:      true,
			setRegionValue: "us-east-2",
			want:           "us-east-2",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if tt.setRegion {
				os.Setenv("AWS_REGION", tt.setRegionValue)
				defer os.Unsetenv("AWS_REGION")
			}

			if got := getRegion(); got != tt.want {
				t.Errorf("getRegion() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_getTag(t *testing.T) {
	type args struct {
		tags      []*ec2.Tag
		tagToFind string
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "value1",
			args: args{
				tags: []*ec2.Tag{
					{
						Key:   aws.String("tag1"),
						Value: aws.String("value1"),
					},
					{
						Key:   aws.String("tag2"),
						Value: aws.String("value2"),
					},
				},
				tagToFind: "tag1",
			},
			want: "value1",
		},
		{
			name: "empty",
			args: args{
				tags: []*ec2.Tag{
					{
						Key:   aws.String("tag1"),
						Value: aws.String("value1"),
					},
				},
				tagToFind: "tag2",
			},
			want: "",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := getTag(tt.args.tags, tt.args.tagToFind); got != tt.want {
				t.Errorf("getTag() = %v, want %v", got, tt.want)
			}
		})
	}
}
