#!/bin/bash

if [ -z $1 ]; then
  echo "Error executing $0, please ensure proper format and arguments"
  echo "This script will check to see if the provided file exists and returns 'true' or  'false'"
  exit 1
fi

path=$1

if [ -f "$(pwd)/$path" ]; then
  echo -n true
else
  echo -n false
fi