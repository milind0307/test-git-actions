# pdsw-devops-terraform-eks

This repo is a hackweek example of using terraform and [terraform eks blueprints](https://aws-ia.github.io/terraform-aws-eks-blueprints) to manage clusters.

## Automation

- On Checkin the [.github/workflows/ci.yml](.github/workflows/ci.yml) will trigger a deploy automatically.
- To spin down the cluster, manually trigger the [.github/workflows/destroy.yml](.github/workflows/destroy.yml).

## Demo

This demo should allow you to see karpenter scale up nodes automatically. It first determines node type required, then adds it to the cluster while the node boots.

```bash
# Login to the account
aws_okta_keyman --ro AdminOkta --account sonos-devops-dev --region us-east-2 -P

# Auth with cluster
aws eks --region us-east-2 update-kubeconfig --name argocd-preprod-test-eks

# To test, you can try the default kubernetes guestbook app (https://kubernetes.io/docs/tutorials/stateless-application/guestbook/#creating-the-guestbook-frontend-deployment)
# Notice, after deploying the cluster should automatically scale

kubectl create namespace guestbook
kubectl apply -f https://k8s.io/examples/application/guestbook/redis-leader-deployment.yaml -n guestbook
kubectl apply -f https://k8s.io/examples/application/guestbook/redis-leader-service.yaml -n guestbook
kubectl apply -f https://k8s.io/examples/application/guestbook/redis-follower-deployment.yaml -n guestbook
kubectl apply -f https://k8s.io/examples/application/guestbook/redis-follower-service.yaml -n guestbook
kubectl apply -f https://k8s.io/examples/application/guestbook/frontend-deployment.yaml -n guestbook
kubectl apply -f https://k8s.io/examples/application/guestbook/frontend-service.yaml -n guestbook

# Test the guestbook with a port forward:
kubectl port-forward svc/frontend 8080:80 -n guestbook
# Open a browser to http://localhost:8080

# Scale up
kubectl scale deploy frontend --replicas 10 -n guestbook

# Scale down
kubectl scale deploy frontend --replicas 2 -n guestbook

# Delete namespace
kubectl delete namespace guestbook

```

After completion, spin down the cluster using the job above.

## TF Docs

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| terraform | >= 1.0.0 |
| aws | >= 4.22.0 |
| helm | >= 2.4.1 |
| kubectl | >= 1.14 |
| kubernetes | >= 2.10 |

## Providers

| Name | Version |
|------|---------|
| aws | >= 4.22.0 |
| kubectl | >= 1.14 |
| kubernetes | >= 2.10 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| aws\_vpc | terraform-aws-modules/vpc/aws | ~> 3.0 |
| eks\_blueprints | github.com/aws-ia/terraform-aws-eks-blueprints | v4.6.2 |
| eks\_blueprints\_kubernetes\_addons | github.com/aws-ia/terraform-aws-eks-blueprints//modules/kubernetes-addons | v4.6.2 |

## Resources

| Name | Type |
|------|------|
| [kubectl_manifest.karpenter_provisioner](https://registry.terraform.io/providers/gavinbunney/kubectl/latest/docs/resources/manifest) | resource |
| [aws_availability_zones.available](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/availability_zones) | data source |
| [kubectl_path_documents.karpenter_provisioners](https://registry.terraform.io/providers/gavinbunney/kubectl/latest/docs/data-sources/path_documents) | data source |
| [kubernetes_service.kube_dns](https://registry.terraform.io/providers/hashicorp/kubernetes/latest/docs/data-sources/service) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| environment | Environment area, e.g. prod or preprod | `string` | `"preprod"` | no |
| tenant | Account Name or unique account unique id e.g., apps or management or aws007 | `string` | `"argocd"` | no |
| zone | Zone, e.g. dev or qa or load or ops etc... | `string` | `"test"` | no |

## Outputs

| Name | Description |
|------|-------------|
| configure\_kubectl | Configure kubectl: make sure you're logged in with the correct AWS profile and run the following command to update your kubeconfig |
<!-- END_TF_DOCS -->
